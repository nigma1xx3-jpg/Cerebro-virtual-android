from cerebro_version import VERSION
from nucleo.ciclo_cognitivo import ejecutar_ciclo
from memoria.episodica import recuperar_recuerdos
from memoria.semantica_profunda import resumen_motor
from nucleo.coordinador import estado_modulos
from nucleo.diagnostico import ejecutar_diagnostico
from aprendizaje.adaptativo import AprendizajeAdaptativo
from aprendizaje.feedback import registrar_feedback
from integridad.ledger import sellar_estado, verificar_estado
from planificacion.gestor import Planificador
from neurociencia.motor import consultar as consultar_neurociencia, resumen_base as resumen_neurociencia
from ejecutivo.gestor import GestorEjecutivo
from prediccion.calibrador import Calibrador
from memoria.indice_calidad import generar_informe as generar_informe_calidad
from aprendizaje.plasticidad_sinaptica import PlasticidadSinaptica
from aprendizaje.asociativo import AprendizajeAsociativo
from red_neuronal.red import RedNeuronalCognitiva
import json


class CerebroVirtual:
    def __init__(self):
        self.estado = "inicializado"
        self.modulos = estado_modulos()

    def iniciar(self):
        self.estado = "activo"
        print(f"\nCEREBRO VIRTUAL {VERSION} ACTIVADO")
        print("Estado:", self.estado)
        try:
            cantidad_recuerdos = len(recuperar_recuerdos())
        except Exception as exc:
            cantidad_recuerdos = f"no disponible ({type(exc).__name__})"
        print("Recuerdos almacenados:", cantidad_recuerdos)
        print("\nMódulos y límites declarados:")
        for modulo, estado in self.modulos.items():
            print(f"- {modulo}: {estado}")
        print("\nComandos: /ayuda, /estado, /diagnostico, /experiencias, /corregir N|texto, /red, /plasticidad, /reforzar origen->destino|si/no|referencia, /candidatos_asociativos, /asociaciones texto, /validar_asociacion origen->destino|si/no|referencia, /plan objetivo|paso1;paso2, /objetivos, /calidad_memoria, /semantica, /predicciones, /sellar, /verificar, /neuro consulta, salir")

    def procesar(self, entrada):
        try:
            resultado = ejecutar_ciclo(entrada)
        except Exception as exc:
            print("No se pudo completar el ciclo; no se confirma ningún aprendizaje:", type(exc).__name__, str(exc))
            return {"ciclo_completado": False, "error": f"{type(exc).__name__}: {exc}"}
        if not resultado.get("ciclo_completado"):
            print("\nEntrada no procesada:", resultado.get("error", "error no especificado"))
            return resultado
        procesamiento = resultado.get("procesamiento", {})
        analisis = procesamiento.get("razonamiento", {})
        motor = analisis.get("razonamiento", {})
        print("\n--- RESULTADO COGNITIVO ---")
        print("Respuesta:", analisis.get("respuesta", "Sin respuesta"))
        print("Confianza heurística:", motor.get("confianza", 0))
        print("Estado del razonamiento:", motor.get("estado", "no disponible"))
        print("Evidencias:", len(motor.get("evidencias", [])))
        print("Fuentes independientes validadas:", len(motor.get("fuentes_independientes", [])))
        print("Estado metacognitivo:", resultado.get("metacognicion", {}).get("estado", "no disponible"))
        neuro = resultado.get("regulacion_cognitiva", {})
        print("Carga cognitiva estimada:", neuro.get("carga_cognitiva_estimada", "no disponible"))
        print("Novedad léxica:", neuro.get("atencion", {}).get("novedad_lexica", "no disponible"))
        print("Requiere revisión:", resultado.get("metacognicion", {}).get("requiere_revision", True))
        print("Experiencia guardada como pendiente de feedback:", resultado.get("aprendizaje", {}).get("id", "no disponible"))
        red = resultado.get("red_neuronal", {})
        neuronas = red.get("neuronas", {}) if isinstance(red, dict) else {}
        activas = sorted(neuronas.items(), key=lambda par: par[1], reverse=True)[:5]
        if activas:
            print("Red sináptica: {} neuronas / {} sinapsis activas".format(
                len(neuronas), red.get("cantidad_sinapsis_activas", 0)))
            print("Nodos más activados:", ", ".join(
                "{}={:.2f}".format(nombre, valor) for nombre, valor in activas))
        for aviso in motor.get("advertencias", []):
            print("Aviso:", aviso)
        return resultado

    def comando(self, entrada):
        texto = entrada.strip()
        comando = texto.casefold()
        if comando in {"/ayuda", "ayuda"}:
            print("/estado: muestra capacidades y límites")
            print("/diagnostico: comprueba importaciones y JSON")
            print("/experiencias: lista experiencias para feedback")
            print("/corregir N|texto: añade corrección humana a la experiencia N")
            print("/red: muestra la topología y los pesos sinápticos actuales")
            print("/plasticidad: muestra el estado de la plasticidad sináptica supervisada")
            print("/reforzar origen->destino|si/no|referencia: ajusta una conexión tras validación humana explícita")
            print("/candidatos_asociativos: genera relaciones candidatas desde experiencias corregidas")
            print("/asociaciones texto: recupera relaciones previamente validadas")
            print("/validar_asociacion origen->destino|si/no|referencia: confirma o rechaza una relación")
            print("/plan objetivo|paso1;paso2: propone un plan, no lo ejecuta")
            print("/objetivo meta|tarea1;tarea2: registra un objetivo supervisado")
            print("/objetivos: muestra objetivos persistentes supervisados")
            print("/calidad_memoria: audita recuerdos sin modificarlos")
            print("/semantica: muestra el motor de recuperación semántica y sus límites")
            print("/predicciones: muestra evaluación de predicciones explícitas")
            print("/neuro tema: consulta la base educativa de neurociencia")
            print("/sellar: crea una línea base SHA-256 del código y los datos")
            print("/verificar: compara código y datos con el último sellado")
            print("Nota: SHA-256 detecta cambios desde un sellado; no demuestra que los recuerdos sean verdaderos.")
            return True
        if comando == "/estado":
            for modulo, estado in estado_modulos().items():
                print(f"{modulo}: {estado}")
            return True
        if comando == "/diagnostico":
            print(json.dumps(ejecutar_diagnostico(), ensure_ascii=False, indent=2))
            return True
        if comando == "/experiencias":
            experiencias = AprendizajeAdaptativo().cargar()
            print("Experiencias:", len(experiencias))
            for indice, experiencia in enumerate(experiencias, 1):
                if isinstance(experiencia, dict):
                    estado = "corregida" if experiencia.get("validada") else "pendiente"
                    print(f"{indice}. [{estado}] {experiencia.get('pensamiento', experiencia.get('evento', ''))[:100]} | ID={experiencia.get('id', 'registro_legacy')}")
            return True
        if comando.startswith("/corregir "):
            payload = texto[len("/corregir "):]
            if "|" not in payload:
                print("Uso: /corregir N|texto de corrección")
                return True
            referencia, correccion = payload.split("|", 1)
            referencia = referencia.strip()
            try:
                numero = int(referencia)
                referencia = numero - 1
            except ValueError:
                pass
            print(registrar_feedback(referencia, correccion))
            return True
        if comando.startswith("/plan "):
            payload = texto[len("/plan "):]
            if "|" in payload:
                objetivo, lista_pasos = payload.split("|", 1)
                pasos = [p.strip() for p in lista_pasos.split(";") if p.strip()]
            else:
                objetivo, pasos = payload, []
            plan = Planificador().crear_plan(objetivo.strip(), pasos)
            print(json.dumps(plan, ensure_ascii=False, indent=2))
            return True
        if comando == "/semantica":
            print(json.dumps(resumen_motor(), ensure_ascii=False, indent=2))
            return True
        if comando == "/neuro":
            print(json.dumps(resumen_neurociencia(), ensure_ascii=False, indent=2))
            print("Uso: /neuro tema o concepto")
            return True
        if comando.startswith("/neuro "):
            consulta = texto[len("/neuro "):].strip()
            resultados = consultar_neurociencia(consulta, limite=5)
            if not resultados:
                print("Sin coincidencias léxicas. Prueba con otros términos.")
            else:
                for item in resultados:
                    print(f"\\n[{item['id']}] {item['tema']} | área: {item['area']} | coincidencia léxica: {item['puntuacion_lexica']}")
                    print("Resumen:", item["resumen"])
                    print("Detalle:", item["detalle"])
                    print("Cautela:", item["cautela"])
                    print("Referencias:", "; ".join(item["referencias"]))
            return True
        if comando.startswith("/objetivo "):
            payload = texto[len("/objetivo "):]
            if "|" not in payload:
                print("Uso: /objetivo meta|tarea1;tarea2")
                return True
            objetivo, tareas = payload.split("|", 1)
            resultado = GestorEjecutivo().crear_objetivo(objetivo, [x.strip() for x in tareas.split(";") if x.strip()])
            print(json.dumps(resultado, ensure_ascii=False, indent=2))
            return True
        if comando == "/objetivos":
            print(json.dumps(GestorEjecutivo().listar(), ensure_ascii=False, indent=2))
            return True
        if comando == "/calidad_memoria":
            print(json.dumps(generar_informe_calidad(), ensure_ascii=False, indent=2))
            return True
        if comando == "/red":
            print(json.dumps(RedNeuronalCognitiva().resumen(), ensure_ascii=False, indent=2))
            return True
        if comando == "/plasticidad":
            print(json.dumps(PlasticidadSinaptica().resumen(), ensure_ascii=False, indent=2))
            return True
        if comando.startswith("/reforzar "):
            payload = texto[len("/reforzar "):]
            partes = payload.split("|", 2)
            if len(partes) != 3 or "->" not in partes[0]:
                print("Uso: /reforzar origen->destino|si/no|referencia")
                return True
            origen, destino = [x.strip() for x in partes[0].split("->", 1)]
            decision = partes[1].strip().casefold()
            if decision not in {"si", "sí", "no"}:
                print("La evaluación debe ser si o no; no se modificó ninguna conexión.")
                return True
            resultado = PlasticidadSinaptica().reforzar(
                origen, destino, decision in {"si", "sí"},
                referencia=partes[2], validador="usuario",
            )
            print(json.dumps(resultado, ensure_ascii=False, indent=2))
            return True
        if comando == "/candidatos_asociativos":
            candidatos = AprendizajeAsociativo().generar_candidatos()
            print(json.dumps({"cantidad": len(candidatos), "candidatos": candidatos}, ensure_ascii=False, indent=2))
            return True
        if comando.startswith("/asociaciones "):
            consulta = texto[len("/asociaciones "):].strip()
            print(json.dumps(AprendizajeAsociativo().recuperar_relacionadas(consulta), ensure_ascii=False, indent=2))
            return True
        if comando.startswith("/validar_asociacion "):
            payload = texto[len("/validar_asociacion "):]
            partes = payload.split("|", 2)
            if len(partes) != 3 or "->" not in partes[0]:
                print("Uso: /validar_asociacion origen->destino|si/no|referencia")
                return True
            origen, destino = [x.strip() for x in partes[0].split("->", 1)]
            decision = partes[1].strip().casefold()
            if decision not in {"si", "sí", "no"}:
                print("La decisión debe ser si o no; no se guardó ningún cambio.")
                return True
            resultado = AprendizajeAsociativo().validar_asociacion(
                origen, destino, aprobada=decision in {"si", "sí"},
                referencia=partes[2], validador="usuario",
            )
            print(json.dumps(resultado, ensure_ascii=False, indent=2))
            return True
        if comando == "/predicciones":
            print(json.dumps(Calibrador().resumen(), ensure_ascii=False, indent=2))
            return True
        if comando == "/sellar":
            print(sellar_estado())
            return True
        if comando == "/verificar":
            print(verificar_estado())
            return True
        return False


if __name__ == "__main__":
    cerebro = CerebroVirtual()
    cerebro.iniciar()
    while True:
        entrada = input("\nTu mensaje (escribe salir para terminar): ")
        if entrada.strip().casefold() in {"salir", "exit", "quit"}:
            print("Cerebro virtual en pausa.")
            break
        if entrada.strip().startswith("/") or entrada.strip().casefold() == "ayuda":
            cerebro.comando(entrada)
            continue
        cerebro.procesar(entrada)
