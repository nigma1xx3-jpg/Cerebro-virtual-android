import unittest

from memoria.semantica_profunda import buscar_semanticamente, tokens_semanticos
from razonamiento.central import buscar_coincidencias


class PruebasSemanticaProfunda(unittest.TestCase):
    def test_equivalencia_conceptual_automovil_coche(self):
        docs = [{"concepto": "automóvil", "informacion": "medio de transporte de cuatro ruedas"}]
        r = buscar_semanticamente("coche", docs, umbral=0.10)
        self.assertEqual(len(r), 1)
        self.assertGreater(r[0]["similitud_vectorial"], 0)
        self.assertEqual(r[0]["metodo"], "tfidf_coseno_expandido_espanol")

    def test_equivalencia_celular_smartphone(self):
        docs = [{"concepto": "smartphone", "informacion": "dispositivo móvil para comunicación"}]
        r = buscar_semanticamente("teléfono celular", docs, umbral=0.10)
        self.assertTrue(r)

    def test_documento_irrelevante_no_se_recupera(self):
        docs = [{"concepto": "receta", "informacion": "harina levadura horno pan"}]
        r = buscar_semanticamente("memoria episódica autobiográfica", docs, umbral=0.18)
        self.assertEqual(r, [])

    def test_resultado_incluye_metodo_y_limitacion(self):
        r = buscar_semanticamente("coche", [{"contenido": "automóvil familiar"}], umbral=0.05)
        self.assertTrue(r)
        self.assertIn("limitacion", r[0])

    def test_entrada_invalida_no_rompe(self):
        self.assertEqual(buscar_semanticamente("", [{"contenido": "algo"}]), [])
        self.assertEqual(tokens_semanticos(None), [])


    def test_recuperacion_del_razonamiento_usa_equivalencias_semanticas(self):
        conocimientos = {
            "automóvil": {
                "informacion": "vehículo familiar de cuatro ruedas",
                "procedencia": "entrada_usuario",
                "estado": "verificado",
            }
        }
        r = buscar_coincidencias("coche", conocimientos)
        self.assertTrue(r)
        self.assertEqual(r[0]["concepto"], "automóvil")
        self.assertIn("_relevancia_semantica", r[0])

    def test_limites_se_validan(self):
        with self.assertRaises(ValueError):
            buscar_semanticamente("coche", [], limite=0)


if __name__ == "__main__":
    unittest.main()
