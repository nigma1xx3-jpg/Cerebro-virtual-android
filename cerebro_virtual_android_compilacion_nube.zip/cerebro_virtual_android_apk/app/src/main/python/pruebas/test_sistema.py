import json
import tempfile
import unittest
import io
from contextlib import redirect_stdout
from pathlib import Path

from razonamiento.motor import razonar
from metacognicion.evaluador import Metacognicion
from planificacion.gestor import Planificador
from integridad.verificador import verificar_procedencia
from memoria.recuperacion import recuperar_similares, normalizar_tokens
from seguridad.validacion import validar_texto
from memoria.gobernanza import evaluar_registro
from nucleo.diagnostico import ejecutar_diagnostico
from integridad.ledger import _archivos_gestionados
from cerebro import CerebroVirtual
from nucleo.coordinador import procesar_informacion
from nucleo.almacenamiento import cargar_json
from unittest.mock import patch
from emociones.valoracion import valorar
from aprendizaje.adaptativo import AprendizajeAdaptativo
import integridad.ledger as ledger
from neurociencia.motor import consultar, cargar_base, resumen_base


class PruebasRegresion(unittest.TestCase):
    def test_detecta_negacion_opuesta(self):
        resultado = razonar({
            "entrada": "prueba",
            "conocimientos": ["El usuario trabaja de día", "El usuario nunca trabaja de día"],
            "recuerdos": [], "asociaciones": [],
        })
        self.assertEqual(len(resultado["contradicciones"]), 1)
        self.assertEqual(resultado["estado"], "contradiccion_detectada")
        self.assertEqual(resultado["confianza"], 5)

    def test_no_confunde_dia_y_noche(self):
        resultado = razonar({
            "entrada": "prueba",
            "conocimientos": ["El usuario trabaja de día", "El usuario trabaja de noche"],
            "recuerdos": [], "asociaciones": [],
        })
        self.assertEqual(resultado["contradicciones"], [])

    def test_entrada_actual_es_observacion(self):
        resultado = razonar({"entrada": "Mensaje de prueba", "conocimientos": [], "recuerdos": [], "asociaciones": []})
        self.assertEqual(len(resultado["evidencias"]), 1)
        self.assertEqual(resultado["evidencias"][0]["tipo"], "observacion")

    def test_metacognicion_acepta_diccionarios(self):
        with tempfile.TemporaryDirectory() as tmp:
            meta = Metacognicion(Path(tmp) / "historial.json")
            resultado = meta.evaluar(
                "prueba", evidencia=[{"tipo": "observacion", "dato": "mensaje de prueba"}],
                confianza="20", calidad_evidencia="20",
            )
            self.assertEqual(len(resultado["evidencias"]), 1)
            recargada = Metacognicion(Path(tmp) / "historial.json")
            self.assertEqual(len(recargada.historial), 1)
            self.assertEqual(recargada.historial[0]["pensamiento"], "prueba")

    def test_metacognicion_no_finge_calidad_si_es_invalida(self):
        with tempfile.TemporaryDirectory() as tmp:
            meta = Metacognicion(Path(tmp) / "historial.json")
            resultado = meta.evaluar("prueba", evidencia=["dato"], confianza=70, calidad_evidencia="no-se")
            self.assertIsNone(resultado["calidad_evidencia"])
            self.assertEqual(resultado["estado"], "evidencia_pendiente_de_validacion")
            self.assertTrue(resultado["requiere_revision"])


    def test_comando_plan_funciona_en_consola(self):
        cerebro = CerebroVirtual()
        salida = io.StringIO()
        with redirect_stdout(salida):
            correcto = cerebro.comando("/plan Ordenar módulos|Revisar código;Probar arranque")
        self.assertTrue(correcto)
        texto = salida.getvalue()
        self.assertIn('"ejecutado": false', texto)
        self.assertIn('"estado": "propuesto"', texto)

    def test_planificador_no_ejecuta(self):
        plan = Planificador().crear_plan("Verificar proyecto", ["Ejecutar pruebas"])
        self.assertEqual(plan["estado"], "propuesto")
        self.assertFalse(plan["ejecutado"])
        self.assertTrue(plan["requiere_confirmacion"])

    def test_planificador_trata_paso_string_como_un_paso(self):
        plan = Planificador().crear_plan("Meta válida", "Paso único")
        self.assertEqual(len(plan["pasos"]), 1)
        self.assertEqual(plan["pasos"][0]["descripcion"], "Paso único")

    def test_procedencia_no_afirma_veracidad(self):
        resultado = verificar_procedencia({"contenido": "dato", "procedencia": "usuario"})
        self.assertTrue(resultado["valido"])
        self.assertIn("no_verificada", resultado["motivo"])

    def test_busqueda_recupera_coincidencia_y_descarta_irrelevante(self):
        docs = ["memoria episódica y recuerdos personales", "receta de pan casero"]
        resultados = recuperar_similares("recuerdos de memoria episódica", docs)
        self.assertEqual(resultados[0]["registro"], docs[0])
        self.assertEqual(len(resultados), 1)

    def test_normalizacion_conserva_palabras_utiles_sin_tildes(self):
        self.assertEqual(set(normalizar_tokens("Memoría episódica")), {"memoria", "episodica"})

    def test_validacion_de_entrada(self):
        self.assertTrue(validar_texto("hola")["valido"])
        self.assertEqual(validar_texto("  ")["motivo"], "entrada_vacia")
        self.assertEqual(validar_texto("x" * 4001)["motivo"], "entrada_demasiado_larga")
        self.assertEqual(validar_texto(None)["motivo"], "tipo_no_textual")

    def test_valoracion_no_confunde_subcadena_bien_en_tambien(self):
        resultado = valorar("también estoy aquí")
        self.assertEqual(resultado["valencia"], 0)

    def test_valoracion_detecta_negacion_de_amenaza(self):
        self.assertFalse(valorar("no hay peligro") ["amenaza"])
        self.assertTrue(valorar("hay peligro") ["amenaza"])

    def test_aprendizaje_requiere_feedback_explicito(self):
        with tempfile.TemporaryDirectory() as tmp:
            sistema = AprendizajeAdaptativo(Path(tmp) / "experiencias.json")
            experiencia = sistema.registrar_experiencia("idea de prueba", {"confianza": 40})
            self.assertFalse(experiencia["validada"])
            self.assertEqual(experiencia["estado_aprendizaje"], "pendiente_feedback")
            self.assertTrue(sistema.registrar_correccion(experiencia["id"], "corrección humana"))
            actualizada = sistema.cargar()[0]
            self.assertTrue(actualizada["validada"])
            self.assertEqual(actualizada["correccion"], "corrección humana")

    def test_rutas_de_aprendizaje_son_absolutas(self):
        sistema = AprendizajeAdaptativo()
        self.assertTrue(Path(sistema.archivo).is_absolute())




    def test_coordinador_transmite_experiencias_y_valoracion(self):
        experiencias = [{"experiencia": {"evento": "experiencia previa"}, "similitud": 0.4}]
        percepcion = {"original": "entrada de prueba"}
        emocion = {"valencia": 0, "amenaza": False}
        with patch("nucleo.coordinador.recibir_entrada", return_value=percepcion), \
             patch("nucleo.coordinador.valorar", return_value=emocion), \
             patch("nucleo.coordinador.analizar", return_value={"respuesta": "ok"}) as analizar_mock, \
             patch("nucleo.coordinador.guardar_recuerdo", return_value=True), \
             patch("nucleo.coordinador.aprender", return_value={"aprendido": False}):
            resultado = procesar_informacion("entrada de prueba", experiencias)
        analizar_mock.assert_called_once_with("entrada de prueba", emocion, experiencias)
        self.assertTrue(resultado["procesado"])

    def test_motor_admite_aprendizajes_como_evidencia_separada(self):
        resultado = razonar({"entrada": "prueba", "conocimientos": [], "recuerdos": [],
            "asociaciones": [], "aprendizajes": [{"evento": "experiencia previa", "_procedencia": "aprendizaje_local", "_estado_verificacion": "pendiente_feedback"}]})
        self.assertIn("aprendizaje", [e["tipo"] for e in resultado["evidencias"]])
        self.assertEqual(resultado["fuentes_independientes"], [])

    def test_gobernanza_excluye_recuerdo_con_caracteres_de_control(self):
        resultado = evaluar_registro({"contenido": chr(24)})
        self.assertFalse(resultado["recuperable"])
        self.assertEqual(resultado["motivo"], "caracteres_de_control")


    def test_gobernanza_excluye_caracteres_de_formato_invisibles(self):
        resultado = evaluar_registro({"contenido": "mensaje\u202eoculto de prueba"})
        self.assertFalse(resultado["recuperable"])

    def test_gobernanza_no_considera_procedencia_de_usuario_independiente(self):
        resultado = evaluar_registro({"contenido": "dato valido para prueba", "procedencia": "entrada_usuario", "estado": "sin_verificar"})
        self.assertIsNone(resultado["fuente_independiente"])

    def test_confianza_no_aumenta_por_repetir_fuentes_internas(self):
        resultado = razonar({"entrada": "prueba", "conocimientos": [{"concepto": "dato", "informacion": "dato local", "_procedencia": "entrada_usuario", "_estado_verificacion": "sin_verificar"}], "recuerdos": [{"contenido": "dato local", "_procedencia": "entrada_usuario", "_estado_verificacion": "sin_verificar"}], "asociaciones": []})
        self.assertEqual(resultado["fuentes_independientes"], [])
        self.assertLessEqual(resultado["confianza"], 20)
        self.assertTrue(resultado["requiere_revision"])

    def test_planificador_no_revienta_con_pasos_invalidos(self):
        plan = Planificador().crear_plan("Meta válida", 123)
        self.assertEqual(plan["pasos"], [])
        self.assertEqual(plan["estado"], "necesita_descomposicion")



    def test_json_ausente_se_recupera_de_bak(self):
        with tempfile.TemporaryDirectory() as tmp:
            ruta = Path(tmp) / "datos.json"
            ruta.with_suffix(".json.bak").write_text('["respaldo"]', encoding="utf-8")
            self.assertEqual(cargar_json(ruta, []), ["respaldo"])
            self.assertEqual(json.loads(ruta.read_text(encoding="utf-8")), ["respaldo"])
            self.assertTrue(ruta.with_suffix(".json.bak").exists())

    def test_diagnostico_no_se_cae_si_memoria_no_se_puede_abrir(self):
        with patch("nucleo.diagnostico.recuperar_recuerdos", side_effect=OSError("prueba")):
            resultado = ejecutar_diagnostico()
        self.assertIn("OSError", resultado["calidad_memoria"]["error_lectura"])

    def test_json_danado_se_recupera_de_bak_y_conserva_original(self):
        with tempfile.TemporaryDirectory() as tmp:
            ruta = Path(tmp) / "datos.json"
            ruta.write_text("{ json dañado", encoding="utf-8")
            ruta.with_suffix(".json.bak").write_text('[{"id": 1}]', encoding="utf-8")
            datos = cargar_json(ruta, [])
            self.assertEqual(datos, [{"id": 1}])
            self.assertEqual(json.loads(ruta.read_text(encoding="utf-8")), [{"id": 1}])
            self.assertTrue(ruta.with_suffix(".json.corrupt").exists())
            self.assertTrue(ruta.with_suffix(".json.bak").exists())

    def test_json_danado_sin_bak_no_se_sustituye_silenciosamente(self):
        with tempfile.TemporaryDirectory() as tmp:
            ruta = Path(tmp) / "datos.json"
            ruta.write_text("{ json dañado", encoding="utf-8")
            with self.assertRaises(json.JSONDecodeError):
                cargar_json(ruta, [])
            self.assertEqual(ruta.read_text(encoding="utf-8"), "{ json dañado")

    def test_adaptativo_acepta_ruta_string(self):
        with tempfile.TemporaryDirectory() as tmp:
            sistema = AprendizajeAdaptativo(str(Path(tmp) / "datos.json"))
            self.assertTrue(Path(sistema.archivo).is_absolute())

    def test_diagnostico_importa_componentes(self):
        resultado = ejecutar_diagnostico()
        self.assertTrue(all(v == "ok" for v in resultado["modulos"].values()))

    def test_ledger_incluye_codigo_fuente(self):
        self.assertIn("cerebro.py", _archivos_gestionados())
        self.assertIn("razonamiento/motor.py", _archivos_gestionados())
        self.assertIn("ejecutivo/gestor.py", _archivos_gestionados())
        self.assertIn("prediccion/calibrador.py", _archivos_gestionados())
        self.assertIn("atencion/selectiva.py", _archivos_gestionados())

    def test_sesgo_no_detecta_subcadena_inocente(self):
        with tempfile.TemporaryDirectory() as tmp:
            meta = Metacognicion(Path(tmp) / "historial.json")
            self.assertEqual(meta.detectar_sesgos("anuncian novedades"), [])


    def test_diagnostico_detecta_recuerdos_heredados_irregulares_sin_borrarlos(self):
        resultado = ejecutar_diagnostico()
        self.assertGreaterEqual(resultado["calidad_memoria"]["recuerdos_total"], 12)
        self.assertEqual(resultado["calidad_memoria"]["recuerdos_excluidos_de_recuperacion"], 3)

    def test_ledger_puede_sellarse_si_historial_opcional_no_existe(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for rel in ledger.ARCHIVOS_DATOS:
                if rel == "metacognicion/historial.json":
                    continue
                ruta = root / rel
                ruta.parent.mkdir(parents=True, exist_ok=True)
                ruta.write_text("[]" if rel.endswith(".json") else "{}", encoding="utf-8")
            original_ruta = ledger.ruta_proyecto
            original_manifest = ledger.ARCHIVO_MANIFIESTO
            original_archivos_codigo = ledger._archivos_codigo
            ledger.ruta_proyecto = lambda *parts: root.joinpath(*parts)
            ledger.ARCHIVO_MANIFIESTO = root / "integridad" / "manifiesto.json"
            ledger._archivos_codigo = lambda: ()
            try:
                ledger.sellar_estado()
                self.assertEqual(ledger.verificar_estado()["estado"], "integro")
                (root / "metacognicion/historial.json").parent.mkdir(parents=True, exist_ok=True)
                (root / "metacognicion/historial.json").write_text("[]", encoding="utf-8")
                self.assertEqual(ledger.verificar_estado()["estado"], "cambios_detectados")
            finally:
                ledger.ruta_proyecto = original_ruta
                ledger.ARCHIVO_MANIFIESTO = original_manifest
                ledger._archivos_codigo = original_archivos_codigo

    def test_ledger_detecta_cambio_en_archivo(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for rel in ledger.ARCHIVOS_DATOS:
                ruta = root / rel
                ruta.parent.mkdir(parents=True, exist_ok=True)
                ruta.write_text("[]" if rel.endswith(".json") else "{}", encoding="utf-8")
            original_ruta = ledger.ruta_proyecto
            original_manifest = ledger.ARCHIVO_MANIFIESTO
            original_archivos_codigo = ledger._archivos_codigo
            (root / "cerebro.py").write_text("print('ok')", encoding="utf-8")
            ledger.ruta_proyecto = lambda *parts: root.joinpath(*parts)
            ledger.ARCHIVO_MANIFIESTO = root / "integridad" / "manifiesto.json"
            ledger._archivos_codigo = lambda: ("cerebro.py",)
            try:
                sellado = ledger.sellar_estado()
                self.assertTrue(sellado["sellado"])
                self.assertEqual(ledger.verificar_estado()["estado"], "integro")
                (root / "memoria" / "recuerdos.json").write_text('["alterado"]', encoding="utf-8")
                (root / "cerebro.py").write_text("print('modificado')", encoding="utf-8")
                resultado = ledger.verificar_estado()
                self.assertEqual(resultado["estado"], "cambios_detectados")
                self.assertIn("memoria/recuerdos.json", resultado["alterados"])
                self.assertIn("cerebro.py", resultado["alterados"])
            finally:
                ledger.ruta_proyecto = original_ruta
                ledger.ARCHIVO_MANIFIESTO = original_manifest
                ledger._archivos_codigo = original_archivos_codigo



    def test_base_neurociencia_tiene_entradas_y_referencias(self):
        base = cargar_base()
        self.assertGreaterEqual(len(base["entradas"]), 20)
        self.assertTrue(all(e.get("referencias") for e in base["entradas"]))

    def test_consulta_neurociencia_recupera_sinapsis(self):
        resultados = consultar("sinapsis neurotransmisores", limite=3)
        self.assertTrue(resultados)
        self.assertEqual(resultados[0]["id"], "NEURO-002")

    def test_consulta_neurociencia_no_finge_semantica(self):
        resultados = consultar("xyz qqq no_existe")
        self.assertEqual(resultados, [])

    def test_consulta_neurociencia_limite_seguro(self):
        self.assertEqual(consultar("memoria", limite=0), [])
        self.assertEqual(consultar("", limite=3), [])

    def test_comando_neuro_en_consola(self):
        cerebro = CerebroVirtual()
        salida = io.StringIO()
        with redirect_stdout(salida):
            correcto = cerebro.comando("/neuro dopamina recompensa")
        self.assertTrue(correcto)
        self.assertIn("NEURO-008", salida.getvalue())


    def test_regulacion_cognitiva_declara_limites_y_buffer(self):
        from neurociencia.regulacion_cognitiva import evaluar
        resultado = evaluar("Atención, memoria y aprendizaje", persistir=False)
        self.assertEqual(resultado["modelo"], "heuristico_inspirado_en_neurociencia")
        self.assertGreaterEqual(resultado["memoria_trabajo"]["elementos_en_buffer"], 1)
        self.assertLessEqual(resultado["memoria_trabajo"]["elementos_en_buffer"], 7)
        self.assertTrue(resultado["limitaciones"])

    def test_ciclo_integra_regulacion_cognitiva(self):
        from nucleo.ciclo_cognitivo import ejecutar_ciclo
        procesamiento = {"procesado": True, "razonamiento": {"razonamiento": {"confianza": 20, "evidencias": []}},
                         "estado_emocional": {}, "memoria_guardada": False}
        evaluacion = {"estado": "prueba", "requiere_revision": True}
        with patch("nucleo.ciclo_cognitivo.buscar_relacionadas", return_value=[]), \
             patch("nucleo.ciclo_cognitivo.procesar_informacion", return_value=procesamiento), \
             patch("nucleo.ciclo_cognitivo.supervisor.evaluar", return_value=evaluacion), \
             patch("nucleo.ciclo_cognitivo.supervisor.retroalimentacion", return_value={}), \
             patch("nucleo.ciclo_cognitivo.aprendizaje.registrar_experiencia", return_value={"id": "prueba"}), \
             patch("nucleo.ciclo_cognitivo.evaluar_regulacion_cognitiva", return_value={"carga_cognitiva_estimada": "baja"}):
            resultado = ejecutar_ciclo("Quiero analizar cómo funciona la atención y la memoria.")
        self.assertTrue(resultado["ciclo_completado"])
        self.assertIn("regulacion_cognitiva", resultado)
        self.assertIn("carga_cognitiva_estimada", resultado["regulacion_cognitiva"])


if __name__ == "__main__":
    unittest.main()

class PruebasAutonomiaSupervisada(unittest.TestCase):
    def test_recuperacion_contextual_idf(self):
        from memoria.recuperacion import recuperar_contextuales
        docs = ["memoria episódica y recuerdos", "receta de pan casero", "memoria semántica"]
        r = recuperar_contextuales("memoria episódica", docs)
        self.assertEqual(r[0]["registro"], docs[0])

    def test_atencion_selectiva_devuelve_prioridad_explicable(self):
        from atencion.selectiva import evaluar
        r = evaluar("revisar memoria y aprendizaje", objetivo="memoria")
        self.assertGreater(r["prioridad"], 0)
        self.assertIn("memoria", r["tokens_relevantes"])

    def test_gestor_ejecutivo_persiste_y_exige_aprobacion(self):
        from ejecutivo.gestor import GestorEjecutivo
        with tempfile.TemporaryDirectory() as tmp:
            g = GestorEjecutivo(Path(tmp)/"objetivos.json")
            o = g.crear_objetivo("Auditar el sistema", ["Ejecutar pruebas"])
            tarea=o["tareas"][0]
            self.assertTrue(o["creado"])
            self.assertFalse(g.actualizar_tarea(o["id"], tarea["id"], "en_progreso", aprobada=False))
            self.assertTrue(g.actualizar_tarea(o["id"], tarea["id"], "en_progreso", aprobada=True))
            self.assertEqual(g.listar()[0]["estado"], "en_progreso")

    def test_gestor_no_acepta_estado_arbitrario(self):
        from ejecutivo.gestor import GestorEjecutivo
        with tempfile.TemporaryDirectory() as tmp:
            g=GestorEjecutivo(Path(tmp)/"objetivos.json")
            o=g.crear_objetivo("Objetivo válido", ["Tarea"])
            self.assertFalse(g.actualizar_tarea(o["id"],o["tareas"][0]["id"],"ejecutar_codigo",aprobada=True))

    def test_calibrador_registra_y_evalua_prediccion(self):
        from prediccion.calibrador import Calibrador
        with tempfile.TemporaryDirectory() as tmp:
            c=Calibrador(Path(tmp)/"pred.json")
            p=c.registrar("La prueba pasará", 70)
            self.assertTrue(p["registrada"])
            self.assertTrue(c.evaluar(p["id"], "La prueba pasó", True))
            self.assertEqual(c.resumen()["precision_observada"], 1.0)

    def test_calibrador_no_acepta_confianza_invalida(self):
        from prediccion.calibrador import Calibrador
        with tempfile.TemporaryDirectory() as tmp:
            self.assertFalse(Calibrador(Path(tmp)/"p.json").registrar("x", "alta")["registrada"])

    def test_perfil_aprendizaje_usa_solo_feedback_validado(self):
        from aprendizaje.adaptativo import AprendizajeAdaptativo
        with tempfile.TemporaryDirectory() as tmp:
            a=AprendizajeAdaptativo(Path(tmp)/"e.json")
            e=a.registrar_experiencia("memoria contextual", {"confianza":30})
            self.assertEqual(a.perfil_aprendizaje()["correcciones_fuente"],0)
            a.registrar_correccion(e["id"],"La corrección humana dice memoria contextual")
            self.assertEqual(a.perfil_aprendizaje()["correcciones_fuente"],1)

    def test_indice_calidad_no_modifica_recuerdos(self):
        from memoria.indice_calidad import generar_informe
        from unittest.mock import patch
        datos=[{"contenido":"recuerdo válido"},{"contenido":chr(24)}]
        with tempfile.TemporaryDirectory() as tmp:
            with patch("memoria.indice_calidad.recuperar_recuerdos", return_value=datos), patch("memoria.indice_calidad.ruta_proyecto", side_effect=lambda *x: Path(tmp).joinpath(*x)):
                r=generar_informe()
            self.assertEqual(r["total"],2)
            self.assertEqual(r["excluidos_solo_de_recuperacion"],1)
            self.assertEqual(datos[1]["contenido"],chr(24))

    def test_ciclo_declara_autonomia_supervisada(self):
        from nucleo.ciclo_cognitivo import ejecutar_ciclo
        with patch("nucleo.ciclo_cognitivo.validar_texto", return_value={"valido":False,"motivo":"prueba","texto":""}):
            r=ejecutar_ciclo("x")
        self.assertFalse(r["ciclo_completado"])
