import tempfile
import unittest
from pathlib import Path

from red_neuronal.red import RedNeuronalCognitiva, NEURONAS
from red_neuronal.integracion import activar_red_cognitiva


class PruebasRedNeuronal(unittest.TestCase):
    def test_red_propaga_senal_desde_percepcion_hasta_razonamiento(self):
        red = RedNeuronalCognitiva(Path(tempfile.mkdtemp()) / "sinapsis.json")
        resultado = red.propagar({"percepcion": 1.0}, rondas=3)
        self.assertGreater(resultado["neuronas"]["atencion"], 0)
        self.assertGreater(resultado["neuronas"]["memoria_trabajo"], 0)
        self.assertGreater(resultado["neuronas"]["razonamiento"], 0)
        self.assertGreater(resultado["cantidad_sinapsis_activas"], 0)

    def test_red_respeta_limites_de_activacion(self):
        red = RedNeuronalCognitiva(Path(tempfile.mkdtemp()) / "sinapsis.json")
        resultado = red.propagar({"percepcion": 99, "atencion": -4})
        self.assertTrue(all(0 <= x <= 1 for x in resultado["neuronas"].values()))

    def test_red_rechaza_numero_de_rondas_invalido(self):
        red = RedNeuronalCognitiva(Path(tempfile.mkdtemp()) / "sinapsis.json")
        with self.assertRaises(ValueError):
            red.propagar({"percepcion": 1}, rondas=99)

    def test_plasticidad_exige_feedback_explicito(self):
        red = RedNeuronalCognitiva(Path(tempfile.mkdtemp()) / "sinapsis.json")
        antes = red.pesos[("percepcion", "atencion")]
        resultado = red.reforzar_sinapsis("percepcion", "atencion", None)
        self.assertFalse(resultado["actualizada"])
        self.assertEqual(red.pesos[("percepcion", "atencion")], antes)

    def test_plasticidad_validada_persiste_y_se_recupera(self):
        ruta = Path(tempfile.mkdtemp()) / "sinapsis.json"
        red = RedNeuronalCognitiva(ruta)
        antes = red.pesos[("percepcion", "atencion")]
        resultado = red.reforzar_sinapsis("percepcion", "atencion", True)
        self.assertTrue(resultado["actualizada"])
        recargada = RedNeuronalCognitiva(ruta)
        self.assertGreater(recargada.pesos[("percepcion", "atencion")], antes)

    def test_integracion_genera_red_con_senales_de_modulos(self):
        resultado = activar_red_cognitiva(
            procesamiento={"entrada": {"original": "hola"},
                           "estado_emocional": {"relevancia": 50},
                           "razonamiento": {"razonamiento": {"confianza": 60},
                                            "recuerdos": [{}], "conocimientos": [{}]}},
            atencion={"prioridad": 80},
            regulacion={"memoria_trabajo": {"elementos_en_buffer": 3}},
            metacognicion={"estado": "evaluado"},
            aprendizaje={"id": "exp-1"},
            planificacion={"estado": "propuesto"},
            integridad=[{"valido": True}],
        )
        self.assertEqual(resultado["naturaleza"], "neurona_computacional_no_biologica")
        self.assertGreater(resultado["neuronas"]["percepcion"], 0)
        self.assertGreater(resultado["neuronas"]["razonamiento"], 0)
        self.assertGreater(resultado["cantidad_sinapsis_activas"], 0)


if __name__ == "__main__":
    unittest.main()
