import json
import tempfile
import unittest
from pathlib import Path

from aprendizaje.asociativo import AprendizajeAsociativo


class PruebasAprendizajeAsociativo(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.exp = self.tmp / "experiencias.json"
        self.assoc = self.tmp / "asociaciones.json"
        self.exp.write_text(json.dumps([
            {"id": "e1", "validada": True, "pensamiento": "memoria contextual",
             "correccion": "memoria contextual mejora recuperacion"},
            {"id": "e2", "validada": True, "pensamiento": "memoria contextual",
             "correccion": "memoria contextual facilita recuperacion"},
            {"id": "e3", "validada": False, "pensamiento": "memoria contextual",
             "correccion": "memoria contextual sin validacion"},
        ]), encoding="utf-8")
        self.motor = AprendizajeAsociativo(self.assoc, self.exp)

    def test_candidatos_solo_desde_experiencias_validadas(self):
        candidatos = self.motor.generar_candidatos(minimo_coocurrencias=2)
        pares = {(x["origen"], x["destino"]) for x in candidatos}
        self.assertIn(("contextual", "memoria"), pares)
        self.assertTrue(all(x["estado"] == "candidato_no_verificado" for x in candidatos))

    def test_candidato_no_se_activa_sin_validacion(self):
        self.motor.validar_asociacion(
            "memoria", "contextual", aprobada=False,
            referencia="prueba de rechazo", validador="tester"
        )
        salida = self.motor.recuperar_relacionadas("memoria")
        self.assertEqual(salida["activadas"], [])
        self.assertEqual(salida["candidatas"], [])

    def test_asociacion_validada_se_recupera_por_un_termino(self):
        r = self.motor.validar_asociacion(
            "memoria", "contextual", aprobada=True,
            referencia="evidencia revisada", validador="tester"
        )
        self.assertTrue(r["actualizada"])
        salida = self.motor.recuperar_relacionadas("memoria")
        self.assertEqual(len(salida["activadas"]), 1)
        self.assertEqual(salida["activadas"][0]["destino"], "contextual")

    def test_no_acepta_aprobacion_ambigua(self):
        r = self.motor.validar_asociacion(
            "memoria", "contextual", aprobada="si",
            referencia="evidencia", validador="tester"
        )
        self.assertFalse(r["actualizada"])
        self.assertEqual(self.motor.recuperar_relacionadas("memoria")["activadas"], [])

    def test_evento_idempotente(self):
        args = dict(aprobada=True, referencia="evidencia", validador="tester", evento_id="evt-1")
        a = self.motor.validar_asociacion("memoria", "contextual", **args)
        b = self.motor.validar_asociacion("memoria", "contextual", **args)
        self.assertTrue(a["actualizada"])
        self.assertFalse(b["actualizada"])


if __name__ == "__main__":
    unittest.main()
