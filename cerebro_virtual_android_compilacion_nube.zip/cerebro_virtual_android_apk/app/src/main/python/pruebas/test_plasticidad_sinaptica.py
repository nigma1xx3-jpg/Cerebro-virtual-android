import tempfile
import unittest
from pathlib import Path

from aprendizaje.plasticidad_sinaptica import PlasticidadSinaptica
from red_neuronal.red import RedNeuronalCognitiva
from cerebro import CerebroVirtual
from contextlib import redirect_stdout
import io


class PruebasPlasticidadSinaptica(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.pesos = self.base / 'sinapsis.json'
        self.historial = self.base / 'historial.json'
        self.plasticidad = PlasticidadSinaptica(self.historial, self.pesos)

    def tearDown(self):
        self.tmp.cleanup()

    def test_requiere_resultado_booleano_explicito(self):
        antes = self.plasticidad.red.pesos[('percepcion', 'atencion')]
        r = self.plasticidad.reforzar('percepcion', 'atencion', 'si', referencia='prueba', validador='usuario')
        self.assertFalse(r['actualizada'])
        self.assertEqual(antes, self.plasticidad.red.pesos[('percepcion', 'atencion')])

    def test_requiere_procedencia_y_validador(self):
        r = self.plasticidad.reforzar('percepcion', 'atencion', True, referencia='', validador='usuario')
        self.assertEqual(r['motivo'], 'referencia_obligatoria')
        r = self.plasticidad.reforzar('percepcion', 'atencion', True, referencia='caso-1', validador='')
        self.assertEqual(r['motivo'], 'validador_obligatorio')

    def test_refuerzo_persistente_y_auditable(self):
        antes = self.plasticidad.red.pesos[('percepcion', 'atencion')]
        r = self.plasticidad.reforzar('percepcion', 'atencion', True, referencia='caso-1', validador='usuario', evento_id='evt-1')
        self.assertTrue(r['actualizada'])
        self.assertGreater(r['peso_nuevo'], antes)
        recargada = PlasticidadSinaptica(self.historial, self.pesos)
        self.assertGreater(recargada.red.pesos[('percepcion', 'atencion')], antes)
        self.assertEqual(recargada.resumen()['eventos_plasticidad'], 1)

    def test_no_procesa_dos_veces_el_mismo_evento(self):
        kwargs = dict(referencia='caso-1', validador='usuario', evento_id='evt-duplicado')
        primero = self.plasticidad.reforzar('percepcion', 'atencion', True, **kwargs)
        peso = self.plasticidad.red.pesos[('percepcion', 'atencion')]
        segundo = self.plasticidad.reforzar('percepcion', 'atencion', True, **kwargs)
        self.assertTrue(primero['actualizada'])
        self.assertEqual(segundo['motivo'], 'evento_ya_procesado')
        self.assertEqual(peso, self.plasticidad.red.pesos[('percepcion', 'atencion')])

    def test_feedback_negativo_debilita_conexion_sin_salir_de_limites(self):
        antes = self.plasticidad.red.pesos[('percepcion', 'atencion')]
        r = self.plasticidad.reforzar('percepcion', 'atencion', False, referencia='caso-2', validador='usuario')
        self.assertTrue(r['actualizada'])
        self.assertLess(r['peso_nuevo'], antes)
        self.assertGreaterEqual(r['peso_nuevo'], 0.05)
        self.assertLessEqual(r['peso_nuevo'], 0.99)

    def test_resumen_red_informa_topologia_valida(self):
        red = RedNeuronalCognitiva(self.pesos)
        resumen = red.resumen()
        self.assertEqual(resumen["neuronas"], 14)
        self.assertEqual(resumen["sinapsis"], 23)
        self.assertTrue(resumen["topologia_valida"])
        self.assertEqual(resumen["neuronas_aisladas"], [])

    def test_comandos_red_y_plasticidad_estan_disponibles(self):
        cerebro = CerebroVirtual()
        salida = io.StringIO()
        with redirect_stdout(salida):
            self.assertTrue(cerebro.comando("/red"))
            self.assertTrue(cerebro.comando("/plasticidad"))
        texto = salida.getvalue()
        self.assertIn("topologia_valida", texto)
        self.assertIn("requiere_validacion_humana", texto)

    def test_no_modifica_sinapsis_inexistente(self):
        r = self.plasticidad.reforzar('no_existe', 'atencion', True, referencia='caso-3', validador='usuario')
        self.assertEqual(r['motivo'], 'sinapsis_inexistente')


if __name__ == '__main__':
    unittest.main()
