import re
from seguridad.validacion import validar_texto


def recibir_entrada(texto):
    validacion = validar_texto(texto)
    if not validacion["valido"]:
        return None
    texto = validacion["texto"]
    texto_limpio = texto.casefold()
    palabras = re.findall(r"\b\w+\b", texto_limpio, flags=re.UNICODE)
    palabras_es = {"que", "para", "como", "pero", "cuando", "porque", "este", "esta", "soy", "tengo", "estoy", "una", "uno", "los", "las", "del", "con", "por"}
    coincidencias_es = len(set(palabras) & palabras_es)
    idioma = "es" if coincidencias_es >= 1 or any(c in "áéíóúñÁÉÍÓÚÑ" for c in texto) else "indeterminado"
    return {
        "original": texto,
        "limpio": texto_limpio,
        "palabras": palabras,
        "cantidad_palabras": len(palabras),
        "cantidad_caracteres": len(texto),
        "idioma_estimado": idioma,
    }
