import re
import unicodedata
from datetime import datetime
import json
from nucleo.almacenamiento import ruta_proyecto, cargar_json, guardar_json_atomico


class Metacognicion:

    def __init__(self, archivo=None):
        self.archivo = ruta_proyecto("metacognicion", "historial.json") if archivo is None else archivo
        historial = cargar_json(self.archivo, [])
        if not isinstance(historial, list):
            raise ValueError("El historial metacognitivo no contiene una lista JSON válida.")
        self.historial = historial
        registros_validos = [item for item in self.historial if isinstance(item, dict)]
        self.historial = registros_validos[-500:]
        self.errores = [
            c for item in registros_validos
            for c in item.get("contradicciones", [])
        ]
        self.sesgos = [
            alerta for item in registros_validos
            for alerta in item.get("alertas_de_sesgo", [])
        ]
        self.confianza = self.historial[-1].get("confianza", 0) if self.historial else 0

    def _persistir(self):
        guardar_json_atomico(self.archivo, self.historial, copia_seguridad=True)

    def normalizar(self, texto):
        texto = texto.lower()
        texto = unicodedata.normalize("NFD", texto)
        texto = "".join(
            c for c in texto
            if unicodedata.category(c) != "Mn"
        )
        return texto

    def detectar_sesgos(self, pensamiento):

        texto = self.normalizar(pensamiento)
        alertas = []

        patrones = {
            "pensamiento_absoluto": [
                "siempre", "nunca", "todos", "nadie"
            ],
            "certeza_excesiva": [
                "es imposible", "sin ninguna duda",
                "es obvio", "indiscutiblemente"
            ],
            "confirmacion": [
                "solo busco pruebas a favor",
                "ignoro las pruebas contrarias"
            ]
        }

        tokens = set(re.findall(r"\w+", texto))
        for sesgo, palabras in patrones.items():
            detectado = any(
                (set(re.findall(r"\w+", patron)) <= tokens)
                if " " in patron else patron in tokens
                for patron in palabras
            )
            if detectado:
                alertas.append(sesgo)

        self.sesgos.extend(alertas)

        return alertas

    def evaluar(
        self,
        pensamiento,
        evidencia=None,
        confianza=50,
        calidad_evidencia=None
    ):

        try:
            confianza = max(0, min(100, float(confianza)))
        except (TypeError, ValueError):
            confianza = 0

        if evidencia is None:
            evidencias = []
        elif isinstance(evidencia, list):
            evidencias = evidencia
        else:
            evidencias = [evidencia]

        evidencias_normalizadas = []
        for item in evidencias:
            if isinstance(item, str):
                texto = item.strip()
            elif isinstance(item, dict):
                valor = (
                    item.get("dato") or item.get("contenido")
                    or item.get("informacion") or item.get("texto")
                )
                texto = str(valor).strip() if valor is not None else ""
            else:
                texto = str(item).strip()
            if texto:
                evidencias_normalizadas.append(texto)
        evidencias = evidencias_normalizadas

        alertas = self.detectar_sesgos(pensamiento)

        if calidad_evidencia is not None:
            try:
                calidad_evidencia = max(0, min(100, float(calidad_evidencia)))
            except (TypeError, ValueError):
                calidad_evidencia = None

        if not evidencias:
            estado = "evidencia_insuficiente"
        elif calidad_evidencia is None:
            estado = "evidencia_pendiente_de_validacion"
        else:
            estado = "evaluado_heuristicamente"

        contradicciones = []
        for i, afirmacion_a in enumerate(evidencias):
            for afirmacion_b in evidencias[i + 1:]:
                if self.detectar_contradiccion(afirmacion_a, afirmacion_b):
                    contradicciones.append({
                        "afirmacion_a": afirmacion_a,
                        "afirmacion_b": afirmacion_b
                    })

        revision = (
            confianza < 60
            or bool(contradicciones)
            or not evidencias
            or calidad_evidencia is None
            or (
                calidad_evidencia is not None
                and calidad_evidencia < 50
            )
            or bool(alertas)
        )

        resultado = {
            "fecha": datetime.now().isoformat(),
            "pensamiento": pensamiento,
            "evidencias": evidencias,
            "confianza": confianza,
            "calidad_evidencia": calidad_evidencia,
            "alertas_de_sesgo": alertas,
            "contradicciones": contradicciones,
            "requiere_revision": revision,
            "estado": estado
        }

        self.historial.append(resultado)
        self.historial = self.historial[-500:]
        self.confianza = confianza
        self._persistir()

        return resultado

    def detectar_contradiccion(self, afirmacion_a,
                               afirmacion_b):

        a = self.normalizar(afirmacion_a)
        b = self.normalizar(afirmacion_b)

        negaciones = {"no", "nunca", "jamas"}

        palabras_a = set(re.findall(r"\w+", a))
        palabras_b = set(re.findall(r"\w+", b))

        contenido_a = palabras_a - negaciones
        contenido_b = palabras_b - negaciones

        opuesta = (
            contenido_a == contenido_b
            and bool(palabras_a & negaciones)
            != bool(palabras_b & negaciones)
            and bool(contenido_a)
        )

        if opuesta:
            error = {
                "tipo": "posible_contradiccion",
                "afirmacion_a": afirmacion_a,
                "afirmacion_b": afirmacion_b
            }

            self.errores.append(error)

        return opuesta

    def corregir(self, indice, nueva_conclusion):

        if type(indice) is int and 0 <= indice < len(self.historial) and isinstance(nueva_conclusion, str) and nueva_conclusion.strip():

            self.historial[indice]["correccion"] = nueva_conclusion.strip()[:4000]

            self.historial[indice]["estado"] = "revisado"
            self._persistir()

            return True

        return False

    def retroalimentacion(self, indice):

        if not 0 <= indice < len(self.historial):
            return None

        dato = self.historial[indice]
        recomendaciones = []

        if not dato.get("evidencias"):
            recomendaciones.append(
                "Buscar evidencias antes de concluir."
            )

        if dato.get("calidad_evidencia") is None:
            recomendaciones.append(
                "Validar la calidad de las evidencias."
            )

        if dato.get("confianza", 0) < 60:
            recomendaciones.append(
                "Revisar el razonamiento y su nivel de confianza."
            )

        if dato.get("alertas_de_sesgo"):
            recomendaciones.append(
                "Examinar posibles sesgos cognitivos."
            )

        if not recomendaciones:
            recomendaciones.append(
                "Mantener la conclusion bajo observacion."
            )

        return recomendaciones

    def informe(self):

        return {
            "pensamientos_evaluados": len(self.historial),
            "errores_detectados": len(self.errores),
            "alertas_de_sesgo": len(self.sesgos),
            "nivel_confianza_actual": self.confianza
        }


if __name__ == "__main__":

    cerebro = Metacognicion()

    resultado = cerebro.evaluar(
        pensamiento="La hipotesis parece correcta",
        evidencia=["Datos disponibles para analizar"],
        confianza=70,
        calidad_evidencia=65
    )

    print("\n=== METACOGNICION 2.0 ===")
    print(resultado)

    print("\n=== RETROALIMENTACION ===")
    print(cerebro.retroalimentacion(0))

    print("\n=== PRUEBA DE CONTRADICCION ===")

    print(
        cerebro.detectar_contradiccion(
            "El sistema funciona",
            "El sistema no funciona"
        )
    )

    print("\n=== INFORME GENERAL ===")
    print(cerebro.informe())
