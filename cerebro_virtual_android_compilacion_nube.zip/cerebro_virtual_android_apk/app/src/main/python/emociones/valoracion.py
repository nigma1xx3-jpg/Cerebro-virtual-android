"""Valoración afectiva aproximada basada en léxico; no interpreta emociones humanas."""
import re
import unicodedata

POSITIVAS = {"feliz", "alegria", "bien", "contento", "tranquilo", "amor", "excelente", "logro", "gracias", "genial"}
NEGATIVAS = {"triste", "miedo", "rabia", "enojo", "angustia", "dolor", "frustrado", "frustrada", "preocupado", "preocupada", "cansado", "cansada"}
AMENAZAS = {"peligro", "amenaza", "agresion", "atacar", "violencia", "intimidacion", "golpear"}
NEGADORES = {"no", "nunca", "jamas", "sin", "tampoco"}


def _tokens(texto):
    texto = unicodedata.normalize("NFD", str(texto).casefold())
    texto = "".join(c for c in texto if unicodedata.category(c) != "Mn")
    return re.findall(r"\w+", texto)


def valorar(texto):
    tokens = _tokens(texto)
    valencia = 0
    activadores_amenaza = []
    for indice, palabra in enumerate(tokens):
        # Alcance heurístico de negación limitado a las tres palabras anteriores.
        negado = any(t in NEGADORES for t in tokens[max(0, indice - 3):indice])
        if palabra in POSITIVAS:
            valencia += -1 if negado else 1
        elif palabra in NEGATIVAS:
            valencia += 1 if negado else -1
        if palabra in AMENAZAS and not negado:
            activadores_amenaza.append(palabra)
    intensidad = min(abs(valencia) * 25, 100)
    amenaza = bool(activadores_amenaza)
    return {
        "valencia": valencia,
        "intensidad": intensidad,
        "amenaza": amenaza,
        "relevancia": min(20 + intensidad // 2 + (30 if amenaza else 0), 100),
        "activadores_amenaza": activadores_amenaza,
        "metodo": "lexico_heuristico",
        "requiere_contexto": True,
    }
