from datetime import datetime


class Planificador:
    """Propone planes de texto; no ejecuta herramientas ni acciones externas."""

    def crear_plan(self, objetivo, pasos=None):
        if not isinstance(objetivo, str) or not 3 <= len(objetivo.strip()) <= 500:
            return {
                "estado": "objetivo_invalido", "objetivo": objetivo,
                "pasos": [], "requiere_confirmacion": True, "ejecutado": False,
            }
        if isinstance(pasos, str):
            pasos = [pasos]
        elif pasos is None:
            pasos = []
        elif not isinstance(pasos, (list, tuple)):
            pasos = []
        pasos_limpios = []
        for paso in pasos:
            if isinstance(paso, str) and paso.strip():
                descripcion = paso.strip()[:500]
                if descripcion not in [p["descripcion"] for p in pasos_limpios]:
                    pasos_limpios.append({"descripcion": descripcion, "estado": "pendiente"})
            if len(pasos_limpios) >= 30:
                break
        return {
            "fecha": datetime.now().isoformat(),
            "objetivo": objetivo.strip(),
            "pasos": pasos_limpios,
            "estado": "propuesto" if pasos_limpios else "necesita_descomposicion",
            "requiere_confirmacion": True,
            "ejecutado": False,
            "limite": "El planificador solo propone; no ejecuta acciones.",
        }
