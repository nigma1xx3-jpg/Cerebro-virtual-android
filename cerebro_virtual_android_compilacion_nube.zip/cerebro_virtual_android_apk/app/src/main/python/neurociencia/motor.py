"""Consulta local de la base educativa de neurociencia.

La búsqueda es léxica y explicable; no es un modelo semántico ni una fuente clínica.
"""
from __future__ import annotations
import json
import re
import unicodedata
from pathlib import Path

_ARCHIVO = Path(__file__).resolve().parent / "conocimientos.json"
_STOPWORDS = {"no", "existe", "xyz", "qqq", "el", "la", "los", "las", "de", "del", "y", "o", "un", "una", "en", "por", "para", "con", "que", "es", "son", "se", "al"}

def _tokens(texto: str) -> set[str]:
    texto = unicodedata.normalize("NFD", str(texto).casefold())
    texto = "".join(c for c in texto if unicodedata.category(c) != "Mn")
    return set(re.findall(r"[a-z0-9]+", texto))

def cargar_base() -> dict:
    with _ARCHIVO.open("r", encoding="utf-8") as f:
        base = json.load(f)
    if not isinstance(base, dict) or not isinstance(base.get("entradas"), list):
        raise ValueError("Base de neurociencia inválida.")
    return base

def consultar(consulta: str, limite: int = 5) -> list[dict]:
    if not isinstance(consulta, str) or not consulta.strip():
        return []
    if type(limite) is not int or not 1 <= limite <= 20:
        return []
    tokens = _tokens(consulta) - _STOPWORDS
    if not tokens:
        return []
    resultados = []
    for entrada in cargar_base()["entradas"]:
        texto = " ".join([
            entrada.get("tema", ""), entrada.get("area", ""),
            entrada.get("resumen", ""), entrada.get("detalle", ""),
            " ".join(entrada.get("conceptos", []))
        ])
        palabras = _tokens(texto)
        coincidencias = sorted(tokens & palabras)
        if not coincidencias:
            continue
        cobertura = len(coincidencias) / len(tokens)
        precision = len(coincidencias) / max(1, len(palabras))
        puntuacion = round(0.8 * cobertura + 0.2 * precision, 4)
        resultados.append({
            "id": entrada["id"], "tema": entrada["tema"],
            "area": entrada["area"], "puntuacion_lexica": puntuacion,
            "coincidencias": coincidencias, "resumen": entrada["resumen"],
            "detalle": entrada["detalle"], "cautela": entrada["cautela"],
            "referencias": entrada["referencias"]
        })
    resultados.sort(key=lambda x: (x["puntuacion_lexica"], len(x["coincidencias"])), reverse=True)
    return resultados[:limite]

def obtener_por_id(identificador: str) -> dict | None:
    if not isinstance(identificador, str):
        return None
    return next((e for e in cargar_base()["entradas"] if e.get("id") == identificador), None)

def resumen_base() -> dict:
    base = cargar_base()
    areas = sorted({e.get("area", "sin_area") for e in base["entradas"]})
    return {"version": base.get("version"), "cantidad_entradas": len(base["entradas"]), "areas": areas}
