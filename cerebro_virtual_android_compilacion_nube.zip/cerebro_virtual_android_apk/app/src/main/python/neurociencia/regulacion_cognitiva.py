"""Mecanismos cognitivos inspirados en neurociencia, implementados como heurísticas.

No simula tejido cerebral ni infiere estados clínicos. Produce metadatos explicables
para apoyar el ciclo cognitivo y mantiene la memoria de trabajo acotada.
"""
from __future__ import annotations
import json
import re
from pathlib import Path
from datetime import datetime, timezone

_ESTADO = Path(__file__).resolve().parent / "estado_cognitivo.json"
_MAX_ELEMENTOS = 7
_MAX_CARACTERES = 1200


def _leer_estado():
    try:
        data = json.loads(_ESTADO.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {"memoria_trabajo": []}
    except (OSError, json.JSONDecodeError):
        return {"memoria_trabajo": []}


def _guardar_estado(data):
    _ESTADO.parent.mkdir(parents=True, exist_ok=True)
    temporal = _ESTADO.with_suffix(".tmp")
    temporal.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temporal.replace(_ESTADO)


def evaluar(texto: str, emocion=None, razonamiento=None, persistir=True) -> dict:
    """Evalúa atención/carga/novelty y actualiza un buffer breve de contexto."""
    if not isinstance(texto, str) or not texto.strip():
        return {"estado": "sin_entrada", "limitaciones": ["No hay texto para evaluar."]}
    emocion = emocion if isinstance(emocion, dict) else {}
    razonamiento = razonamiento if isinstance(razonamiento, dict) else {}
    palabras = re.findall(r"\w+", texto.casefold(), flags=re.UNICODE)
    longitud = len(palabras)
    carga = "baja" if longitud < 35 else "media" if longitud < 110 else "alta"
    puntuacion_saliencia = 0
    for clave in ("relevancia", "intensidad", "valencia"):
        valor = emocion.get(clave)
        if isinstance(valor, (int, float)):
            puntuacion_saliencia += min(30, max(0, abs(valor)))
    tokens = set(palabras)
    estado = _leer_estado()
    buffer = estado.get("memoria_trabajo", [])
    if not isinstance(buffer, list):
        buffer = []
    anteriores = set()
    for item in buffer:
        if isinstance(item, dict):
            anteriores.update(re.findall(r"\w+", str(item.get("texto", "")).casefold()))
    novedad = len(tokens - anteriores) / max(1, len(tokens))
    confianza = razonamiento.get("confianza")
    incertidumbre = None
    if isinstance(confianza, (int, float)):
        incertidumbre = round(1 - min(100, max(0, confianza)) / 100, 3)
    item = {"texto": texto[:_MAX_CARACTERES], "registrado_utc": datetime.now(timezone.utc).isoformat()}
    nuevo_buffer = (buffer + [item])[-_MAX_ELEMENTOS:]
    if persistir:
        _guardar_estado({"version": 1, "memoria_trabajo": nuevo_buffer})
    return {
        "modelo": "heuristico_inspirado_en_neurociencia",
        "atencion": {"saliencia_textual": min(100, puntuacion_saliencia), "novedad_lexica": round(novedad, 3)},
        "memoria_trabajo": {"elementos_en_buffer": len(nuevo_buffer), "capacidad_maxima_configurada": _MAX_ELEMENTOS, "politica": "ventana_reciente_con_limite"},
        "carga_cognitiva_estimada": carga,
        "incertidumbre_heuristica": incertidumbre,
        "prediccion_y_error": {"estado": "no_calculado", "motivo": "No existe un modelo generativo validado de expectativas para esta entrada."},
        "consolidacion": {"estado": "pendiente_de_revision", "politica": "No consolidar como aprendizaje validado sin feedback explícito."},
        "limitaciones": [
            "No representa neuronas, neurotransmisores ni actividad cerebral real.",
            "La saliencia y la carga son aproximaciones basadas en texto, no mediciones fisiológicas.",
            "No infiere sueño, estrés, dolor, diagnósticos ni estados mentales privados.",
            "La memoria de trabajo es un buffer técnico, no memoria humana.",
        ],
    }


def reiniciar_memoria_trabajo() -> dict:
    """Vacía solo el buffer técnico de memoria de trabajo; no toca recuerdos autobiográficos."""
    _guardar_estado({"version": 1, "memoria_trabajo": []})
    return {"reiniciada": True, "recuerdos_autobiograficos_afectados": False}
