"""Base educativa de neurociencia para Cerebro Virtual."""
