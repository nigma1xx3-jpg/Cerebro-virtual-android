"""Registro de predicciones y evaluación posterior basada en resultados explícitos."""
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4
from nucleo.almacenamiento import ruta_proyecto, cargar_json, guardar_json_atomico

class Calibrador:
    def __init__(self, archivo=None):
        self.archivo = Path(archivo) if archivo else ruta_proyecto("prediccion", "historial.json")
        self.archivo.parent.mkdir(parents=True, exist_ok=True)

    def _cargar(self):
        datos = cargar_json(self.archivo, [])
        if not isinstance(datos, list):
            raise ValueError("Historial predictivo inválido; se preservan los datos.")
        return datos

    def registrar(self, prediccion, confianza, contexto=""):
        if not isinstance(prediccion, str) or not prediccion.strip():
            return {"registrada": False, "motivo": "prediccion_vacia"}
        try: confianza = max(0.0, min(100.0, float(confianza)))
        except (TypeError, ValueError): return {"registrada": False, "motivo": "confianza_invalida"}
        datos = self._cargar()
        item = {"id": str(uuid4()), "fecha_utc": datetime.now(timezone.utc).isoformat(),
                "prediccion": prediccion.strip()[:2000], "confianza": confianza,
                "contexto": str(contexto)[:2000], "resultado_observado": None,
                "evaluada": False}
        datos.append(item); guardar_json_atomico(self.archivo, datos, copia_seguridad=True)
        return {"registrada": True, **item}

    def evaluar(self, referencia, resultado_observado, acierto):
        if not isinstance(resultado_observado, str) or not resultado_observado.strip() or type(acierto) is not bool:
            return False
        datos = self._cargar()
        item = next((x for x in datos if isinstance(x, dict) and x.get("id") == str(referencia)), None)
        if item is None: return False
        item.update({"resultado_observado": resultado_observado.strip()[:2000],
                     "acierto": acierto, "evaluada": True,
                     "fecha_evaluacion_utc": datetime.now(timezone.utc).isoformat()})
        guardar_json_atomico(self.archivo, datos, copia_seguridad=True)
        return True

    def resumen(self):
        datos = self._cargar(); evaluadas = [x for x in datos if isinstance(x, dict) and x.get("evaluada")]
        return {"predicciones": len(datos), "evaluadas": len(evaluadas),
                "aciertos": sum(x.get("acierto") is True for x in evaluadas),
                "precision_observada": (round(sum(x.get("acierto") is True for x in evaluadas)/len(evaluadas), 3) if evaluadas else None),
                "nota": "La precisión observada no es una probabilidad calibrada si la muestra es pequeña o sesgada."}
