"""Predicción y evaluación de resultados."""
