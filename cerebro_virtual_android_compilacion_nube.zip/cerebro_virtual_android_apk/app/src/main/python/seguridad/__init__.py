"""Validaciones defensivas de entrada y almacenamiento."""
