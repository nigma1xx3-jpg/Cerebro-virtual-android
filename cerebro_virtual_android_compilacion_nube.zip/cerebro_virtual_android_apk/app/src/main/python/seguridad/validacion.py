import unicodedata
"""Validación defensiva de entradas textuales."""
MAX_LONGITUD_ENTRADA = 4000


def validar_texto(texto, max_longitud=MAX_LONGITUD_ENTRADA):
    if not isinstance(texto, str):
        return {"valido": False, "motivo": "tipo_no_textual", "texto": ""}
    limpio = texto.strip()
    if not limpio:
        return {"valido": False, "motivo": "entrada_vacia", "texto": ""}
    if len(limpio) > max_longitud:
        return {"valido": False, "motivo": "entrada_demasiado_larga", "texto": ""}
    if any(unicodedata.category(c) in {"Cc", "Cf", "Cs"} and c not in "\n\t\r" for c in limpio):
        return {"valido": False, "motivo": "caracteres_de_control", "texto": ""}
    return {"valido": True, "motivo": None, "texto": limpio}
