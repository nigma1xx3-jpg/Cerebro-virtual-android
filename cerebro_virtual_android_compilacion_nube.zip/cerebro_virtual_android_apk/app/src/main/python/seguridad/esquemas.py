"""Validación estructural de los almacenes JSON del proyecto."""
from __future__ import annotations
import json
from nucleo.almacenamiento import ruta_proyecto

ESQUEMAS = {
    "memoria/recuerdos.json": list,
    "memoria/conocimientos.json": dict,
    "memoria/asociaciones.json": list,
    "aprendizaje/experiencias.json": list,
}


def validar_archivos_datos():
    resultados = {}
    advertencias = []
    for relativo, tipo in ESQUEMAS.items():
        ruta = ruta_proyecto(*relativo.split("/"))
        try:
            with ruta.open("r", encoding="utf-8") as archivo:
                datos = json.load(archivo)
        except FileNotFoundError:
            resultados[relativo] = {"estado": "no_existe"}
            continue
        except (json.JSONDecodeError, OSError) as exc:
            resultados[relativo] = {"estado": "ilegible", "detalle": type(exc).__name__}
            continue
        if not isinstance(datos, tipo):
            resultados[relativo] = {"estado": "tipo_incorrecto", "esperado": tipo.__name__}
            continue
        registros = datos.values() if isinstance(datos, dict) else datos
        total = 0
        estructuras_invalidas = 0
        for registro in registros:
            total += 1
            if relativo == "memoria/recuerdos.json":
                valido = isinstance(registro, dict) and bool(registro.get("contenido"))
            elif relativo == "memoria/conocimientos.json":
                valido = isinstance(registro, (str, dict))
            elif relativo == "memoria/asociaciones.json":
                valido = isinstance(registro, dict) and all(registro.get(k) for k in ("origen", "relacion", "destino"))
            else:
                valido = isinstance(registro, dict) and bool(registro.get("pensamiento") or registro.get("evento"))
            if not valido:
                estructuras_invalidas += 1
        resultados[relativo] = {
            "estado": "ok" if estructuras_invalidas == 0 else "advertencia_estructura",
            "registros": total,
            "registros_irregulares": estructuras_invalidas,
        }
        if estructuras_invalidas:
            advertencias.append(f"{relativo}: {estructuras_invalidas} registros con estructura heredada o irregular; se conservan.")
    estado = "correcto" if all(x.get("estado") == "ok" for x in resultados.values()) else "requiere_revision"
    return {"estado": estado, "archivos": resultados, "advertencias": advertencias}
