"""Arranque Android: configura datos privados y levanta la API local."""
from __future__ import annotations
import os
import socket
import threading
import time
from pathlib import Path

_server_thread = None

def start(data_dir: str):
    global _server_thread
    data_root = Path(data_dir) / "cerebro_virtual_data"
    data_root.mkdir(parents=True, exist_ok=True)
    os.environ["CV_DATA_DIR"] = str(data_root)

    from interfaz import servidor
    if _server_thread is None or not _server_thread.is_alive():
        _server_thread = threading.Thread(
            target=servidor.start_server,
            name="CV-Local-API",
            daemon=True,
        )
        _server_thread.start()

    deadline = time.time() + 20
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", 8765), timeout=0.5):
                return {"ok": True, "data_dir": str(data_root), "server": "ready"}
        except OSError:
            time.sleep(0.2)
    raise RuntimeError("El servidor local no respondió en 20 segundos.")
