"""Traduce resultados reales de los módulos a señales de la red cognitiva."""
from red_neuronal.red import RedNeuronalCognitiva


def _unidad(valor, defecto=0.0):
    try:
        return max(0.0, min(1.0, float(valor)))
    except (TypeError, ValueError):
        return defecto


def activar_red_cognitiva(procesamiento, atencion=None, regulacion=None,
                          metacognicion=None, aprendizaje=None, planificacion=None,
                          integridad=None, memoria_asociativa=None):
    procesamiento = procesamiento if isinstance(procesamiento, dict) else {}
    razonamiento = procesamiento.get("razonamiento", {})
    razonamiento = razonamiento if isinstance(razonamiento, dict) else {}
    motor = razonamiento.get("razonamiento", {})
    motor = motor if isinstance(motor, dict) else {}
    emocion = procesamiento.get("estado_emocional", {})
    emocion = emocion if isinstance(emocion, dict) else {}
    atencion = atencion if isinstance(atencion, dict) else {}
    regulacion = regulacion if isinstance(regulacion, dict) else {}
    metacognicion = metacognicion if isinstance(metacognicion, dict) else {}
    aprendizaje = aprendizaje if isinstance(aprendizaje, dict) else {}
    planificacion = planificacion if isinstance(planificacion, dict) else {}
    integridad = integridad if isinstance(integridad, list) else []
    memoria_asociativa = memoria_asociativa if isinstance(memoria_asociativa, dict) else {}

    recuerdos = razonamiento.get("recuerdos", [])
    conocimientos = razonamiento.get("conocimientos", [])
    asociaciones = razonamiento.get("asociaciones", [])
    asociaciones = asociaciones if isinstance(asociaciones, list) else []
    confianza = motor.get("confianza", 0)
    try:
        confianza = _unidad(float(confianza or 0) / 100.0)
    except (TypeError, ValueError):
        confianza = 0.0
    activaciones = {
        "percepcion": 1.0 if procesamiento.get("entrada") else 0.0,
        "atencion": _unidad(atencion.get("prioridad", 0) / 100.0),
        "memoria_trabajo": _unidad(
            regulacion.get("memoria_trabajo", {}).get("elementos_en_buffer", 0) / 7.0
            if isinstance(regulacion.get("memoria_trabajo"), dict) else 0
        ),
        "memoria_episodica": _unidad(min(1.0, len(recuerdos) / 5.0)),
        "memoria_semantica": _unidad(min(1.0, len(conocimientos) / 5.0)),
        "memoria_asociativa": _unidad(min(1.0, (len(asociaciones) + len(memoria_asociativa.get("activadas", []))) / 5.0)),
        "emocion": _unidad(emocion.get("relevancia", 0) / 100.0),
        "razonamiento": 1.0 if motor else 0.0,
        "metacognicion": 1.0 if metacognicion else 0.0,
        "control_ejecutivo": 0.25,
        "planificacion": 1.0 if planificacion.get("estado") == "propuesto" else 0.15,
        "prediccion": 0.2,
        "aprendizaje": 0.65 if aprendizaje.get("id") else 0.0,
        "integridad": _unidad(
            sum(1 for x in integridad if x.get("valido")) / max(1, len(integridad))
            if integridad else 0.25
        ),
    }
    red = RedNeuronalCognitiva()
    return red.propagar(activaciones, rondas=3)
