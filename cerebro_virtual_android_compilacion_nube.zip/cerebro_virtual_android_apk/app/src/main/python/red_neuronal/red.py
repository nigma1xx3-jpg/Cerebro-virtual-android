"""Red funcional de neuronas computacionales y sinapsis entre módulos.

Cada neurona representa un subsistema de software, no una neurona biológica.
La propagación transmite activación por conexiones dirigidas y ponderadas.
La plasticidad solo cambia pesos con feedback explícito y validado.
"""
from __future__ import annotations

from pathlib import Path
from nucleo.almacenamiento import ruta_proyecto, cargar_json, guardar_json_atomico

NEURONAS = (
    "percepcion", "atencion", "memoria_trabajo", "memoria_episodica",
    "memoria_semantica", "emocion", "razonamiento", "metacognicion",
    "control_ejecutivo", "planificacion", "prediccion", "aprendizaje",
    "integridad", "memoria_asociativa",
)

SINAPSIS_BASE = (
    ("percepcion", "atencion", 0.95),
    ("percepcion", "memoria_trabajo", 0.72),
    ("atencion", "memoria_trabajo", 0.90),
    ("atencion", "memoria_episodica", 0.58),
    ("memoria_trabajo", "memoria_episodica", 0.72),
    ("memoria_trabajo", "memoria_semantica", 0.68),
    ("memoria_episodica", "razonamiento", 0.88),
    ("memoria_semantica", "razonamiento", 0.90),
    ("emocion", "atencion", 0.52),
    ("emocion", "control_ejecutivo", 0.48),
    ("razonamiento", "metacognicion", 0.94),
    ("integridad", "metacognicion", 0.76),
    ("metacognicion", "control_ejecutivo", 0.88),
    ("control_ejecutivo", "planificacion", 0.92),
    ("planificacion", "prediccion", 0.72),
    ("prediccion", "metacognicion", 0.62),
    ("metacognicion", "aprendizaje", 0.82),
    ("aprendizaje", "memoria_episodica", 0.66),
    ("aprendizaje", "memoria_semantica", 0.64),
    ("control_ejecutivo", "atencion", 0.44),
    ("memoria_episodica", "memoria_asociativa", 0.70),
    ("memoria_semantica", "memoria_asociativa", 0.91),
    ("memoria_asociativa", "razonamiento", 0.86),
)

class RedNeuronalCognitiva:
    def __init__(self, archivo=None):
        self.archivo = Path(archivo) if archivo else ruta_proyecto("red_neuronal", "sinapsis.json")
        self.archivo.parent.mkdir(parents=True, exist_ok=True)
        self.neuronas = tuple(NEURONAS)
        self.pesos = {(a, b): float(w) for a, b, w in SINAPSIS_BASE}
        self._cargar_pesos()

    def _cargar_pesos(self):
        datos = cargar_json(self.archivo, {})
        if not isinstance(datos, dict):
            return
        for clave, peso in datos.items():
            if not isinstance(clave, str) or "->" not in clave:
                continue
            origen, destino = clave.split("->", 1)
            try:
                valor = float(peso)
            except (TypeError, ValueError):
                continue
            if (origen, destino) in self.pesos and 0.05 <= valor <= 0.99:
                self.pesos[(origen, destino)] = valor

    def resumen(self):
        """Devuelve topología y salud básica de la red, sin alterar sus pesos."""
        conexiones = [
            {"origen": a, "destino": b, "peso": round(w, 4)}
            for (a, b), w in sorted(self.pesos.items())
        ]
        nodos_conectados = {x for par in self.pesos for x in par}
        return {
            "neuronas": len(self.neuronas),
            "sinapsis": len(self.pesos),
            "neuronas_aisladas": sorted(set(self.neuronas) - nodos_conectados),
            "peso_minimo": round(min(self.pesos.values()), 4) if self.pesos else None,
            "peso_maximo": round(max(self.pesos.values()), 4) if self.pesos else None,
            "peso_medio": round(sum(self.pesos.values()) / len(self.pesos), 4) if self.pesos else None,
            "topologia_valida": all(
                a in self.neuronas and b in self.neuronas and 0.05 <= w <= 0.99
                for (a, b), w in self.pesos.items()
            ) and bool(self.pesos),
            "conexiones": conexiones,
        }

    def propagar(self, activaciones, rondas=3, umbral=0.05):
        if not isinstance(activaciones, dict):
            raise TypeError("activaciones debe ser un diccionario")
        if type(rondas) is not int or not 1 <= rondas <= 5:
            raise ValueError("rondas debe estar entre 1 y 5")
        estado = {n: 0.0 for n in self.neuronas}
        for nombre, valor in activaciones.items():
            if nombre not in estado:
                continue
            try:
                estado[nombre] = max(0.0, min(1.0, float(valor)))
            except (TypeError, ValueError):
                continue
        inicial = dict(estado)
        rutas = {}
        for ronda in range(1, rondas + 1):
            aportes = {n: [] for n in self.neuronas}
            for (origen, destino), peso in self.pesos.items():
                senal = estado[origen] * peso
                if senal >= umbral:
                    aportes[destino].append(senal)
                    rutas[(origen, destino)] = {
                        "origen": origen, "destino": destino,
                        "peso": round(peso, 4),
                        "activacion_transmitida": round(senal, 4),
                        "ronda": ronda,
                    }
            siguiente = dict(estado)
            for destino, valores in aportes.items():
                if valores:
                    combinado = 1.0
                    for valor in valores:
                        combinado *= (1.0 - valor)
                    combinado = 1.0 - combinado
                    siguiente[destino] = max(estado[destino], combinado)
            estado = siguiente
        return {
            "modelo": "red_funcional_dirigida_ponderada",
            "naturaleza": "neurona_computacional_no_biologica",
            "rondas": rondas,
            "neuronas": {k: round(v, 4) for k, v in estado.items()},
            "activaciones_iniciales": {k: round(v, 4) for k, v in inicial.items() if v > 0},
            "sinapsis_activas": sorted(rutas.values(), key=lambda x: (x["ronda"], -x["activacion_transmitida"])),
            "cantidad_sinapsis_activas": len(rutas),
            "limitacion": "La activación es una señal computacional heurística; no representa actividad neuronal biológica.",
        }

    def reforzar_sinapsis(self, origen, destino, resultado_validado, tasa=0.02):
        """Plasticidad acotada: exige feedback explícito (True/False), nunca inferido."""
        if type(resultado_validado) is not bool:
            return {"actualizada": False, "motivo": "feedback_explicito_requerido"}
        clave = (origen, destino)
        if clave not in self.pesos:
            return {"actualizada": False, "motivo": "sinapsis_inexistente"}
        try:
            tasa = float(tasa)
        except (TypeError, ValueError):
            return {"actualizada": False, "motivo": "tasa_invalida"}
        if not 0 < tasa <= 0.1:
            return {"actualizada": False, "motivo": "tasa_fuera_de_rango"}
        anterior = self.pesos[clave]
        nuevo = anterior + tasa * (1.0 - anterior) if resultado_validado else anterior * (1.0 - tasa)
        nuevo = round(max(0.05, min(0.99, nuevo)), 6)
        self.pesos[clave] = nuevo
        datos = {f"{a}->{b}": w for (a, b), w in sorted(self.pesos.items())}
        guardar_json_atomico(self.archivo, datos, copia_seguridad=True)
        return {"actualizada": True, "origen": origen, "destino": destino,
                "peso_anterior": anterior, "peso_nuevo": nuevo,
                "procedencia": "feedback_explicito_validado"}
