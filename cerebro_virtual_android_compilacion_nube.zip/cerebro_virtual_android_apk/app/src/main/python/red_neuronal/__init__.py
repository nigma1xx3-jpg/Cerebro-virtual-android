"""Red funcional de activación entre subsistemas cognitivos."""
from .red import RedNeuronalCognitiva
