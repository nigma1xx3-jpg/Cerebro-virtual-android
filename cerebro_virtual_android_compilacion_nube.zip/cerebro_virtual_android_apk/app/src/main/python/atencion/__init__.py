"""Atención selectiva explicable."""
