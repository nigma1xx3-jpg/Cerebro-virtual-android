"""Priorización heurística de entradas; no representa atención biológica."""
from memoria.recuperacion import normalizar_tokens


def evaluar(texto, objetivo=None, contexto=None):
    if not isinstance(texto, str) or not texto.strip():
        return {"prioridad": 0, "tokens_relevantes": [], "motivo": "entrada_vacia"}
    tokens = normalizar_tokens(texto)
    objetivo_tokens = set(normalizar_tokens(objetivo or ""))
    contexto_tokens = set(normalizar_tokens(" ".join(contexto or [])))
    relevantes = sorted(set(tokens) & (objetivo_tokens | contexto_tokens))
    cobertura_objetivo = len(set(tokens) & objetivo_tokens) / max(1, len(objetivo_tokens))
    novedad = len(set(tokens) - contexto_tokens) / max(1, len(set(tokens)))
    prioridad = min(100, round(55 * cobertura_objetivo + 30 * novedad + min(15, len(set(tokens)))))
    return {"prioridad": prioridad, "tokens_relevantes": relevantes,
            "cobertura_objetivo": round(cobertura_objetivo, 3), "novedad": round(novedad, 3),
            "motivo": "heuristica_lexica_explicable", "limitacion": "No equivale a atención humana."}
