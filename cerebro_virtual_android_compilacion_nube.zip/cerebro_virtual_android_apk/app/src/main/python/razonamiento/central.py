"""Coordinador de recuperación y razonamiento prudente."""
from memoria.semantica import recuperar_conocimientos, recuperar_asociaciones
from memoria.episodica import recuperar_recuerdos
from memoria.recuperacion import recuperar_contextuales
from memoria.semantica_profunda import buscar_semanticamente
from memoria.gobernanza import evaluar_registro
from razonamiento.motor import razonar
from emociones.valoracion import valorar


def buscar_coincidencias(entrada, datos, limite=8):
    if isinstance(datos, dict):
        registros = [{"concepto": concepto, "informacion": informacion}
                     for concepto, informacion in datos.items()]
    elif isinstance(datos, list):
        registros = datos
    else:
        return []
    elegibles = []
    politicas = {}
    for posicion, registro in enumerate(registros):
        politica = evaluar_registro(registro)
        if politica["recuperable"]:
            elegibles.append(registro)
            politicas[id(registro)] = politica
    encontrados = buscar_semanticamente(
        entrada, elegibles, limite=max(limite * 2, limite), umbral=0.10
    )
    salida = []
    for item in encontrados:
        registro = item["registro"]
        politica = politicas.get(id(registro), evaluar_registro(registro))
        puntuacion_ponderada = round(item["puntuacion"] * politica["peso"], 4)
        if puntuacion_ponderada < 0.10:
            continue
        if isinstance(registro, dict):
            salida.append({**registro,
                "_relevancia_lexica": item["puntuacion"],
                "_relevancia_semantica": item["puntuacion"],
                "_similitud_vectorial": item["similitud_vectorial"],
                "_metodo_recuperacion": item["metodo"],
                "_relevancia_ponderada": puntuacion_ponderada,
                "_coincidencias": item["coincidencias"],
                "_estado_verificacion": politica["estado_verificacion"],
                "_procedencia": politica.get("procedencia", "legado_sin_procedencia"),
                "_fuente_independiente": politica.get("fuente_independiente"),
            })
        else:
            salida.append({"contenido": str(registro),
                "_relevancia_lexica": item["puntuacion"],
                "_relevancia_semantica": item["puntuacion"],
                "_similitud_vectorial": item["similitud_vectorial"],
                "_metodo_recuperacion": item["metodo"],
                "_relevancia_ponderada": puntuacion_ponderada,
                "_coincidencias": item["coincidencias"],
                "_estado_verificacion": politica["estado_verificacion"],
                "_procedencia": politica.get("procedencia", "legado_sin_procedencia"),
                "_fuente_independiente": politica.get("fuente_independiente"),
            })
        if len(salida) >= limite:
            break
    return salida


def analizar(entrada, valoracion=None, experiencias_relacionadas=None):
    entrada_original = str(entrada).strip() if entrada is not None else ""
    if not entrada_original:
        return {"entrada": "", "valoracion_emocional": None, "conocimientos": [],
                "recuerdos": [], "asociaciones": [], "razonamiento": None,
                "respuesta": "No se recibió información.", "limitaciones": ["entrada_vacia"]}
    emocion = valoracion if isinstance(valoracion, dict) else valorar(entrada_original)
    conceptos = buscar_coincidencias(entrada_original, recuperar_conocimientos())
    recuerdos = buscar_coincidencias(entrada_original, recuperar_recuerdos())
    asociaciones = buscar_coincidencias(entrada_original, recuperar_asociaciones())
    aprendizajes = []
    for item in experiencias_relacionadas or []:
        experiencia = item.get("experiencia", item) if isinstance(item, dict) else item
        if isinstance(experiencia, dict):
            registro = dict(experiencia)
            registro["_relevancia_ponderada"] = item.get("similitud", 0) if isinstance(item, dict) else 0
            registro["_procedencia"] = "feedback_usuario" if registro.get("validada") else "aprendizaje_local"
            registro["_estado_verificacion"] = registro.get("estado_aprendizaje", "pendiente_feedback")
            aprendizajes.append(registro)
    analisis = {"entrada": entrada_original, "valoracion_emocional": emocion,
                "conocimientos": conceptos, "recuerdos": recuerdos,
                "asociaciones": asociaciones, "aprendizajes": aprendizajes}
    resultado = razonar(analisis)
    conclusiones = resultado.get("conclusiones", []) or ["No hay evidencias suficientes para concluir."]
    return {**analisis, "razonamiento": resultado, "respuesta": " ".join(conclusiones),
            "recuperacion": {"metodo": "recuperacion_semantica_hibrida_tfidf_expandida_con_gobernanza",
                "cantidad": len(conceptos) + len(recuerdos) + len(asociaciones) + len(aprendizajes),
                "limitacion": "Vectorización TF-IDF local con expansión conceptual española; no usa embeddings neuronales contextuales."}}


def estado_cognitivo():
    return {
        "percepcion": "validacion_textual_basica",
        "memoria_episodica": "persistencia_json_atomica",
         "memoria_semantica": "persistencia_json_atomica_y_recuperacion_hibrida_tfidf_coseno_expandido_espanol",
        "memoria_asociativa": "recuperacion_semantica_hibrida_ponderada_con_filtro_de_calidad",
        "gobernanza_memoria": "filtrado_de_entradas_corruptas_y_etiquetado_de_procedencia",
        "valoracion_emocional": "lexico_heuristico",
        "motor_razonamiento": "reglas_heuristicas_con_control_de_dependencia_de_fuentes",
        "coordinador_central": "integracion_local",
    }
