# CEREBRO VIRTUAL
# Motor de razonamiento 2.0

def razonar(analisis):

    if not isinstance(analisis, dict):
        analisis = {}

    conocimientos = analisis.get("conocimientos", [])
    recuerdos = analisis.get("recuerdos", [])
    asociaciones = analisis.get("asociaciones", [])

    evidencias = []
    hipotesis = []
    conclusiones = []
    advertencias = []
    contradicciones = []

    # 1. Normalizar entradas y mantener procedencia/estado de cada evidencia.
    fuentes = [
        ("observacion", analisis.get("entrada")),
        ("conocimiento", conocimientos),
        ("experiencia", recuerdos),
        ("asociacion", asociaciones),
        ("aprendizaje", analisis.get("aprendizajes", [])),
    ]
    for tipo, datos in fuentes:
        if datos is None:
            continue
        if isinstance(datos, dict):
            elementos = [{"concepto": k, "informacion": v} for k, v in datos.items()]
        elif isinstance(datos, (list, tuple, set)):
            elementos = list(datos)
        else:
            elementos = [datos]
        for dato in elementos:
            if dato is None:
                continue
            if tipo == "observacion":
                procedencia = "entrada_usuario_actual"
                estado_verificacion = "sin_verificar"
                fuente_independiente = None
            elif isinstance(dato, dict):
                procedencia = dato.get("_procedencia", dato.get("procedencia", "legado_sin_procedencia"))
                estado_verificacion = dato.get("_estado_verificacion", dato.get("estado", "legado_sin_estado"))
                fuente_independiente = dato.get("_fuente_independiente")
            else:
                procedencia = "legado_sin_procedencia"
                estado_verificacion = "legado_sin_estado"
                fuente_independiente = None
            evidencias.append({
                "tipo": tipo,
                "dato": dato,
                "procedencia": procedencia,
                "estado_verificacion": estado_verificacion,
                "fuente_independiente": fuente_independiente,
            })

    fuentes_presentes = {e["tipo"] for e in evidencias}
    fuentes_independientes = sorted({
        e["fuente_independiente"] for e in evidencias
        if isinstance(e.get("fuente_independiente"), str) and e["fuente_independiente"]
    })
    if not evidencias:
        advertencias.append("No hay evidencias disponibles.")
    if "observacion" in fuentes_presentes:
        advertencias.append("La entrada actual procede del usuario y no es un hecho verificado.")
    if fuentes_presentes.intersection({"experiencia", "conocimiento", "asociacion"}):
        advertencias.append("Los recuerdos/conocimientos/asociaciones locales pueden proceder de una misma fuente; no son corroboración independiente por sí solos.")
    if not fuentes_independientes and evidencias:
        advertencias.append("No hay fuentes externas marcadas y validadas de forma independiente.")

    # 3. Generar hipotesis
    for evidencia in evidencias:

        hipotesis.append({
            "origen": evidencia["tipo"],
            "descripcion": str(evidencia["dato"]),
            "estado": "pendiente_de_verificacion"
        })

    # 4. Detectar contradicciones textuales simples.
    # Solo declara contradicción cuando el contenido coincide exactamente
    # tras retirar una negación explícita; no infiere incompatibilidades
    # semánticas complejas como "día" frente a "noche".
    import re
    import unicodedata

    def normalizar(texto):
        texto = str(texto).strip().casefold()
        texto = unicodedata.normalize("NFD", texto)
        texto = "".join(
            c for c in texto if unicodedata.category(c) != "Mn"
        )
        texto = re.sub(r"[^\w\s]", " ", texto)
        return re.sub(r"\s+", " ", texto).strip()

    def extraer_texto(dato):
        if isinstance(dato, dict):
            for clave in ("dato", "contenido", "informacion", "texto", "descripcion"):
                if clave in dato:
                    return extraer_texto(dato[clave])
            return " ".join(
                str(v) for v in dato.values()
                if isinstance(v, (str, int, float))
            )
        return str(dato)

    negaciones = {"no", "nunca", "jamas", "ningun", "ninguna", "ninguno"}

    def separar_negacion(texto):
        palabras = normalizar(texto).split()
        presentes = [p for p in palabras if p in negaciones]
        base = [p for p in palabras if p not in negaciones]
        return " ".join(base), bool(presentes)

    textos = []
    for evidencia in evidencias:
        texto = extraer_texto(evidencia["dato"])
        if texto.strip():
            textos.append(texto)

    for i in range(len(textos)):
        for j in range(i + 1, len(textos)):
            base_a, neg_a = separar_negacion(textos[i])
            base_b, neg_b = separar_negacion(textos[j])
            if base_a and base_a == base_b and neg_a != neg_b:
                contradicciones.append({
                    "dato_1": textos[i],
                    "dato_2": textos[j],
                    "tipo": "contradiccion_textual"
                })

    # 5. Evaluar confianza
    cantidad = len(evidencias)
    diversidad = len(fuentes_presentes)

    # El número de categorías internas no equivale a fuentes independientes.
    # Solo cuentan fuentes marcadas explícitamente como validadas e independientes.
    if cantidad == 0:
        confianza = 0
        estado = "sin_evidencia"
    elif contradicciones:
        confianza = 5
        estado = "contradiccion_detectada"
    elif fuentes_independientes:
        confianza = min(20 + 15 * len(fuentes_independientes), 65)
        estado = "evidencia_con_fuentes_declaradas_independientes"
    elif diversidad > 1:
        confianza = 20
        estado = "evidencia_local_no_independiente"
    else:
        confianza = 15
        estado = "evidencia_limitada_no_verificada"

    calidad_evidencia = confianza
    if contradicciones:
        calidad_evidencia = 0

    requiere_revision = (
        cantidad < 3 or bool(contradicciones) or not fuentes_independientes
        or confianza < 60
    )

    if requiere_revision:
        advertencias.append(
            "Se necesita revisar la informacion antes de concluir."
        )

    # 7. Generar conclusiones prudentes
    if contradicciones:
        conclusiones.append(
            "Existen datos contradictorios que requieren revision."
        )

    elif not evidencias:
        conclusiones.append(
            "No hay informacion suficiente para concluir."
        )

    elif requiere_revision:
        conclusiones.append(
            "Hay indicios disponibles, pero la evidencia es insuficiente."
        )

    else:
        conclusiones.append(
            "Hay informacion de varias fuentes internas, "
            "pero necesita verificacion independiente."
        )

    # 8. Resultado
    return {
        "conclusiones": conclusiones,
        "evidencias": evidencias,
        "hipotesis": hipotesis,
        "advertencias": advertencias,
        "contradicciones": contradicciones,
        "confianza": confianza,
        "calidad_evidencia": calidad_evidencia,
        "estado": estado,
        "requiere_revision": requiere_revision,
        "fuentes_consultadas": sorted(fuentes_presentes),
        "fuentes_independientes": fuentes_independientes,
        "nota_confianza": "Índice heurístico; no es una probabilidad. Las categorías internas no cuentan como corroboración independiente."
    }
