
# CEREBRO VIRTUAL
# Motor de razonamiento 1.0

def razonar(analisis):
    conocimientos = analisis.get("conocimientos", [])
    recuerdos = analisis.get("recuerdos", [])
    asociaciones = analisis.get("asociaciones", [])

    evidencias = []
    conclusiones = []
    advertencias = []

    # 1. Recopilar evidencias
    for dato in conocimientos:
        evidencias.append({
            "tipo": "conocimiento",
            "dato": dato
        })

    for recuerdo in recuerdos:
        evidencias.append({
            "tipo": "experiencia",
            "dato": recuerdo
        })

    for asociacion in asociaciones:
        evidencias.append({
            "tipo": "asociacion",
            "dato": asociacion
        })

    # 2. Evaluar la informacion disponible
    if conocimientos:
        conclusiones.append(
            "Existen conocimientos relacionados."
        )

    if recuerdos:
        conclusiones.append(
            "Existen experiencias relacionadas."
        )

    if asociaciones:
        conclusiones.append(
            "Existen conexiones entre conceptos."
        )

    # 3. Detectar informacion insuficiente
    if not evidencias:
        advertencias.append(
            "No hay evidencias suficientes."
        )

    # 4. Metacognicion basica
    tipos = sum([
        bool(conocimientos),
        bool(recuerdos),
        bool(asociaciones)
    ])

    if tipos == 0:
        confianza = "sin evidencia"
    elif tipos == 1:
        confianza = "limitada"
    else:
        confianza = "requiere verificacion"

    return {
        "conclusiones": conclusiones,
        "evidencias": evidencias,
        "advertencias": advertencias,
        "confianza": confianza
    }
