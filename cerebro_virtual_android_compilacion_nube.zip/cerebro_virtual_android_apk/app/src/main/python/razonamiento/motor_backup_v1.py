
# CEREBRO VIRTUAL
# Motor de razonamiento 2.0

def razonar(analisis):

    conocimientos = analisis.get("conocimientos", [])
    recuerdos = analisis.get("recuerdos", [])
    asociaciones = analisis.get("asociaciones", [])

    evidencias = []
    hipotesis = []
    conclusiones = []
    advertencias = []
    contradicciones = []

    # 1. Recopilar evidencias
    fuentes = [
        ("conocimiento", conocimientos),
        ("experiencia", recuerdos),
        ("asociacion", asociaciones)
    ]

    for tipo, datos in fuentes:
        for dato in datos:
            evidencias.append({
                "tipo": tipo,
                "dato": dato
            })

    # 2. Generar hipotesis iniciales
    if conocimientos:
        hipotesis.append({
            "origen": "conocimiento",
            "descripcion": "La informacion disponible contiene conocimientos relevantes."
        })

    if recuerdos:
        hipotesis.append({
            "origen": "experiencia",
            "descripcion": "Las experiencias anteriores pueden aportar contexto."
        })

    if asociaciones:
        hipotesis.append({
            "origen": "asociacion",
            "descripcion": "Existen posibles conexiones entre conceptos."
        })

    # 3. Detectar posibles contradicciones
    datos_texto = [
        str(e["dato"]).strip().lower()
        for e in evidencias
    ]

    for i in range(len(datos_texto)):
        for j in range(i + 1, len(datos_texto)):
            a = datos_texto[i]
            b = datos_texto[j]

            if a and b and a == b:
                continue

            if (
                ("no " + a) == b
                or ("no " + b) == a
            ):
                contradicciones.append({
                    "dato_1": a,
                    "dato_2": b
                })

    # 4. Evaluar evidencias
    cantidad = len(evidencias)

    if cantidad == 0:
        confianza = 0
        estado = "sin_evidencia"

    elif cantidad == 1:
        confianza = 20
        estado = "evidencia_limitada"

    elif cantidad <= 3:
        confianza = 35
        estado = "requiere_verificacion"

    else:
        confianza = 45
        estado = "evidencia_por_evaluar"

    # 5. Revisar contradicciones
    if contradicciones:
        confianza = min(confianza, 15)
        advertencias.append(
            "Se detectaron posibles contradicciones."
        )

    # 6. Construir conclusiones
    if evidencias:
        conclusiones.append(
            "Existe informacion disponible para analizar."
        )
    else:
        conclusiones.append(
            "No hay evidencias suficientes para concluir."
        )

    if hipotesis:
        conclusiones.append(
            "Se generaron hipotesis que requieren evaluacion."
        )

    # 7. Evaluacion final
    requiere_revision = (
        cantidad == 0
        or cantidad < 4
        or bool(contradicciones)
    )

    if requiere_revision:
        advertencias.append(
            "Se necesita revisar la informacion antes de concluir."
        )

    # 8. Resultado
    return {
        "conclusiones": conclusiones,
        "evidencias": evidencias,
        "hipotesis": hipotesis,
        "contradicciones": contradicciones,
        "advertencias": advertencias,
        "confianza": confianza,
        "estado": estado,
        "requiere_revision": requiere_revision
    }
