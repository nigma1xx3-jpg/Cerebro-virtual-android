"""Servidor local de la interfaz Android del Cerebro Virtual.
Solo escucha en localhost. No expone el motor a la red local.
"""
from __future__ import annotations
import json
import os
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
DATA_ROOT = Path(os.environ.get("CV_DATA_DIR", ROOT))
UI_ROOT = DATA_ROOT / "interfaz"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

HOST = "127.0.0.1"
PORT = int(os.environ.get("CV_PORT", "8765"))

def _json_bytes(data):
    return json.dumps(data, ensure_ascii=False, default=str).encode("utf-8")

def _count_json(rel, default):
    try:
        value = json.loads((ROOT / rel).read_text(encoding="utf-8"))
        return len(value) if isinstance(value, (list, dict)) else 0
    except Exception:
        return default

def api_status():
    from cerebro_version import VERSION
    from nucleo.coordinador import estado_modulos
    from memoria.episodica import recuperar_recuerdos
    try:
        memories = recuperar_recuerdos()
        memory_count = len(memories)
        memory_state = "disponible"
    except Exception as exc:
        memory_count, memory_state = None, "error: " + type(exc).__name__
    modules = estado_modulos()
    return {
        "ok": True,
        "name": "Cerebro Virtual",
        "version": VERSION,
        "state": "local_activo",
        "modules": modules,
        "module_count": len(modules),
        "memory_count": memory_count,
        "memory_state": memory_state,
        "learning_mode": "supervisado",
        "external_actions": False,
        "api": "local_http",
    }

def api_memories(limit=30):
    from memoria.episodica import recuperar_recuerdos
    items = recuperar_recuerdos()
    output = []
    for idx, item in enumerate(reversed(items[-limit:]), 1):
        if isinstance(item, dict):
            output.append({
                "id": item.get("id", f"registro-{len(items)-idx+1}"),
                "date": item.get("fecha", ""),
                "content": item.get("contenido", item.get("evento", str(item)))[:1200],
                "source": item.get("procedencia", "legacy"),
                "status": item.get("estado", "sin_estado"),
            })
        else:
            output.append({"id": f"registro-{idx}", "date": "", "content": str(item)[:1200],
                           "source": "legacy", "status": "sin_estado"})
    return {"ok": True, "count": len(items), "items": output}

def api_diagnostic():
    from nucleo.diagnostico import ejecutar_diagnostico
    result = ejecutar_diagnostico()
    return {"ok": True, "diagnostic": result}

def api_semantic():
    from memoria.semantica_profunda import resumen_motor
    return {"ok": True, "semantic": resumen_motor()}

def api_process(text):
    if not isinstance(text, str) or not text.strip():
        return {"ok": False, "error": "Escribe una consulta."}, 400
    if len(text) > 4000:
        return {"ok": False, "error": "La consulta supera el límite de 4000 caracteres."}, 400
    from nucleo.ciclo_cognitivo import ejecutar_ciclo
    result = ejecutar_ciclo(text.strip())
    if not result.get("ciclo_completado"):
        return {"ok": False, "error": result.get("error", "No se pudo completar el ciclo."),
                "result": result}, 422
    processing = result.get("procesamiento", {})
    reasoning = processing.get("razonamiento", {}) if isinstance(processing, dict) else {}
    motor = reasoning.get("razonamiento", {}) if isinstance(reasoning, dict) else {}
    return {
        "ok": True,
        "answer": reasoning.get("respuesta", "El ciclo terminó sin una respuesta textual."),
        "confidence": motor.get("confianza", 0),
        "reasoning_state": motor.get("estado", "no_disponible"),
        "evidence_count": len(motor.get("evidencias", []) or []),
        "metacognition": result.get("metacognicion", {}),
        "cognitive_load": result.get("regulacion_cognitiva", {}).get("carga_cognitiva_estimada"),
        "learning": result.get("aprendizaje", {}),
        "network": result.get("red_neuronal", {}),
        "warnings": motor.get("advertencias", []) or [],
        "note": "La confianza es heurística, no una probabilidad calibrada.",
    }

class Handler(BaseHTTPRequestHandler):
    server_version = "CerebroVirtualLocal/1.0"
    def _send(self, status, payload, content_type="application/json; charset=utf-8"):
        body = payload if isinstance(payload, bytes) else _json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        try:
            if path == "/":
                page = (UI_ROOT / "index.html").read_bytes()
                self._send(200, page, "text/html; charset=utf-8")
            elif path == "/app.css":
                self._send(200, (UI_ROOT / "app.css").read_bytes(), "text/css; charset=utf-8")
            elif path == "/app.js":
                self._send(200, (UI_ROOT / "app.js").read_bytes(), "application/javascript; charset=utf-8")
            elif path == "/api/status":
                self._send(200, api_status())
            elif path == "/api/memories":
                self._send(200, api_memories())
            elif path == "/api/diagnostic":
                self._send(200, api_diagnostic())
            elif path == "/api/semantic":
                self._send(200, api_semantic())
            elif path == "/api/health":
                self._send(200, {"ok": True, "service": "Cerebro Virtual UI"})
            else:
                self._send(404, {"ok": False, "error": "Ruta no encontrada."})
        except Exception as exc:
            self._send(500, {"ok": False, "error": type(exc).__name__ + ": " + str(exc)})

    def do_POST(self):
        if urlparse(self.path).path != "/api/process":
            self._send(404, {"ok": False, "error": "Ruta no encontrada."})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 12000:
                self._send(400, {"ok": False, "error": "Tamaño de solicitud no válido."})
                return
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            result = api_process(payload.get("text"))
            if isinstance(result, tuple):
                data, status = result
                self._send(status, data)
            else:
                self._send(200, result)
        except Exception as exc:
            self._send(500, {"ok": False, "error": type(exc).__name__ + ": " + str(exc)})

    def log_message(self, fmt, *args):
        print("[UI]", fmt % args)

if __name__ == "__main__":
    print(f"Cerebro Virtual UI disponible en http://{HOST}:{PORT}")
    print("Solo accesible desde este dispositivo (localhost).")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()


def start_server():
    """Inicia el servidor local; se llama desde el puente Android."""
    global _HTTP_SERVER
    _HTTP_SERVER = ThreadingHTTPServer((HOST, PORT), Handler)
    _HTTP_SERVER.daemon_threads = True
    _HTTP_SERVER.serve_forever()

def stop_server():
    """Detiene el servidor local de forma ordenada."""
    global _HTTP_SERVER
    if globals().get("_HTTP_SERVER") is not None:
        _HTTP_SERVER.shutdown()
        _HTTP_SERVER.server_close()
        _HTTP_SERVER = None
