"""Audita la calidad heredada sin alterar ni eliminar recuerdos originales."""
from datetime import datetime, timezone
from nucleo.almacenamiento import ruta_proyecto, guardar_json_atomico
from memoria.episodica import recuperar_recuerdos
from memoria.gobernanza import evaluar_registro


def generar_informe():
    recuerdos=recuperar_recuerdos(); elegibles=[]; excluidos=[]; legados=[]
    for i, r in enumerate(recuerdos):
        p=evaluar_registro(r)
        fila={"indice":i,"fecha":r.get("fecha") if isinstance(r,dict) else None,
              "motivo":p.get("motivo"),"estado_verificacion":p.get("estado_verificacion"),
              "recuperable":p.get("recuperable")}
        (elegibles if p.get("recuperable") else excluidos).append(fila)
        if p.get("recuperable") and p.get("estado_verificacion")=="legado_sin_estado": legados.append(i)
    informe={"generado_utc":datetime.now(timezone.utc).isoformat(),"total":len(recuerdos),
             "recuperables":len(elegibles),"excluidos_solo_de_recuperacion":len(excluidos),
             "legados_sin_estado":legados,"registros_excluidos":excluidos,
             "politica":"No se modifica ni elimina ningún recuerdo; la exclusión afecta solo a recuperación."}
    guardar_json_atomico(ruta_proyecto("memoria","informe_calidad.json"),informe,copia_seguridad=True)
    return informe
