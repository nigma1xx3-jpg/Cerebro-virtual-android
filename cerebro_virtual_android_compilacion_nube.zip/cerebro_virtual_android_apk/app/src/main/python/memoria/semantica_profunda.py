"""Recuperación semántica local híbrida.

Combina TF-IDF/coseno disperso, expansión conceptual española controlada,
normalización morfológica ligera y coincidencia de frases. No usa un LLM ni
afirma comprensión humana; entrega puntuaciones explicables y procedencia.
"""
from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter
from typing import Any

from memoria.recuperacion import normalizar_tokens

# Grupos conservadores de equivalencia aproximada. Son pistas de recuperación,
# no afirmaciones de que las palabras sean idénticas en todos los contextos.
_GRUPOS = (
    ("auto", "automovil", "coche", "carro", "vehiculo"),
    ("computador", "ordenador", "pc", "computadora"),
    ("telefono", "movil", "celular", "smartphone"),
    ("trabajo", "empleo", "labor", "ocupacion"),
    ("casa", "hogar", "vivienda", "domicilio"),
    ("medico", "doctor", "facultativo"),
    ("dinero", "plata", "efectivo", "capital"),
    ("comprar", "adquirir", "obtener"),
    ("ayuda", "apoyo", "asistencia", "auxilio"),
    ("problema", "dificultad", "inconveniente", "obstaculo"),
    ("aprender", "estudiar", "asimilar", "adquirir_conocimiento"),
    ("recordar", "rememorar", "evocar", "memoria"),
    ("rapido", "veloz", "acelerado"),
    ("lento", "pausado", "despacio"),
    ("feliz", "contento", "alegre", "satisfecho"),
    ("triste", "apenado", "afligido"),
    ("miedo", "temor", "pavor"),
    ("enojo", "ira", "rabia", "enfado"),
    ("comida", "alimento", "nutricion"),
    ("agua", "liquido", "hidratacion"),
    ("planificar", "organizar", "programar", "preparar"),
    ("error", "fallo", "equivocacion", "defecto"),
    ("objetivo", "meta", "proposito", "finalidad"),
    ("conocimiento", "saber", "informacion", "concepto"),
)
_MAPA = {palabra: set(grupo) - {palabra} for grupo in _GRUPOS for palabra in grupo}

_STOP = {
    "a", "al", "algo", "ante", "bajo", "con", "como", "contra", "cual",
    "cuando", "de", "del", "desde", "donde", "el", "ella", "ellas", "ellos",
    "en", "entre", "era", "es", "esa", "ese", "eso", "esta", "este", "esto",
    "fue", "ha", "hasta", "hay", "la", "las", "le", "les", "lo", "los",
    "mas", "me", "mi", "mis", "muy", "no", "nos", "o", "para", "pero",
    "por", "que", "se", "sin", "sobre", "su", "sus", "te", "tu", "tus",
    "un", "una", "uno", "unos", "unas", "y", "ya",
}


def _sin_tildes(texto: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", texto)
                   if unicodedata.category(c) != "Mn")


def _raiz(token: str) -> str:
    """Stemmer ligero para español; evita alterar tokens cortos."""
    if len(token) <= 5:
        return token
    for sufijo in ("amientos", "imientos", "aciones", "uciones", "mente",
                   "amiento", "imiento", "acion", "ucion", "idades",
                   "idad", "anzas", "anzas", "ando", "iendo", "ados",
                   "idos", "adas", "idas", "es", "os", "as", "s"):
        if token.endswith(sufijo) and len(token) - len(sufijo) >= 4:
            return token[:-len(sufijo)]
    return token


def tokens_semanticos(texto: Any) -> list[str]:
    if not isinstance(texto, str):
        return []
    base = [_sin_tildes(t) for t in normalizar_tokens(texto)]
    salida = []
    for token in base:
        if token in _STOP or len(token) < 2:
            continue
        raiz = _raiz(token)
        salida.append(raiz)
        # La expansión se añade como rasgo de menor peso en la vectorización.
    return salida


def _texto_registro(registro: Any) -> str:
    if isinstance(registro, str):
        return registro
    if not isinstance(registro, dict):
        return str(registro)
    partes = []
    for clave in ("concepto", "informacion", "contenido", "evento", "pensamiento",
                  "correccion", "resumen", "detalle", "origen", "destino", "relacion"):
        valor = registro.get(clave)
        if isinstance(valor, str):
            partes.append(valor)
    if not partes:
        partes.append(" ".join(str(v) for v in registro.values()
                               if isinstance(v, (str, int, float))))
    return " ".join(partes)


def _expandir(tokens: list[str]) -> Counter:
    rasgos = Counter()
    for token in tokens:
        rasgos[token] += 1.0
        # Expansión conceptual con peso menor para no desplazar el significado
        # literal de la consulta.
        originales = _MAPA.get(token, set())
        for equivalente in originales:
            rasgos[_raiz(equivalente)] += 0.38
    return rasgos


def _coseno(a: Counter, b: Counter, idf: dict[str, float]) -> float:
    if not a or not b:
        return 0.0
    wa = {k: v * idf.get(k, 1.0) for k, v in a.items()}
    wb = {k: v * idf.get(k, 1.0) for k, v in b.items()}
    comunes = set(wa).intersection(wb)
    numerador = sum(wa[k] * wb[k] for k in comunes)
    norma_a = math.sqrt(sum(v * v for v in wa.values()))
    norma_b = math.sqrt(sum(v * v for v in wb.values()))
    return numerador / (norma_a * norma_b) if norma_a and norma_b else 0.0


def buscar_semanticamente(consulta: str, registros: list, limite: int = 8,
                          umbral: float = 0.10) -> list[dict]:
    """Devuelve documentos ordenados por similitud semántica híbrida."""
    if not isinstance(consulta, str) or not consulta.strip() or not isinstance(registros, list):
        return []
    if type(limite) is not int or not 1 <= limite <= 100:
        raise ValueError("limite debe estar entre 1 y 100")
    try:
        umbral = float(umbral)
    except (TypeError, ValueError):
        raise ValueError("umbral debe ser numérico")
    if not 0 <= umbral <= 1:
        raise ValueError("umbral debe estar entre 0 y 1")

    docs = []
    for registro in registros:
        texto = _texto_registro(registro)
        tokens = tokens_semanticos(texto)
        if tokens:
            docs.append((registro, texto, tokens, _expandir(tokens)))
    if not docs:
        return []

    q_tokens = tokens_semanticos(consulta)
    q_vector = _expandir(q_tokens)
    if not q_vector:
        return []

    df = Counter()
    for _, _, _, vector in docs:
        df.update(set(vector))
    n = len(docs)
    idf = {term: math.log(1 + (n + 1) / (freq + 1)) + 1
           for term, freq in df.items()}

    q_limpia = " ".join(q_tokens)
    resultados = []
    for registro, texto, tokens, vector in docs:
        coseno = _coseno(q_vector, vector, idf)
        coincidencias = sorted(set(q_tokens).intersection(tokens))
        # Coincidencia literal exacta recibe una bonificación moderada.
        frase = 0.08 if q_limpia and q_limpia in " ".join(tokens) else 0.0
        literal = len(coincidencias) / max(1, len(set(q_tokens)))
        score = min(1.0, 0.78 * coseno + 0.22 * literal + frase)
        if score < umbral:
            continue
        resultados.append({
            "registro": registro,
            "puntuacion": round(score, 4),
            "similitud_vectorial": round(coseno, 4),
            "coincidencias": coincidencias,
            "metodo": "tfidf_coseno_expandido_espanol",
            "limitacion": "Modelo local simbólico-vectorial; no equivale a embeddings neuronales contextuales.",
        })
    resultados.sort(key=lambda x: x["puntuacion"], reverse=True)
    return resultados[:limite]


def resumen_motor() -> dict:
    """Estado transparente del motor de recuperación semántica."""
    return {
        "motor": "tfidf_coseno_expandido_espanol",
        "grupos_conceptuales": len(_GRUPOS),
        "terminos_en_lexico": len(_MAPA),
        "vectorizacion": "TF-IDF dispersa local",
        "similitud": "coseno ponderado por IDF",
        "normalizacion": "acentos, stopwords y stemming ligero",
        "embeddings_neuronales": False,
        "modelo_transformer": False,
        "aprendizaje_de_hechos": "no; las asociaciones factuales requieren validación",
        "limitacion": "Recuperación semántica híbrida explicable; no comprensión contextual humana.",
    }
