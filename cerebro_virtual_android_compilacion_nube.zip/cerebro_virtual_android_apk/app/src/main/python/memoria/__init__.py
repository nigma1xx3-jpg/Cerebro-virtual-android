
from .semantica_profunda import buscar_semanticamente, tokens_semanticos
