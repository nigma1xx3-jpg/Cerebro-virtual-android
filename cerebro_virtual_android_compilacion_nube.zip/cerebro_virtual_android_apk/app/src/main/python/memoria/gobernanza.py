"""Gobernanza de recuerdos: calidad estructural, procedencia y elegibilidad de recuperación.

No determina si un recuerdo es verdadero. Evita que datos vacíos, comandos o texto
corrupto contaminen la recuperación y conserva explícitamente los límites de confianza.
"""
from __future__ import annotations
import unicodedata

COMANDOS_NO_MEMORIZABLES = {"salir", "exit", "quit", "/ayuda", "ayuda"}


def extraer_texto(registro):
    if isinstance(registro, str):
        return registro
    if not isinstance(registro, dict):
        return ""
    partes = []
    for clave in ("contenido", "pensamiento", "evento", "resultado", "concepto",
                  "informacion", "origen", "relacion", "destino", "correccion"):
        valor = registro.get(clave)
        if isinstance(valor, (str, int, float)) and str(valor).strip():
            partes.append(str(valor).strip())
    return " ".join(partes)


def contiene_caracteres_no_seguros(texto):
    return any(unicodedata.category(c) in {"Cc", "Cf", "Cs"} and c not in "\n\r\t" for c in texto)


def evaluar_registro(registro):
    texto = extraer_texto(registro)
    texto_limpio = texto.strip()
    normalizado = " ".join(texto_limpio.casefold().split())
    if not texto_limpio:
        return {"recuperable": False, "motivo": "contenido_vacio", "peso": 0.0,
                "estado_verificacion": "no_evaluable", "fuente_independiente": None}
    if contiene_caracteres_no_seguros(texto_limpio):
        return {"recuperable": False, "motivo": "caracteres_de_control", "peso": 0.0,
                "estado_verificacion": "no_evaluable", "fuente_independiente": None}
    if normalizado in COMANDOS_NO_MEMORIZABLES or len(normalizado) < 5:
        return {"recuperable": False, "motivo": "contenido_no_informativo", "peso": 0.0,
                "estado_verificacion": "no_evaluable", "fuente_independiente": None}

    procedencia = registro.get("procedencia") if isinstance(registro, dict) else None
    estado = registro.get("estado") if isinstance(registro, dict) else None
    if not isinstance(estado, str) or not estado.strip():
        estado = "legado_sin_estado"
    if not isinstance(procedencia, str) or not procedencia.strip():
        procedencia = "legado_sin_procedencia"

    # Solo una procedencia externa explícita y un estado validado pueden contar
    # como fuente independiente. Un rótulo por sí solo no autentica su contenido.
    verificada = estado.casefold() in {"verificado", "validado"}
    externa = procedencia.casefold().startswith(("fuente_verificada:", "documento_verificado:"))
    fuente_independiente = procedencia.strip() if verificada and externa else None
    if fuente_independiente:
        peso = 1.0
    elif estado.casefold() in {"sin_verificar", "pendiente", "pendiente_feedback"}:
        peso = 0.70
    elif procedencia == "legado_sin_procedencia" or estado == "legado_sin_estado":
        peso = 0.50
    else:
        peso = 0.60
    return {
        "recuperable": True,
        "motivo": "registro_util_no_autenticado" if not fuente_independiente else "fuente_declarada_validada",
        "peso": peso,
        "estado_verificacion": estado,
        "procedencia": procedencia,
        "fuente_independiente": fuente_independiente,
    }
