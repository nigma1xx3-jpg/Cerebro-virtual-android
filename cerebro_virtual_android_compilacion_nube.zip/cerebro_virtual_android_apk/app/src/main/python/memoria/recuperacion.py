"""Recuperación local por similitud léxica ponderada; no usa embeddings."""
from __future__ import annotations
import re
import unicodedata
from typing import Callable, Iterable, Any

PALABRAS_VACIAS = {
    "a", "al", "algo", "ante", "bajo", "cada", "como", "con", "contra",
    "cual", "cuando", "de", "del", "desde", "donde", "durante", "e", "el",
    "ella", "ellas", "ello", "ellos", "en", "entre", "era", "es", "esa",
    "ese", "eso", "esta", "estaba", "estado", "estan", "estar", "este",
    "esto", "estos", "fue", "ha", "hace", "hacia", "han", "hasta", "hay",
    "la", "las", "le", "les", "lo", "los", "mas", "me", "mi", "mis",
    "muy", "ni", "no", "nos", "o", "para", "pero", "por", "que", "se",
    "ser", "si", "sin", "sobre", "su", "sus", "tambien", "te", "tiene",
    "tu", "tus", "un", "una", "uno", "unos", "unas", "y", "ya",
}


def normalizar_tokens(texto: Any) -> list[str]:
    texto = unicodedata.normalize("NFD", str(texto).casefold())
    texto = "".join(c for c in texto if unicodedata.category(c) != "Mn")
    tokens = re.findall(r"[a-z0-9_]+", texto)
    return [t for t in tokens if len(t) > 1 and t not in PALABRAS_VACIAS]


def texto_registro(registro: Any) -> str:
    if isinstance(registro, str):
        return registro
    if isinstance(registro, dict):
        claves = ("contenido", "pensamiento", "evento", "resultado", "concepto",
                  "informacion", "origen", "relacion", "destino", "correccion")
        return " ".join(str(registro[k]) for k in claves if registro.get(k) not in (None, ""))
    return str(registro)


def puntuar_similitud(consulta: str, contenido: str) -> tuple[float, list[str]]:
    q, d = set(normalizar_tokens(consulta)), set(normalizar_tokens(contenido))
    if not q or not d:
        return 0.0, []
    coincidencias = sorted(q & d)
    if not coincidencias:
        return 0.0, []
    cobertura = len(coincidencias) / len(q)
    precision = len(coincidencias) / len(d)
    score = 0.72 * cobertura + 0.28 * precision
    frase = " ".join(normalizar_tokens(consulta))
    documento = " ".join(normalizar_tokens(contenido))
    if frase and frase in documento:
        score = min(1.0, score + 0.18)
    return round(score, 4), coincidencias


def recuperar_similares(consulta: str, registros: Iterable[Any], *,
                        extractor: Callable[[Any], str] | None = None,
                        limite: int = 5, umbral: float = 0.18) -> list[dict]:
    if not isinstance(consulta, str) or not consulta.strip():
        return []
    if type(limite) is not int or limite <= 0:
        return []
    try:
        umbral = float(umbral)
    except (TypeError, ValueError):
        return []
    if not 0 <= umbral <= 1:
        return []
    extraer = extractor or texto_registro
    resultados = []
    for posicion, registro in enumerate(registros or []):
        try:
            texto = extraer(registro)
        except Exception:
            continue
        puntuacion, coincidencias = puntuar_similitud(consulta, texto)
        if puntuacion >= umbral:
            resultados.append({"registro": registro, "puntuacion": puntuacion,
                               "coincidencias": coincidencias, "posicion": posicion})
    resultados.sort(key=lambda x: (x["puntuacion"], -x["posicion"]), reverse=True)
    return resultados[:limite]


def recuperar_contextuales(consulta: str, registros: Iterable[Any], *,
                           extractor: Callable[[Any], str] | None = None,
                           limite: int = 5, umbral: float = 0.12) -> list[dict]:
    """Recuperación local mejorada con ponderación IDF y cobertura de consulta.

    Es búsqueda léxica contextual, no embeddings ni comprensión semántica profunda.
    """
    if not isinstance(consulta, str) or not consulta.strip() or type(limite) is not int or limite < 1:
        return []
    try: umbral = float(umbral)
    except (TypeError, ValueError): return []
    if not 0 <= umbral <= 1: return []
    extraer = extractor or texto_registro
    docs=[]
    for pos, reg in enumerate(registros or []):
        try: toks=normalizar_tokens(extraer(reg))
        except Exception: continue
        if toks: docs.append((pos,reg,toks))
    q=list(dict.fromkeys(normalizar_tokens(consulta)))
    if not q or not docs: return []
    import math
    n=len(docs); df={t:sum(1 for _,_,ts in docs if t in set(ts)) for t in q}
    idf={t:math.log(1+(n-df[t]+0.5)/(df[t]+0.5)) for t in q}
    max_idf=sum(idf.values()) or 1.0
    resultados=[]
    for pos,reg,toks in docs:
        bolsa=set(toks); hits=[t for t in q if t in bolsa]
        if not hits: continue
        cobertura=sum(idf[t] for t in hits)/max_idf
        # Penaliza documentos excesivamente largos y premia frase literal.
        precision=len(hits)/max(1,len(bolsa))
        score=0.82*cobertura+0.18*min(1.0,precision*4)
        qfrase=" ".join(q); dfrase=" ".join(toks)
        if qfrase and qfrase in dfrase: score=min(1.0,score+0.08)
        score=round(score,4)
        if score>=umbral:
            resultados.append({"registro":reg,"puntuacion":score,"coincidencias":hits,"posicion":pos})
    resultados.sort(key=lambda x:(x["puntuacion"],-x["posicion"]),reverse=True)
    return resultados[:limite]
