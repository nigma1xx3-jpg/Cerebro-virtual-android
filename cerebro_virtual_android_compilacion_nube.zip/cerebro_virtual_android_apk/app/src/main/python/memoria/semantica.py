import json
from datetime import datetime
from nucleo.almacenamiento import ruta_proyecto, cargar_json, guardar_json_atomico

ARCHIVO = ruta_proyecto("memoria", "conocimientos.json")
ARCHIVO_ASOCIACIONES = ruta_proyecto("memoria", "asociaciones.json")


def _leer(ruta, defecto):
    datos = cargar_json(ruta, defecto)
    if not isinstance(datos, type(defecto)):
        raise ValueError(f"El almacén {ruta} tiene un tipo JSON incorrecto.")
    return datos


def _guardar(ruta, datos):
    guardar_json_atomico(ruta, datos, copia_seguridad=True)


def guardar_conocimiento(concepto, informacion):
    if not isinstance(concepto, str) or not isinstance(informacion, str):
        return False
    concepto, informacion = concepto.strip().lower(), informacion.strip()
    if len(concepto) < 2 or len(concepto) > 200 or len(informacion) < 5 or len(informacion) > 4000:
        return False
    conocimientos = _leer(ARCHIVO, {})
    conocimientos[concepto] = {
        "informacion": informacion,
        "fecha": datetime.now().isoformat(),
        "procedencia": "entrada_usuario",
        "estado": "sin_verificar",
    }
    _guardar(ARCHIVO, conocimientos)
    return True


def consultar_conocimiento(concepto):
    if not isinstance(concepto, str):
        return None
    return _leer(ARCHIVO, {}).get(concepto.strip().lower())


def recuperar_conocimientos():
    return _leer(ARCHIVO, {})


def guardar_asociacion(concepto_a, relacion, concepto_b):
    if not all(isinstance(x, str) for x in (concepto_a, relacion, concepto_b)):
        return False
    concepto_a, relacion, concepto_b = (x.strip().lower() for x in (concepto_a, relacion, concepto_b))
    if any(not x or len(x) > 200 for x in (concepto_a, relacion, concepto_b)):
        return False
    asociacion = {
        "origen": concepto_a.strip().lower(),
        "relacion": relacion.strip().lower(),
        "destino": concepto_b.strip().lower(),
        "procedencia": "entrada_usuario",
        "estado": "sin_verificar",
        "fecha": datetime.now().isoformat(),
    }
    if not all(asociacion[k] for k in ("origen", "relacion", "destino")):
        return False
    asociaciones = recuperar_asociaciones()
    if not any(
        all(a.get(k) == asociacion[k] for k in ("origen", "relacion", "destino"))
        for a in asociaciones if isinstance(a, dict)
    ):
        asociaciones.append(asociacion)
        _guardar(ARCHIVO_ASOCIACIONES, asociaciones)
    return True


def recuperar_asociaciones(concepto=None):
    asociaciones = _leer(ARCHIVO_ASOCIACIONES, [])
    if concepto is None:
        return asociaciones
    if not isinstance(concepto, str):
        return []
    concepto = concepto.strip().lower()
    return [a for a in asociaciones if isinstance(a, dict) and (a.get("origen") == concepto or a.get("destino") == concepto)]
