import json
from datetime import datetime
from nucleo.almacenamiento import ruta_proyecto, cargar_json, guardar_json_atomico
from seguridad.validacion import validar_texto

ARCHIVO = ruta_proyecto("memoria", "recuerdos.json")


def _cargar():
    datos = cargar_json(ARCHIVO, [])
    if not isinstance(datos, list):
        raise ValueError("El archivo de recuerdos no contiene una lista JSON válida.")
    return datos


def _guardar_atomico(datos):
    guardar_json_atomico(ARCHIVO, datos, copia_seguridad=True)


def guardar_recuerdo(texto):
    validacion = validar_texto(texto)
    if not validacion["valido"]:
        return False
    texto = validacion["texto"]
    if len(texto) < 5 or texto.casefold() in {"salir", "exit", "quit"}:
        return False
    recuerdos = _cargar()
    if any(
        isinstance(r, dict)
        and str(r.get("contenido", "")).strip().casefold() == texto.casefold()
        for r in recuerdos
    ):
        return False
    recuerdos.append({
        "fecha": datetime.now().isoformat(),
        "contenido": texto,
        "procedencia": "entrada_usuario",
        "estado": "sin_verificar",
        "tipo": "episodio_de_interaccion",
    })
    _guardar_atomico(recuerdos)
    return True


def recuperar_recuerdos():
    return _cargar()
