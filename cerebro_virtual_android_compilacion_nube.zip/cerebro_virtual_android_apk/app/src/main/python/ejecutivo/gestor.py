"""Gestor persistente de objetivos y tareas. No ejecuta código arbitrario ni acciones externas."""
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4
from nucleo.almacenamiento import ruta_proyecto, cargar_json, guardar_json_atomico

ESTADOS = {"pendiente", "en_progreso", "completada", "bloqueada", "cancelada"}

class GestorEjecutivo:
    def __init__(self, archivo=None):
        self.archivo = Path(archivo) if archivo else ruta_proyecto("ejecutivo", "objetivos.json")
        self.archivo.parent.mkdir(parents=True, exist_ok=True)

    def _cargar(self):
        data = cargar_json(self.archivo, [])
        if not isinstance(data, list): raise ValueError("Almacén ejecutivo inválido.")
        return data

    def _guardar(self, data): guardar_json_atomico(self.archivo, data, copia_seguridad=True)

    def crear_objetivo(self, objetivo, tareas):
        if not isinstance(objetivo, str) or not 3 <= len(objetivo.strip()) <= 500:
            return {"creado": False, "motivo": "objetivo_invalido"}
        if not isinstance(tareas, (list, tuple)) or not tareas:
            return {"creado": False, "motivo": "se_requieren_tareas"}
        limpias=[]
        for t in tareas[:30]:
            if isinstance(t, str) and t.strip(): limpias.append({"id":str(uuid4()),"descripcion":t.strip()[:500],"estado":"pendiente","requiere_aprobacion":True})
        if not limpias: return {"creado": False, "motivo": "sin_tareas_validas"}
        item={"id":str(uuid4()),"objetivo":objetivo.strip(),"creado_utc":datetime.now(timezone.utc).isoformat(),
              "estado":"pendiente","tareas":limpias,"modo":"supervisado","acciones_externas_habilitadas":False}
        data=self._cargar(); data.append(item); self._guardar(data)
        return {"creado":True, **item}

    def actualizar_tarea(self, objetivo_id, tarea_id, estado, aprobada=False):
        if estado not in ESTADOS: return False
        data=self._cargar(); objetivo=next((x for x in data if x.get("id")==str(objetivo_id)),None)
        if not objetivo: return False
        tarea=next((x for x in objetivo.get("tareas",[]) if x.get("id")==str(tarea_id)),None)
        if not tarea: return False
        if estado in {"en_progreso","completada"} and not aprobada: return False
        tarea["estado"]=estado
        tarea["actualizada_utc"]=datetime.now(timezone.utc).isoformat()
        if estado=="completada": tarea["verificacion_requerida"]=True
        estados=[x.get("estado") for x in objetivo["tareas"]]
        objetivo["estado"]="completada" if all(x=="completada" for x in estados) else "en_progreso" if any(x=="en_progreso" for x in estados) else "pendiente"
        self._guardar(data); return True

    def listar(self): return self._cargar()
