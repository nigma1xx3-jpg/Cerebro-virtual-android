"""Control ejecutivo supervisado."""
