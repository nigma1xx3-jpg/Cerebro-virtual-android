"""Diagnóstico de importaciones, JSON y calidad heredada sin modificar los datos."""
import importlib
from nucleo.almacenamiento import ruta_proyecto
from seguridad.esquemas import validar_archivos_datos
from memoria.episodica import recuperar_recuerdos
from memoria.gobernanza import evaluar_registro
from red_neuronal.red import RedNeuronalCognitiva

MODULOS = (
    "cerebro", "percepcion.entrada", "memoria.episodica", "memoria.semantica",
    "memoria.recuperacion", "memoria.semantica_profunda", "memoria.gobernanza", "emociones.valoracion",
    "razonamiento.central", "razonamiento.motor", "metacognicion.evaluador",
    "aprendizaje.adaptativo", "aprendizaje.feedback", "aprendizaje.plasticidad_sinaptica",
    "aprendizaje.asociativo",
    "red_neuronal.red", "red_neuronal.integracion", "planificacion.gestor",
    "integridad.verificador", "integridad.ledger", "seguridad.validacion",
    "atencion.selectiva", "prediccion.calibrador", "ejecutivo.gestor", "memoria.indice_calidad",
    "seguridad.esquemas", "nucleo.coordinador", "nucleo.ciclo_cognitivo",
)


def ejecutar_diagnostico():
    imports = {}
    for nombre in MODULOS:
        try:
            importlib.import_module(nombre)
            imports[nombre] = "ok"
        except Exception as exc:
            imports[nombre] = f"error: {type(exc).__name__}: {exc}"
    datos = validar_archivos_datos()
    red = RedNeuronalCognitiva().resumen()
    error_lectura_memoria = None
    try:
        recuerdos = recuperar_recuerdos()
    except Exception as exc:
        recuerdos = []
        error_lectura_memoria = f"{type(exc).__name__}: {exc}"
    politica = [evaluar_registro(r) for r in recuerdos]
    excluidos = sum(1 for p in politica if not p["recuperable"])
    legados = sum(1 for p in politica if p["recuperable"] and p.get("estado_verificacion") == "legado_sin_estado")
    errores_import = [v for v in imports.values() if v != "ok"]
    if not red.get("topologia_valida"):
        errores_import.append("topologia_red_neuronal_invalida")
    errores_datos = [v.get("estado") for v in datos["archivos"].values() if v.get("estado") not in {"ok", "advertencia_estructura"}]
    advertencias = list(datos["advertencias"])
    if excluidos:
        advertencias.append(f"{excluidos} recuerdos no se usarán en recuperación por estar vacíos, corruptos o no informativos; permanecen conservados.")
    if legados:
        advertencias.append(f"{legados} recuerdos heredados no tienen estado de verificación explícito.")
    if error_lectura_memoria:
        advertencias.append("No se pudo abrir el almacén de recuerdos: " + error_lectura_memoria)
    advertencias.extend([
        "La confianza es un índice heurístico, no una probabilidad calibrada.",
        "La recuperación semántica usa TF-IDF y expansión conceptual local; no equivale a embeddings neuronales contextuales.",
        "El aprendizaje requiere feedback explícito y no entrena parámetros de un modelo.",
        "El hash local detecta cambios frente al último sellado; copia la huella fuera del proyecto para anclarla.",
    ])
    estado = "requiere_revision" if errores_import or errores_datos else ("correcto_con_advertencias" if advertencias else "correcto")
    return {"estado": estado, "modulos": imports, "red_neuronal": red, "datos": datos,
            "calidad_memoria": {"recuerdos_total": len(recuerdos),
                "recuerdos_excluidos_de_recuperacion": excluidos,
                "recuerdos_legacy_sin_verificar": legados,
                "error_lectura": error_lectura_memoria},
            "advertencias": advertencias}


if __name__ == "__main__":
    import json
    print(json.dumps(ejecutar_diagnostico(), ensure_ascii=False, indent=2))
