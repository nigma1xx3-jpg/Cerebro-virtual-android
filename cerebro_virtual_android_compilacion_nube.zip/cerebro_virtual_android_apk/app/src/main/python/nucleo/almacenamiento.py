"""Utilidades comunes para persistencia local y rutas estables del proyecto."""
from __future__ import annotations

import json
import os
import tempfile
import shutil
from pathlib import Path
from typing import Any

# En Android, CV_DATA_DIR apunta al almacenamiento privado y escribible de la app.
# En PC/Termux conserva la raíz habitual del proyecto.
RAIZ_PROYECTO = Path(os.environ.get("CV_DATA_DIR", Path(__file__).resolve().parents[1]))


def ruta_proyecto(*partes: str) -> Path:
    return RAIZ_PROYECTO.joinpath(*partes)


def _ruta_respaldo(ruta: Path) -> Path:
    return ruta.with_suffix(ruta.suffix + ".bak")


def _restaurar_respaldo(ruta: Path, respaldo: Path) -> None:
    """Restaura un .bak válido y conserva el archivo principal dañado."""
    if ruta.exists():
        corrupto = ruta.with_suffix(ruta.suffix + ".corrupt")
        contador = 1
        while corrupto.exists():
            corrupto = ruta.with_suffix(ruta.suffix + f".corrupt.{contador}")
            contador += 1
        ruta.replace(corrupto)
    temporal = ruta.with_suffix(ruta.suffix + ".restore")
    try:
        shutil.copyfile(respaldo, temporal)
        os.replace(temporal, ruta)
    finally:
        temporal.unlink(missing_ok=True)


def cargar_json(ruta: str | Path, defecto: Any):
    """Carga JSON; ante archivo ausente/dañado intenta .bak sin perder el original.

    Si el archivo y su respaldo están dañados, propaga el error para impedir que
    un guardado posterior reemplace silenciosamente los datos por una lista vacía.
    """
    ruta = Path(ruta)
    respaldo = _ruta_respaldo(ruta)
    if not ruta.exists():
        if respaldo.is_file():
            with respaldo.open("r", encoding="utf-8") as archivo:
                recuperado = json.load(archivo)
            _restaurar_respaldo(ruta, respaldo)
            return recuperado
        return defecto
    try:
        with ruta.open("r", encoding="utf-8") as archivo:
            return json.load(archivo)
    except json.JSONDecodeError:
        if respaldo.is_file():
            with respaldo.open("r", encoding="utf-8") as archivo:
                recuperado = json.load(archivo)
            _restaurar_respaldo(ruta, respaldo)
            return recuperado
        raise


def guardar_json_atomico(
    ruta: str | Path,
    datos: Any,
    *,
    copia_seguridad: bool = False,
) -> None:
    """Escribe en el mismo directorio y sustituye el destino atómicamente."""
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    temporal = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=ruta.parent,
            prefix=f".{ruta.name}.", suffix=".tmp", delete=False
        ) as archivo:
            temporal = Path(archivo.name)
            json.dump(datos, archivo, ensure_ascii=False, indent=4)
            archivo.write("\n")
            archivo.flush()
            os.fsync(archivo.fileno())
        if copia_seguridad and ruta.exists():
            respaldo = ruta.with_suffix(ruta.suffix + ".bak")
            respaldo.write_bytes(ruta.read_bytes())
        os.replace(temporal, ruta)
    finally:
        if temporal is not None and temporal.exists():
            temporal.unlink(missing_ok=True)
