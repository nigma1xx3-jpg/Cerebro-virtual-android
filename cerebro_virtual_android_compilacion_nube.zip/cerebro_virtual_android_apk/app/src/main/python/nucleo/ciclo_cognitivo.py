from nucleo.coordinador import procesar_informacion
from aprendizaje.retroalimentacion import buscar_relacionadas
from metacognicion.evaluador import Metacognicion
from aprendizaje.adaptativo import AprendizajeAdaptativo
from planificacion.gestor import Planificador
from integridad.verificador import verificar_procedencia
from seguridad.validacion import validar_texto
from neurociencia.regulacion_cognitiva import evaluar as evaluar_regulacion_cognitiva
import json
from atencion.selectiva import evaluar as evaluar_atencion
from prediccion.calibrador import Calibrador
from red_neuronal.integracion import activar_red_cognitiva
from aprendizaje.asociativo import AprendizajeAsociativo

supervisor = Metacognicion()
aprendizaje = AprendizajeAdaptativo()
asociador = AprendizajeAsociativo()


def _preparar_evidencias_metacognicion(evidencias):
    preparadas = []
    for evidencia in evidencias:
        if isinstance(evidencia, str):
            texto = evidencia.strip()
        elif isinstance(evidencia, dict):
            dato = evidencia.get("dato", evidencia)
            texto = dato.strip() if isinstance(dato, str) else json.dumps(dato, ensure_ascii=False, sort_keys=True)
        else:
            texto = str(evidencia).strip()
        if texto and texto not in preparadas:
            preparadas.append(texto)
    return preparadas


def ejecutar_ciclo(texto, objetivo=None, pasos=None):
    validacion = validar_texto(texto)
    if not validacion["valido"]:
        return {
            "entrada": texto,
            "ciclo_completado": False,
            "error": validacion["motivo"],
            "metacognicion": {"estado": "no_evaluado", "requiere_revision": True},
        }
    texto = validacion["texto"]
    experiencias_relacionadas = buscar_relacionadas(texto)
    procesamiento = procesar_informacion(texto, experiencias_relacionadas)
    if not procesamiento.get("procesado"):
        return {"entrada": texto, "procesamiento": procesamiento, "ciclo_completado": False}

    analisis_central = procesamiento.get("razonamiento", {})
    resultado_motor = analisis_central.get("razonamiento", {}) if isinstance(analisis_central, dict) else {}
    if not isinstance(resultado_motor, dict):
        resultado_motor = {}
    evidencias = _preparar_evidencias_metacognicion(resultado_motor.get("evidencias", []))
    confianza = resultado_motor.get("confianza", 0)
    try:
        confianza = max(0, min(100, float(confianza)))
    except (TypeError, ValueError):
        confianza = 0
    calidad = resultado_motor.get("calidad_evidencia")
    try:
        calidad = None if calidad is None else max(0, min(100, float(calidad)))
    except (TypeError, ValueError):
        calidad = None

    atencion = evaluar_atencion(texto, objetivo=objetivo, contexto=[str(x.get("experiencia", {}).get("evento", "")) for x in experiencias_relacionadas if isinstance(x, dict)])

    regulacion_cognitiva = evaluar_regulacion_cognitiva(
        texto,
        emocion=procesamiento.get("estado_emocional", {}),
        razonamiento=resultado_motor,
    )

    evaluacion = supervisor.evaluar(
        pensamiento=texto,
        evidencia=evidencias,
        confianza=confianza,
        calidad_evidencia=calidad,
    )
    retroalimentacion = supervisor.retroalimentacion(len(supervisor.historial) - 1)
    experiencia = aprendizaje.registrar_experiencia(texto, evaluacion)
    plan = Planificador().crear_plan(objetivo, pasos) if objetivo is not None else None

    recuerdos = analisis_central.get("recuerdos", []) if isinstance(analisis_central, dict) else []
    conocimientos = analisis_central.get("conocimientos", []) if isinstance(analisis_central, dict) else []
    asociaciones = analisis_central.get("asociaciones", []) if isinstance(analisis_central, dict) else []
    registros = [("recuerdo", r) for r in recuerdos] + [("conocimiento", r) for r in conocimientos] + [("asociacion", r) for r in asociaciones]
    integridad = [{"tipo": tipo, **verificar_procedencia(r)} for tipo, r in registros if isinstance(r, dict)]
    asociaciones_activadas = asociador.recuperar_relacionadas(texto)
    candidatos_asociativos = asociador.generar_candidatos()
    red_neuronal = activar_red_cognitiva(
        procesamiento=procesamiento,
        atencion=atencion,
        regulacion=regulacion_cognitiva,
        metacognicion=evaluacion,
        aprendizaje=experiencia,
        planificacion=plan or {},
        integridad=integridad,
        memoria_asociativa=asociaciones_activadas,
    )
    return {
        "entrada": texto,
        "experiencias_relacionadas": experiencias_relacionadas,
        "recuerdos_relacionados": recuerdos,
        "procesamiento": procesamiento,
        "metacognicion": evaluacion,
        "regulacion_cognitiva": regulacion_cognitiva,
        "atencion_selectiva": atencion,
        "autonomia": {"modo": "supervisado", "ejecucion_automatica": False, "aprobacion_humana_requerida": True},
        "prediccion": Calibrador().resumen(),
        "retroalimentacion": retroalimentacion,
        "aprendizaje": experiencia,
        "planificacion": plan,
        "integridad_recuerdos": integridad,
        "red_neuronal": red_neuronal,
        "memoria_asociativa": {
            "relaciones": asociaciones_activadas,
            "candidatos_generados": len(candidatos_asociativos),
            "estado": "integrada_con_validacion_humana",
        },
        "ciclo_completado": True,
    }
