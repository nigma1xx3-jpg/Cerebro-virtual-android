from percepcion.entrada import recibir_entrada
from emociones.valoracion import valorar
from memoria.episodica import guardar_recuerdo
from razonamiento.central import analizar, estado_cognitivo
from aprendizaje.neuroplasticidad import aprender


def procesar_informacion(texto, experiencias_relacionadas=None):
    percepcion = recibir_entrada(texto)
    if percepcion is None:
        return {
            "entrada": None,
            "error": "entrada_invalida_o_supera_4000_caracteres",
            "procesado": False,
        }
    texto_limpio = percepcion["original"]
    emocion = valorar(texto_limpio)
    razonamiento = analizar(texto_limpio, emocion, experiencias_relacionadas)
    memoria_guardada = guardar_recuerdo(texto_limpio)
    resumen_aprendizaje = aprender()
    return {
        "entrada": percepcion,
        "estado_emocional": emocion,
        "razonamiento": razonamiento,
        "memoria_guardada": memoria_guardada,
        "aprendizaje": resumen_aprendizaje,
        "procesado": True,
    }


def estado_modulos():
    estado = estado_cognitivo()
    estado.update({
        "metacognicion": "evaluacion_persistente; confianza_heuristica",
        "aprendizaje_adaptativo": "registro_y_feedback_explicito; no_entrenamiento_automatico",
        "planificacion": "propuestas_sin_ejecucion",
        "integridad": "SHA256_bajo_demanda; no_prueba_veracidad",
        "neurociencia_aplicada": "atencion_heuristica; memoria_trabajo_acotada; carga_textual; incertidumbre; consolidacion_con_feedback",
        "atencion_selectiva": "priorizacion_lexica_explicable",
        "control_ejecutivo": "objetivos_persistentes_con_aprobacion_humana",
        "prediccion": "registro_y_evaluacion_explicita_de_resultados",
        "autonomia": "supervisada; sin ejecucion externa automatica",
        "red_neuronal": "sinapsis_dirigidas_ponderadas; propagacion_de_activacion; plasticidad_solo_con_feedback_explicito",
        "diagnostico": "disponible",
    })
    return estado
