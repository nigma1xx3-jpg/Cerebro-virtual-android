"""Manifiesto local SHA-256 para detectar cambios en datos y código.

El manifiesto local ayuda a detectar cambios accidentales. Para resistir a un
atacante que pueda modificar todo el directorio, el hash debe copiarse fuera del
proyecto; este módulo no firma digitalmente ni demuestra autenticidad.
"""
from __future__ import annotations
import hashlib
import json
from datetime import datetime
from nucleo.almacenamiento import ruta_proyecto, cargar_json, guardar_json_atomico
from integridad.verificador import huella_archivo

ARCHIVO_MANIFIESTO = ruta_proyecto("integridad", "manifiesto_huellas.json")
ARCHIVOS_DATOS = (
    "memoria/recuerdos.json", "memoria/conocimientos.json",
    "memoria/asociaciones.json", "aprendizaje/experiencias.json",
    "metacognicion/historial.json", "prediccion/historial.json",
    "ejecutivo/objetivos.json", "memoria/informe_calidad.json",
    "red_neuronal/sinapsis.json",
)
DIRECTORIOS_CODIGO = ("aprendizaje", "atencion", "ejecutivo", "emociones", "integridad", "memoria",
                      "metacognicion", "nucleo", "percepcion", "planificacion", "prediccion",
                      "razonamiento", "seguridad", "neurociencia", "red_neuronal")


def _archivos_codigo():
    archivos = ["cerebro.py", "cerebro_version.py"]
    for carpeta in DIRECTORIOS_CODIGO:
        base = ruta_proyecto(carpeta)
        if base.exists():
            archivos.extend(str(p.relative_to(ruta_proyecto())) for p in base.rglob("*.py")
                            if "__pycache__" not in p.parts)
    return tuple(sorted(set(archivos)))


def _archivos_gestionados():
    return tuple(sorted(set(ARCHIVOS_DATOS) | set(_archivos_codigo())))


def _hash_json(datos):
    bruto = json.dumps(datos, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(bruto).hexdigest()


def sellar_estado():
    archivos = {}
    for relativo in _archivos_gestionados():
        ruta = ruta_proyecto(*relativo.split("/"))
        archivos[relativo] = huella_archivo(ruta) if ruta.is_file() else None
    try:
        historial = cargar_json(ARCHIVO_MANIFIESTO, [])
        if not isinstance(historial, list):
            historial = []
    except (json.JSONDecodeError, OSError):
        historial = []
    previo = historial[-1].get("hash_entrada", "0" * 64) if historial and isinstance(historial[-1], dict) else "0" * 64
    entrada = {"fecha": datetime.now().isoformat(), "archivos": archivos, "hash_anterior": previo}
    entrada["hash_entrada"] = _hash_json(entrada)
    historial.append(entrada)
    guardar_json_atomico(ARCHIVO_MANIFIESTO, historial, copia_seguridad=True)
    return {"sellado": True, "archivos": len(archivos), "hash": entrada["hash_entrada"],
            "alcance": "código_y_datos_locales; copia_el_hash_fuera_del_proyecto_para_anclarlo"}


def verificar_estado():
    try:
        historial = cargar_json(ARCHIVO_MANIFIESTO, [])
    except (json.JSONDecodeError, OSError):
        return {"estado": "manifiesto_ilegible", "coinciden": [], "alterados": [], "sin_registro": []}
    if not isinstance(historial, list) or not historial:
        return {"estado": "sin_sellar", "coinciden": [], "alterados": [], "sin_registro": list(_archivos_gestionados())}
    anterior = "0" * 64
    for entrada in historial:
        if not isinstance(entrada, dict):
            return {"estado": "cadena_invalida", "coinciden": [], "alterados": [], "sin_registro": []}
        esperado = entrada.get("hash_entrada")
        contenido = {k: v for k, v in entrada.items() if k != "hash_entrada"}
        if entrada.get("hash_anterior") != anterior or _hash_json(contenido) != esperado:
            return {"estado": "cadena_invalida", "coinciden": [], "alterados": [], "sin_registro": []}
        anterior = esperado
    ultimo = historial[-1].get("archivos", {})
    actuales = set(_archivos_gestionados())
    registrados = set(ultimo) if isinstance(ultimo, dict) else set()
    coinciden, alterados = [], []
    for relativo in sorted(actuales & registrados):
        ruta = ruta_proyecto(*relativo.split("/"))
        huella_esperada = ultimo[relativo]
        if huella_esperada is None:
            if ruta.exists():
                alterados.append(relativo)
            else:
                coinciden.append(relativo)
        elif not ruta.is_file() or huella_archivo(ruta) != huella_esperada:
            alterados.append(relativo)
        else:
            coinciden.append(relativo)
    sin_registro = sorted(actuales - registrados)
    faltantes = sorted(registrados - actuales)
    estado = "integro" if not alterados and not sin_registro and not faltantes else "cambios_detectados"
    return {"estado": estado, "coinciden": coinciden, "alterados": alterados,
            "sin_registro": sin_registro, "archivos_ya_no_presentes": faltantes,
            "archivos_verificados": len(coinciden)}
