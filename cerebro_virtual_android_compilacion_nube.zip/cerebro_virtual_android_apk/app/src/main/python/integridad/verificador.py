"""Herramientas de integridad y procedencia declarada; no prueban veracidad."""
import hashlib
from pathlib import Path


def huella_archivo(ruta):
    ruta = Path(ruta)
    if not ruta.is_file():
        raise FileNotFoundError(str(ruta))
    digest = hashlib.sha256()
    with ruta.open("rb") as archivo:
        for bloque in iter(lambda: archivo.read(65536), b""):
            digest.update(bloque)
    return digest.hexdigest()


def verificar_procedencia(registro):
    if not isinstance(registro, dict):
        return {"valido": False, "verificada": False,
                "motivo": "registro_no_es_diccionario", "alcance": "estructura"}
    contenido = next((registro.get(k) for k in ("contenido", "dato", "informacion", "pensamiento", "evento", "concepto", "origen") if registro.get(k) not in (None, "")), None)
    procedencia = registro.get("_procedencia", registro.get("procedencia"))
    estado = registro.get("_estado_verificacion", registro.get("estado", "sin_verificar"))
    if not contenido:
        return {"valido": False, "verificada": False,
                "motivo": "contenido_ausente", "alcance": "estructura"}
    if not isinstance(procedencia, str) or not procedencia.strip():
        return {"valido": False, "verificada": False,
                "motivo": "procedencia_ausente", "alcance": "estructura"}
    procedencia_externa = procedencia.casefold().startswith(("fuente_verificada:", "documento_verificado:"))
    verificada = str(estado).casefold() in {"verificado", "validado"} and procedencia_externa
    return {
        "valido": True,
        "verificada": verificada,
        "motivo": "fuente_declarada_validada" if verificada else "procedencia_declarada_no_verificada",
        "procedencia": procedencia,
        "estado_verificacion": estado,
        "alcance": "estructura_y_etiquetas; no_autenticidad_ni_veracidad",
    }
