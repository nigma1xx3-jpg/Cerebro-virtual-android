"""Canal explícito para incorporar correcciones humanas a una experiencia."""
from aprendizaje.adaptativo import AprendizajeAdaptativo


def registrar_feedback(referencia, correccion, autor="usuario"):
    if not isinstance(correccion, str) or not correccion.strip():
        return {"registrado": False, "motivo": "correccion_vacia"}
    sistema = AprendizajeAdaptativo()
    correcto = sistema.registrar_correccion(referencia, correccion, validador=autor)
    return {
        "registrado": correcto,
        "motivo": "feedback_guardado" if correcto else "experiencia_no_encontrada",
        "nota": "El feedback queda registrado; no ajusta parámetros de un modelo.",
    }
