"""Aprendizaje asociativo trazable basado en feedback humano validado.

Las coocurrencias generan candidatos, nunca hechos. Solo una validación humana
explícita permite que una relación participe en la recuperación asociativa.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from nucleo.almacenamiento import ruta_proyecto, cargar_json, guardar_json_atomico
from memoria.recuperacion import normalizar_tokens


class AprendizajeAsociativo:
    def __init__(self, archivo=None, archivo_experiencias=None):
        self.archivo = Path(archivo) if archivo else ruta_proyecto(
            "aprendizaje", "asociaciones_aprendidas.json"
        )
        self.archivo_experiencias = Path(archivo_experiencias) if archivo_experiencias else ruta_proyecto(
            "aprendizaje", "experiencias.json"
        )
        self.archivo.parent.mkdir(parents=True, exist_ok=True)
        self._cargar()

    def _cargar(self):
        datos = cargar_json(self.archivo, [])
        if not isinstance(datos, list):
            raise ValueError("El almacén asociativo debe ser una lista JSON.")
        if any(not isinstance(x, dict) for x in datos):
            raise ValueError("El almacén asociativo contiene registros inválidos.")
        return datos

    def _experiencias_validadas(self):
        datos = cargar_json(self.archivo_experiencias, [])
        if not isinstance(datos, list):
            raise ValueError("El archivo de experiencias debe contener una lista.")
        return [
            e for e in datos
            if isinstance(e, dict) and e.get("validada") is True
            and isinstance(e.get("correccion"), str) and e["correccion"].strip()
        ]

    def generar_candidatos(self, minimo_coocurrencias=2, max_candidatos=30):
        """Genera pares recurrentes a partir de experiencias corregidas por humanos."""
        if type(minimo_coocurrencias) is not int or minimo_coocurrencias < 2:
            raise ValueError("minimo_coocurrencias debe ser entero >= 2")
        if type(max_candidatos) is not int or not 1 <= max_candidatos <= 200:
            raise ValueError("max_candidatos debe estar entre 1 y 200")

        conteo = Counter()
        evidencias = {}
        for exp in self._experiencias_validadas():
            tokens = sorted(set(
                normalizar_tokens(exp.get("pensamiento", "")) +
                normalizar_tokens(exp.get("correccion", ""))
            ))
            # Evita asociaciones triviales entre términos demasiado genéricos.
            tokens = [t for t in tokens if len(t) >= 3][:40]
            for i, a in enumerate(tokens):
                for b in tokens[i + 1:]:
                    par = (a, b)
                    conteo[par] += 1
                    evidencias.setdefault(par, set()).add(str(exp.get("id", "sin_id")))

        existentes = self._cargar()
        estado_por_par = {
            (x.get("origen"), x.get("destino")): x.get("estado")
            for x in existentes if isinstance(x, dict)
        }
        candidatos = []
        for (a, b), cantidad in conteo.most_common():
            if cantidad < minimo_coocurrencias:
                continue
            estado = estado_por_par.get((a, b))
            if estado in {"validada_por_usuario", "rechazada"}:
                continue
            candidatos.append({
                "origen": a,
                "destino": b,
                "tipo": "coocurrencia_en_feedback_validado",
                "coocurrencias": cantidad,
                "experiencias_fuente": sorted(evidencias[(a, b)]),
                "estado": "candidato_no_verificado",
                "procedencia": "feedback_humano_corregido",
            })
            if len(candidatos) >= max_candidatos:
                break
        return candidatos

    def validar_asociacion(self, origen, destino, *, aprobada, referencia,
                           validador, evento_id=None):
        if type(aprobada) is not bool:
            return {"actualizada": False, "motivo": "aprobacion_booleana_explicita_requerida"}
        if not all(isinstance(x, str) and x.strip() for x in (origen, destino, referencia, validador)):
            return {"actualizada": False, "motivo": "origen_destino_referencia_y_validador_obligatorios"}
        origen, destino = origen.strip().casefold(), destino.strip().casefold()
        if origen == destino:
            return {"actualizada": False, "motivo": "no_se_admiten_autorelaciones"}
        evento_id = str(evento_id or uuid4())
        registros = self._cargar()
        if any(x.get("evento_id") == evento_id for x in registros):
            return {"actualizada": False, "motivo": "evento_ya_procesado", "evento_id": evento_id}

        registro = {
            "evento_id": evento_id,
            "origen": origen,
            "destino": destino,
            "tipo": "asociacion_semantica_validada",
            "estado": "validada_por_usuario" if aprobada else "rechazada",
            "referencia": referencia.strip()[:300],
            "validador": validador.strip()[:120],
            "fecha": datetime.now(timezone.utc).isoformat(),
            "procedencia": "validacion_humana_explicita",
        }
        # Reemplaza el estado previo del mismo par, conservando el historial de eventos.
        registros.append(registro)
        guardar_json_atomico(self.archivo, registros, copia_seguridad=True)
        return {"actualizada": True, **registro}

    def recuperar_relacionadas(self, texto, limite=10):
        if not isinstance(texto, str) or not texto.strip():
            return {"activadas": [], "candidatas": []}
        if type(limite) is not int or not 1 <= limite <= 50:
            raise ValueError("limite debe estar entre 1 y 50")
        tokens = set(normalizar_tokens(texto))
        registros = self._cargar()
        ultimo_estado = {}
        for r in registros:
            ultimo_estado[(r.get("origen"), r.get("destino"))] = r
        activadas, candidatas = [], []
        for (a, b), r in ultimo_estado.items():
            coincidencias = sorted(tokens.intersection({a, b}))
            if not coincidencias:
                continue
            salida = {
                "origen": a, "destino": b,
                "coincidencias": coincidencias,
                "estado": r.get("estado"),
                "procedencia": r.get("procedencia"),
            }
            if r.get("estado") == "validada_por_usuario":
                activadas.append(salida)
            elif r.get("estado") not in {"rechazada"}:
                candidatas.append(salida)
        return {
            "activadas": activadas[:limite],
            "candidatas": candidatas[:limite],
            "limitacion": "Solo las asociaciones validadas por una persona se activan como conocimiento; las candidatas no se presentan como hechos.",
        }

    def resumen(self):
        registros = self._cargar()
        ultimo_estado = {}
        for r in registros:
            ultimo_estado[(r.get("origen"), r.get("destino"))] = r.get("estado")
        return {
            "asociaciones_registradas": len(registros),
            "asociaciones_validadas": sum(x == "validada_por_usuario" for x in ultimo_estado.values()),
            "asociaciones_rechazadas": sum(x == "rechazada" for x in ultimo_estado.values()),
            "aprendizaje_automatico_de_hechos": False,
            "validacion_humana_requerida": True,
        }
