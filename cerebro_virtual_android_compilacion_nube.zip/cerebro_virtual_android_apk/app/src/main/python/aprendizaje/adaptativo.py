from datetime import datetime
from uuid import uuid4
from pathlib import Path
import json

from nucleo.almacenamiento import ruta_proyecto, cargar_json, guardar_json_atomico


class AprendizajeAdaptativo:
    """Registra experiencias y feedback explícito; no entrena un modelo."""

    def __init__(self, archivo=None):
        self.archivo = ruta_proyecto("aprendizaje", "experiencias.json") if archivo is None else Path(archivo)
        self.archivo.parent.mkdir(parents=True, exist_ok=True)
        self.experiencias = self.cargar()

    def cargar(self):
        datos = cargar_json(self.archivo, [])
        if not isinstance(datos, list):
            raise ValueError("El archivo de experiencias no contiene una lista JSON válida.")
        return datos

    def guardar(self):
        guardar_json_atomico(self.archivo, self.experiencias, copia_seguridad=True)

    def registrar_experiencia(self, pensamiento, evaluacion):
        self.experiencias = self.cargar()
        evaluacion = evaluacion if isinstance(evaluacion, dict) else {}
        try:
            relevancia = max(0, min(100, int(evaluacion.get("confianza", 0) or 0)))
        except (TypeError, ValueError):
            relevancia = 0
        experiencia = {
            "id": str(uuid4()),
            "fecha": datetime.now().isoformat(),
            "evento": str(pensamiento)[:4000],
            "resultado": str(evaluacion.get("resultado", "Evaluación metacognitiva registrada; pendiente de feedback"))[:4000],
            "relevancia": relevancia,
            "pensamiento": str(pensamiento)[:4000],
            "evaluacion": evaluacion,
            "correccion": None,
            "validada": False,
            "estado_aprendizaje": "pendiente_feedback",
        }
        self.experiencias.append(experiencia)
        self.guardar()
        return experiencia

    def registrar_correccion(self, indice, correccion, validador="usuario"):
        self.experiencias = self.cargar()
        if not isinstance(correccion, str) or not correccion.strip():
            return False
        objetivo = None
        if type(indice) is int and 0 <= indice < len(self.experiencias):
            objetivo = self.experiencias[indice]
        else:
            objetivo = next((e for e in self.experiencias if isinstance(e, dict) and e.get("id") == str(indice)), None)
        if objetivo is None:
            return False
        objetivo["correccion"] = correccion.strip()[:4000]
        objetivo["validada"] = True
        objetivo["validada_por"] = str(validador)
        objetivo["fecha_correccion"] = datetime.now().isoformat()
        objetivo["estado_aprendizaje"] = "corregida_con_feedback"
        self.guardar()
        return True

    def buscar_experiencias(self, palabra):
        palabra = str(palabra).casefold()
        return [e for e in self.cargar() if palabra in str(e.get("pensamiento", "")).casefold() or palabra in str(e.get("evento", "")).casefold()]

    def perfil_aprendizaje(self):
        """Extrae patrones solo de correcciones humanas explícitas y trazables."""
        from memoria.recuperacion import normalizar_tokens
        registros = [e for e in self.cargar() if isinstance(e, dict) and e.get("validada") and e.get("correccion")]
        frecuencias = {}
        for e in registros:
            for token in set(normalizar_tokens(e.get("pensamiento", ""))):
                frecuencias[token] = frecuencias.get(token, 0) + 1
        patrones = sorted(frecuencias.items(), key=lambda x: (-x[1], x[0]))[:20]
        return {"correcciones_fuente": len(registros), "tokens_recurrentes": [{"token": t, "frecuencia": n} for t,n in patrones],
                "procedencia": "feedback_humano_explicito", "modelo_entrenado": False,
                "limitacion": "Perfil descriptivo; no modifica pesos de un modelo ni valida la verdad de la corrección."}

    def resumen(self):
        self.experiencias = self.cargar()
        registros = [e for e in self.experiencias if isinstance(e, dict)]
        return {
            "experiencias": len(self.experiencias),
            "correcciones_confirmadas": sum(1 for e in registros if e.get("validada", False)),
            "pendientes_feedback": sum(1 for e in registros if not e.get("validada", False)),
            "aprendizaje_automatico": False,
            "perfil_aprendizaje": self.perfil_aprendizaje(),
        }
