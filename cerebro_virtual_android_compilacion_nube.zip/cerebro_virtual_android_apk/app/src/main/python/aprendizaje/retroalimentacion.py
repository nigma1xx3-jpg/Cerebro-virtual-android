from aprendizaje.neuroplasticidad import recuperar_aprendizaje
from memoria.recuperacion import recuperar_similares, texto_registro


def buscar_relacionadas(texto, limite=5):
    """Recupera experiencias parecidas por señales léxicas, no por semántica."""
    coincidencias = recuperar_similares(
        texto,
        recuperar_aprendizaje(),
        extractor=texto_registro,
        limite=limite,
        umbral=0.18,
    )
    return [
        {
            "experiencia": item["registro"],
            "similitud": item["puntuacion"],
            "coincidencias": item["coincidencias"],
        }
        for item in coincidencias
    ]
