"""Plasticidad sináptica supervisada, acotada y auditable.

Los pesos solo cambian tras una evaluación humana explícita. Una corrección
textual por sí sola no refuerza ni debilita conexiones.
"""
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from nucleo.almacenamiento import ruta_proyecto, cargar_json, guardar_json_atomico
from red_neuronal.red import RedNeuronalCognitiva


class PlasticidadSinaptica:
    def __init__(self, archivo_historial=None, archivo_pesos=None):
        self.archivo_historial = (
            Path(archivo_historial) if archivo_historial
            else ruta_proyecto("aprendizaje", "historial_plasticidad.json")
        )
        self.archivo_historial.parent.mkdir(parents=True, exist_ok=True)
        self.red = RedNeuronalCognitiva(archivo_pesos)
        self.historial = self._cargar_historial()

    def _cargar_historial(self):
        datos = cargar_json(self.archivo_historial, [])
        if not isinstance(datos, list):
            raise ValueError("El historial de plasticidad debe ser una lista JSON.")
        return [x for x in datos if isinstance(x, dict)]

    def reforzar(self, origen, destino, resultado_validado, *,
                referencia, validador, tasa=0.02, evento_id=None):
        if type(resultado_validado) is not bool:
            return {"actualizada": False, "motivo": "resultado_booleano_explicito_requerido"}
        if not isinstance(referencia, str) or not referencia.strip():
            return {"actualizada": False, "motivo": "referencia_obligatoria"}
        if not isinstance(validador, str) or not validador.strip():
            return {"actualizada": False, "motivo": "validador_obligatorio"}
        evento_id = str(evento_id or uuid4())
        self.historial = self._cargar_historial()
        if any(x.get("evento_id") == evento_id for x in self.historial):
            return {"actualizada": False, "motivo": "evento_ya_procesado", "evento_id": evento_id}

        cambio = self.red.reforzar_sinapsis(
            origen, destino, resultado_validado, tasa=tasa
        )
        if not cambio.get("actualizada"):
            return cambio

        registro = {
            "evento_id": evento_id,
            "fecha": datetime.now(timezone.utc).isoformat(),
            "origen": origen,
            "destino": destino,
            "resultado_validado": resultado_validado,
            "referencia": referencia.strip()[:300],
            "validador": validador.strip()[:120],
            "tasa": tasa,
            "peso_anterior": cambio["peso_anterior"],
            "peso_nuevo": cambio["peso_nuevo"],
            "procedencia": "evaluacion_explicita_supervisada",
        }
        self.historial.append(registro)
        guardar_json_atomico(self.archivo_historial, self.historial, copia_seguridad=True)
        return {"actualizada": True, **registro}

    def resumen(self):
        self.historial = self._cargar_historial()
        return {
            "eventos_plasticidad": len(self.historial),
            "sinapsis": len(self.red.pesos),
            "peso_medio": round(sum(self.red.pesos.values()) / max(1, len(self.red.pesos)), 4),
            "cambios_supervisados": sum(1 for x in self.historial if x.get("procedencia") == "evaluacion_explicita_supervisada"),
            "aprendizaje_autonomo": False,
            "requiere_validacion_humana": True,
        }
