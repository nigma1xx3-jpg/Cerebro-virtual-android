"""Compatibilidad del antiguo módulo de neuroplasticidad.

Este módulo resume experiencias; no modifica pesos de un modelo. El registro se
delega al almacén único de aprendizaje para evitar esquemas duplicados.
"""
from aprendizaje.adaptativo import AprendizajeAdaptativo


def cargar_experiencias():
    return AprendizajeAdaptativo().cargar()


def registrar_experiencia(evento, resultado, relevancia=1):
    try:
        nivel = max(0, min(100, int(relevancia)))
    except (TypeError, ValueError):
        nivel = 0
    evaluacion = {"confianza": nivel, "resultado": str(resultado)[:4000], "requiere_revision": True}
    return AprendizajeAdaptativo().registrar_experiencia(str(evento)[:4000], evaluacion)


def aprender():
    sistema = AprendizajeAdaptativo()
    return {
        "aprendido": False,
        **sistema.resumen(),
        "nota": "El sistema registra experiencias y feedback explícito; no entrena automáticamente un modelo.",
    }


def recuperar_aprendizaje():
    return cargar_experiencias()
