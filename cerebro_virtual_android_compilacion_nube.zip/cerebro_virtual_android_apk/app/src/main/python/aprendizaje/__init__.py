"""Subsistemas de aprendizaje supervisado y asociativo."""
from .plasticidad_sinaptica import PlasticidadSinaptica
from .asociativo import AprendizajeAsociativo

__all__ = ["PlasticidadSinaptica", "AprendizajeAsociativo"]
