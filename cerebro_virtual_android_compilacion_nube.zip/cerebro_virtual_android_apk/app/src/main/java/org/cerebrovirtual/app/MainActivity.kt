package org.cerebrovirtual.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var serverStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 17, 27)
        window.navigationBarColor = Color.rgb(8, 17, 27)

        val container = FrameLayout(this)
        val loading = TextView(this).apply {
            text = "INICIANDO CEREBRO VIRTUAL…"
            setTextColor(Color.rgb(84, 214, 223))
            textSize = 14f
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(8, 17, 27))
        }
        container.addView(loading, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))
        setContentView(container)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = request.url.host ?: return true
                return host != "127.0.0.1" && host != "localhost"
            }
        }

        executor.execute {
            try {
                if (!Python.isStarted()) {
                    Python.start(AndroidPlatform(applicationContext))
                }
                copyBundledAssets()
                val py = Python.getInstance()
                val bootstrap = py.getModule("android_bootstrap")
                bootstrap.callAttr("start", filesDir.absolutePath)
                serverStarted = true
                mainHandler.post {
                    container.removeView(loading)
                    container.addView(webView, FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    ))
                    webView.loadUrl("http://127.0.0.1:8765/")
                }
            } catch (e: Exception) {
                mainHandler.post {
                    loading.text = "No se pudo iniciar el motor.\n${e.javaClass.simpleName}: ${e.message}"
                }
            }
        }
    }

    private fun copyBundledAssets() {
        val root = java.io.File(filesDir, "cerebro_virtual_data")
        fun copyTree(assetPath: String, target: java.io.File) {
            target.mkdirs()
            val children = assets.list(assetPath) ?: emptyArray()
            children.forEach { child ->
                val childAsset = "$assetPath/$child"
                val childTarget = java.io.File(target, child)
                val nested = assets.list(childAsset) ?: emptyArray()
                if (nested.isNotEmpty()) {
                    copyTree(childAsset, childTarget)
                } else if (!childTarget.exists()) {
                    childTarget.parentFile?.mkdirs()
                    assets.open(childAsset).use { input ->
                        childTarget.outputStream().use { output -> input.copyTo(output) }
                    }
                }
            }
        }
        copyTree("cv_data", root)
        copyTree("cv_ui", java.io.File(root, "interfaz"))
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        executor.shutdown()
        super.onDestroy()
    }
}
