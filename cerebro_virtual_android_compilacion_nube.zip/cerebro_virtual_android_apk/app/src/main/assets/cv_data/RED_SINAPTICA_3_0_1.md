# Red sináptica funcional — Cerebro Virtual 3.0.1

## Qué se incorporó
- 13 neuronas computacionales que representan subsistemas de software.
- 20 conexiones sinápticas dirigidas y ponderadas.
- Propagación de activación en hasta cinco rondas.
- Trazabilidad de las conexiones activadas en cada ciclo cognitivo.
- Integración con percepción, atención, memoria, emoción, razonamiento,
  metacognición, control ejecutivo, planificación, predicción, aprendizaje
  e integridad.
- Plasticidad acotada y persistente, habilitada únicamente mediante feedback
  explícito booleano validado.

## Límites
Estas neuronas son nodos computacionales; no son neuronas biológicas ni
implican conciencia. La activación es una señal heurística para coordinar
módulos. Los pesos no se modifican automáticamente por la mera repetición:
se requiere invocar `reforzar_sinapsis` con un resultado validado.

## API básica
```python
from red_neuronal.red import RedNeuronalCognitiva

red = RedNeuronalCognitiva()
resultado = red.propagar({"percepcion": 1.0, "emocion": 0.4})
print(resultado["neuronas"])
print(resultado["sinapsis_activas"])

# Solo después de una evaluación explícita y validada:
red.reforzar_sinapsis("metacognicion", "aprendizaje", True)
```

La salida completa también aparece como `red_neuronal` en el resultado de
`ejecutar_ciclo` y se resume en la consola principal.

## Actualización 3.0.2 — plasticidad supervisada
- Se añade `aprendizaje.plasticidad_sinaptica.PlasticidadSinaptica`.
- Cada cambio exige resultado booleano explícito, referencia y validador.
- Cada cambio se registra con fecha UTC, evento único y pesos anterior/nuevo.
- Los eventos duplicados se rechazan para evitar reforzar dos veces el mismo feedback.
- La CLI incorpora `/plasticidad` y `/reforzar origen->destino|si/no|referencia`.
- Las correcciones textuales no alteran pesos automáticamente.
- La adaptación sigue siendo supervisada; no se afirma aprendizaje autónomo.
