# Cerebro Virtual 3.0 — arquitectura y límites

## Estado de esta entrega
Versión `3.0.0-alpha-autonomia-supervisada`. Esta entrega añade una primera capa ejecutiva supervisada, no autonomía irrestricta ni conciencia.

## Componentes añadidos
- `atencion/selectiva.py`: priorización léxica explicable.
- `memoria/recuperacion.py::recuperar_contextuales`: recuperación contextual local ponderada por IDF; no usa embeddings.
- `prediccion/calibrador.py`: registra predicciones y permite evaluarlas contra resultados explícitos.
- `ejecutivo/gestor.py`: objetivos y tareas persistentes; exige aprobación explícita para pasar tareas a ejecución/completadas. No ejecuta código ni acciones externas.
- `memoria/indice_calidad.py`: genera un informe de calidad sin alterar ni borrar recuerdos.
- Perfil descriptivo de aprendizaje derivado exclusivamente de feedback humano validado.

## Arquitectura operativa
Entrada -> validación -> atención -> recuperación -> razonamiento -> metacognición -> regulación -> memoria/aprendizaje. El gestor ejecutivo conserva objetivos, pero la ejecución externa está deshabilitada por diseño.

## Próximas etapas necesarias
1. Búsqueda vectorial opcional con embeddings locales y evaluación de recuperación.
2. Motor de predicción con conjuntos de prueba, métricas y calibración estadística suficiente.
3. Planificador con dependencias, plazos, prioridades y replanificación.
4. Registro de acciones con lista permitida, sandbox, límites de recursos y aprobación humana.
5. Pruebas de larga duración, recuperación tras interrupciones y evaluación de transferencia de aprendizaje.
6. Interfaz API y cliente Android/PC.

## Salvaguardas
- Los recuerdos originales se conservan. Registros con caracteres de control se excluyen solo de recuperación.
- Los recuerdos legados sin estado se mantienen como legados; no se marcan como verificados.
- Ningún feedback se considera verdad universal ni entrena pesos de un modelo.
- El sistema no se concede permisos a sí mismo.
