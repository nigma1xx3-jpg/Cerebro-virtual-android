# Cerebro Virtual - Reparaciones 2.2

## Cambios
- Rutas de memoria y aprendizaje ancladas al directorio del proyecto.
- Escrituras JSON atomicas para recuerdos, conocimientos, asociaciones y experiencias.
- Deteccion de duplicados exactos en memoria episodica y asociaciones.
- Metacognicion acepta evidencias estructuradas y revisa contradicciones.
- El ciclo cognitivo transmite calidad de evidencia del motor a metacognicion.
- Se evita registrar dos veces cada entrada en el almacén de aprendizaje.
- Se incorpora un planificador que solo propone pasos y requiere confirmacion.
- Se incorpora verificacion de procedencia y huellas SHA-256.

## Limites conocidos
- La deteccion de contradicciones es textual y conservadora; no comprende todo el lenguaje natural.
- La calidad y confianza son indicadores heurísticos, no probabilidades calibradas.
- Las huellas SHA-256 detectan cambios frente a una huella guardada externamente; no cifran ni protegen por sí solas.
- Planificacion propone planes, pero no ejecuta acciones.
- Los recuerdos nuevos se marcan como `sin_verificar`; no se convierten automáticamente en hechos.

## Seguridad de datos
Los datos JSON existentes se conservan. Se recomienda mantener una copia de seguridad antes de instalar esta versión.
