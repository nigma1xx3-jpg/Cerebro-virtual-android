# Instalación de Cerebro Virtual 2.5.0 en Termux

## Antes de instalar
- No borres `~/cerebro_2_2` ni sus respaldos.
- Instala 2.5.0 en una carpeta nueva e independiente.
- El ZIP conserva los cuatro almacenes originales de recuerdos, conocimientos, asociaciones y experiencias.

## Instalación
1. Descarga `cerebro_virtual_2_5_auditado.zip` desde el chat.
2. Abre Termux y concede acceso al almacenamiento si todavía no lo hiciste:

   ```bash
   termux-setup-storage
   ```

3. Instala las herramientas necesarias (solo Python y unzip):

   ```bash
   pkg install python unzip -y
   ```

4. Crea la carpeta nueva y copia el ZIP:

   ```bash
   mkdir -p ~/cerebro_2_5
   cp ~/storage/downloads/cerebro_virtual_2_5_auditado.zip ~/cerebro_2_5/
   cd ~/cerebro_2_5
   unzip -o cerebro_virtual_2_5_auditado.zip
   ```

5. Comprueba sintaxis y pruebas:

   ```bash
   python -m compileall -q .
   python -m unittest discover -s pruebas -v
   ```

6. Inicia el sistema:

   ```bash
   python cerebro.py
   ```

Si el programa no puede arrancar por un JSON dañado, ejecuta el diagnóstico independiente desde la carpeta del proyecto:

```bash
python -m nucleo.diagnostico
```

## Comandos de la consola
- `/diagnostico` revisa importaciones, JSON y calidad estructural de memoria.
- `/estado` muestra módulos y límites declarados.
- `/experiencias` lista experiencias y su estado de feedback.
- `/corregir N|texto` registra una corrección humana para la experiencia N (numeración visible desde 1).
- `/plan objetivo|paso1;paso2` propone un plan; no ejecuta pasos.
- `/sellar` crea una línea base SHA-256 de código y datos.
- `/verificar` compara código y datos con el último sellado.
- `salir` cierra la consola.

## Recomendación de integridad
Después de comprobar el sistema y realizar cambios de datos, ejecuta `/sellar` y luego `/verificar`. Si escribes recuerdos o registras experiencias después de sellar, el resultado `cambios_detectados` es esperado: vuelve a sellar cuando termines.

El manifiesto SHA-256 permanece dentro del proyecto. Para anclarlo frente a una modificación deliberada de todo el directorio, copia también el hash devuelto por `/sellar` fuera de Termux/proyecto.
