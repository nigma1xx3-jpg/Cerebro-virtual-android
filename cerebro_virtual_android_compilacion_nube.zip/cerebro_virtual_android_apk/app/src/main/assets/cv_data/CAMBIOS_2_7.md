# Cerebro Virtual 2.7 — Neurocognición integrada

## Qué se integró
- Nuevo módulo `neurociencia/regulacion_cognitiva.py` conectado al ciclo cognitivo.
- Atención heurística: saliencia textual y novedad léxica, con explicación de sus límites.
- Memoria de trabajo técnica: buffer local de hasta 7 elementos recientes, con longitud máxima por elemento y persistencia atómica.
- Estimación de carga cognitiva textual (baja/media/alta), sin presentarla como medición cerebral.
- Incertidumbre heurística derivada de la confianza disponible, sin elevar la certeza.
- Consolidación: sigue pendiente de feedback explícito; no se transforma una entrada en aprendizaje validado por repetición.
- Reinicio aislado del buffer técnico mediante `reiniciar_memoria_trabajo()`; no elimina recuerdos autobiográficos.
- El estado de módulos y la salida de consola muestran que la regulación está conectada.

## Salvaguardas
- No simula neuronas, neurotransmisores ni conciencia.
- No infiere estrés, sueño, dolor, emociones privadas ni diagnósticos.
- No modifica ni reclasifica recuerdos autobiográficos.
- La memoria autobiográfica del usuario se conserva; los datos excluidos de Mery siguen excluidos.
- La memoria de trabajo es independiente de los recuerdos episódicos y autobiográficos.

## Validación
- 41 pruebas automatizadas superadas.
- Compilación de todos los módulos Python superada.
- Prueba de arranque y ciclo cognitivo superada.
- La versión original 2.6 se conserva sin modificaciones.
