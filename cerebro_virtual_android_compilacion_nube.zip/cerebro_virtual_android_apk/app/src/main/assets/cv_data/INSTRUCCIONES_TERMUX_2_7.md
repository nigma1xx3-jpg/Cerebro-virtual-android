# Instalación — Cerebro Virtual 2.7

1. Conserva el ZIP anterior como respaldo.
2. Extrae `cerebro_virtual_2_7_neurocognicion.zip` en una carpeta nueva.
3. En Termux, entra a esa carpeta con `cd ruta/de/la/carpeta`.
4. Ejecuta `python cerebro.py`.
5. Usa `/estado` para comprobar que aparece `neurociencia_aplicada`.
6. Escribe una frase normal para probar el ciclo. La salida mostrará carga cognitiva estimada y novedad léxica.
7. Usa `/diagnostico` para revisar módulos y archivos JSON.
8. Usa `/neuro atención` o `/neuro memoria de trabajo` para consultar la base educativa.

No reemplaces la carpeta antigua hasta comprobar que esta versión funciona en tu Termux. La memoria de trabajo técnica se guarda en `neurociencia/estado_cognitivo.json`; no es la memoria autobiográfica.
