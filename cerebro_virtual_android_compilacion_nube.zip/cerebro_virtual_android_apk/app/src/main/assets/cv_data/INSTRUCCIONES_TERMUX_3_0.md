# Instalación — Cerebro Virtual 3.0 alpha

1. Conserva la versión anterior sin modificar.
2. Extrae este ZIP en una carpeta nueva.
3. En Termux, entra a la carpeta extraída: `cd ruta/de/cvwork`.
4. Ejecuta `python -m pytest -q` si tienes pytest instalado.
5. Ejecuta `python cerebro.py`.
6. Usa `/diagnostico` para comprobar importaciones y datos.
7. Usa `/calidad_memoria` para auditar recuerdos sin modificarlos.
8. Usa `/objetivo meta|tarea1;tarea2` para registrar un objetivo supervisado.
9. Usa `/objetivos` para consultar objetivos persistentes.
10. Usa `/predicciones` para consultar el registro de predicciones evaluadas.
11. Usa `/sellar` y luego `/verificar` para comprobar cambios locales.

La ejecución externa automática está deshabilitada. Las tareas requieren aprobación y verificación humana. Esta versión no sustituye ni borra la instalación anterior.

12. La salida de cada ciclo muestra la red sináptica: neuronas activadas y cantidad de conexiones activas.
13. La API de la red está en `red_neuronal/red.py`; la integración con el ciclo está en `red_neuronal/integracion.py`.
14. La plasticidad de conexiones requiere feedback explícito validado; no se refuerzan conexiones automáticamente por repetición.
15. Para una comprobación adicional, ejecuta `python -m unittest pruebas.test_red_neuronal -v`.
