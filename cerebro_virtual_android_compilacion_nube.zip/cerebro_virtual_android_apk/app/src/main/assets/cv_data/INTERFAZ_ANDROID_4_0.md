# Cerebro Virtual 4.0.0-alpha — Interfaz Android conectada

## Requisitos
- Python 3 en Termux.
- El ZIP completo del proyecto, extraído en una carpeta con `cerebro.py` en la raíz.
- No requiere FastAPI, Flask, Node ni conexión a Internet.

## Inicio en Termux
```bash
cd ~/cerebro_virtual/cvwork
python interfaz/servidor.py
```
Abre Chrome en el mismo teléfono:
`http://127.0.0.1:8765`

Detén el servidor con `Ctrl+C` en Termux.

## Qué está conectado
- Estado/versionado y mapa de módulos desde `estado_modulos()`.
- Recuento y listado de memoria episódica desde `recuperar_recuerdos()`.
- Consola conectada a `ejecutar_ciclo()`.
- Diagnóstico real desde `ejecutar_diagnostico()`.
- Resumen del motor semántico desde `resumen_motor()`.

## Seguridad y límites
- El servidor escucha exclusivamente en `127.0.0.1`; no se expone a la red Wi-Fi.
- El navegador no accede directamente a archivos del teléfono.
- Procesar una consulta ejecuta el ciclo existente y puede guardar el texto como recuerdo.
- La confianza mostrada es heurística, no probabilidad calibrada.
- No se habilitan acciones externas, ejecución arbitraria, cambios de sinapsis ni aprendizaje autónomo.
- La interfaz no sustituye ni altera el motor; funciona como capa de presentación y control local.

## Nota
La hoja de estilos intenta cargar Manrope/DM Mono desde Google Fonts; si no hay Internet, usa fuentes del sistema. El resto de la aplicación funciona sin red.
