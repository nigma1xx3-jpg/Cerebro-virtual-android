# Instalación y comprobación — Cerebro Virtual 3.0.3

1. Conserva los ZIP y carpetas anteriores; no los sobrescribas.
2. Extrae `cerebro_virtual_3_0_3_aprendizaje_asociativo.zip` en una carpeta nueva.
3. En Termux entra en `cvwork`, donde está `cerebro.py`.
4. Ejecuta `python -m compileall -q .`.
5. Ejecuta `python -m unittest discover -s pruebas -v`. Deben pasar 69 pruebas.
6. Inicia con `python cerebro.py`.
7. Ejecuta `/diagnostico`; comprueba que la topología indique 14 neuronas, 23 sinapsis y ninguna neurona aislada.
8. Ejecuta `/red` para inspeccionar la topología.
9. Ejecuta `/candidatos_asociativos` para ver coocurrencias extraídas de experiencias corregidas y validadas.
10. Ejecuta `/asociaciones memoria` para recuperar relaciones validadas que coincidan con el concepto consultado.
11. Solo después de revisar evidencia, usa `/validar_asociacion origen->destino|si/no|referencia`.

## Comandos nuevos

- `/candidatos_asociativos`
- `/asociaciones texto`
- `/validar_asociacion origen->destino|si/no|referencia`

Ejemplo: `/validar_asociacion memoria->atencion|si|revisión manual de la evidencia 01`.

`si` aprueba explícitamente una relación y `no` la rechaza. La referencia y el validador son obligatorios. No confirmes relaciones por simple coincidencia de palabras. Las asociaciones candidatas nunca se presentan como hechos.

La memoria asociativa usa términos normalizados y coocurrencias de experiencias corregidas por una persona. No utiliza embeddings ni demuestra causalidad. La autonomía sigue siendo supervisada y el sistema no ejecuta acciones externas por su cuenta.
