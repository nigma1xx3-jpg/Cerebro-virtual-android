# Cerebro Virtual 2.5.0 — auditoría ampliada

## Resultado de auditoría sobre el ZIP recibido
- Se conservaron sin cambios los cuatro almacenes JSON originales: recuerdos, conocimientos, asociaciones y experiencias.
- La recuperación ahora excluye de la búsqueda contenido vacío, comandos y texto con caracteres de control; los registros siguen almacenados.
- Se detectó que las categorías internas (observación, recuerdo, conocimiento, asociación) podían inflar la confianza aunque procedieran de una misma persona. El motor ya no las trata como fuentes independientes.
- Se separaron `recuerdos_relacionados` y `experiencias_relacionadas`, que antes apuntaban al mismo resultado.
- Las experiencias recuperadas ahora entran al motor como una categoría de evidencia propia, sin contarlas como fuente independiente; se prueba explícitamente que el coordinador transmite esa categoría.
- El planificador quedó accesible desde el CLI mediante `/plan`; solo propone pasos y nunca los ejecuta.
- Se consolidó el registro legado de neuroplasticidad para que utilice el mismo esquema de experiencias con ID y estado pendiente de feedback.
- Se corrigió el manejo de rutas cuando se pasa una ruta como texto al módulo de aprendizaje.
- Se endurecieron límites de datos para recuerdos, conocimientos, asociaciones, planificación y recuperación.
- La carga JSON intenta restaurar un respaldo `.bak` válido y conserva el archivo dañado como `.corrupt`; sin respaldo, propaga el error para impedir sobrescrituras silenciosas. El diagnóstico independiente informa cuando no puede leer un almacén y la consola evita confirmar aprendizaje tras una excepción.
- Se corrigió la detección de sesgos que podía activar palabras por coincidencia parcial dentro de otras palabras.
- Se amplió el diagnóstico para ejecutar importaciones reales y validar tipos de datos, sin editar los datos.
- La prueba end-to-end descubrió y permitió corregir un conflicto de importación local en el comando `/plan`; se añadió una prueba de regresión de consola.
- El sellado SHA-256 ahora cubre datos y archivos Python gestionados, y detecta archivos añadidos o ausentes desde el último sellado.

## Módulos añadidos
- `memoria/gobernanza.py`: elegibilidad y etiquetado de recuerdos según calidad estructural y procedencia declarada.
- `seguridad/esquemas.py`: comprobación de estructura de los almacenes JSON.

## Límites que permanecen explícitos
- La recuperación es léxica, no semántica ni vectorial.
- El razonamiento es un motor determinista de reglas, no un modelo de lenguaje ni una inteligencia general.
- La confianza es heurística; solo reconoce como independientes fuentes con procedencia externa explícita y estado verificado. El sistema no autentica por sí solo esas fuentes.
- La valoración emocional es un léxico simple con alcance de negación limitado.
- El aprendizaje registra correcciones; no entrena automáticamente redes neuronales ni modifica pesos.
- El planificador propone pasos; no ejecuta acciones.
- SHA-256 local detecta alteraciones comparadas con un manifiesto local. Un usuario con acceso de escritura a todo el directorio podría reemplazar también el manifiesto; para anclarlo, copia el hash fuera del proyecto.
- Los registros heredados sin procedencia se conservan y se etiquetan como no verificados. No se borraron recuerdos del usuario.

## Procedimiento de verificación ejecutado
1. Compilación de todos los módulos Python.
2. Pruebas unitarias automatizadas.
3. Diagnóstico de importaciones y almacenes JSON.
4. Prueba de consola en copia desechable: arranque, diagnóstico, sellado, verificación, interacción, feedback y salida.
5. Comparación byte a byte de los cuatro JSON originales con los del paquete final.
6. Pruebas adicionales de recuperación de datos heredados, archivos opcionales ausentes, control Unicode invisible, persistencia de feedback y recuperación ante JSON dañado/ausente y diagnóstico ante almacén inaccesible.

La batería final contiene 34 pruebas unitarias automatizadas; además se realiza una prueba end-to-end de consola en una copia desechable.


## Memoria autobiográfica del usuario (incorporación posterior)
- Se agregaron 32 recuerdos autobiográficos autorreportados.
- Se creó `memoria/autobiografia_usuario.json` como índice curado.
- Se excluyeron todos los datos de Mery; los datos de terceros no se atribuyen al usuario.
- Los datos aproximados, históricos, clínicos no confirmados y proyectos ficticios se etiquetaron con cautela.
- Se conservaron los registros preexistentes y se añadieron los nuevos; no se eliminaron recuerdos anteriores.
