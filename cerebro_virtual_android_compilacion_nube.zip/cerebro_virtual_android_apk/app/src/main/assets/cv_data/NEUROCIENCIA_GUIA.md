# Base de neurociencia de Cerebro Virtual 2.6

Esta versión incorpora una base educativa local con 28 temas y referencias bibliográficas de partida. No es una enciclopedia exhaustiva ni reemplaza la lectura de artículos originales, libros de texto o evaluación profesional.

## Áreas incluidas
1. Neurofisiología: neuronas, potenciales de acción y sinapsis.
2. Neuroquímica y neuromodulación: glutamato, GABA, dopamina, serotonina, noradrenalina y acetilcolina.
3. Plasticidad, LTP/LTD y aprendizaje.
4. Memoria episódica, semántica, procedimental y de trabajo.
5. Atención, funciones ejecutivas, emoción, motivación y decisión.
6. Sueño, ritmos circadianos y estrés.
7. Interocepción, sistema autónomo, percepción, dolor y control motor.
8. Lenguaje, dislexia y neurodesarrollo.
9. Envejecimiento y reserva cognitiva.
10. Glía, mielina y neuroinmunología.
11. Redes cerebrales y métodos de investigación.
12. Genética, epigenética, neuroética y privacidad.

## Uso desde Termux
- `/neuro` muestra el resumen de la base.
- `/neuro dopamina recompensa` busca entradas relacionadas.
- `/neuro memoria episódica` consulta sistemas de memoria.

La búsqueda actual es léxica, no comprensión semántica profunda. Cada resultado incluye cautelas y referencias para evitar presentar simplificaciones como hechos absolutos.

## Principios científicos incorporados
- Distinguir correlación de causalidad.
- Distinguir nocicepción de dolor, memoria de exactitud, confianza de certeza y aprendizaje computacional de plasticidad biológica.
- No convertir síntomas en diagnósticos.
- No atribuir una función compleja a una sola región cerebral.
- No inferir pensamientos, emociones o estados clínicos de una persona solo a partir de texto.
- Tratar las puntuaciones del sistema como heurísticas no calibradas.

## Referencias de texto y revisión
Las referencias por entrada apuntan a libros de texto y revisiones académicas reconocidas. Deben comprobarse y ampliarse al hacer futuras revisiones; el contenido es una síntesis y no reproduce capítulos o artículos.
