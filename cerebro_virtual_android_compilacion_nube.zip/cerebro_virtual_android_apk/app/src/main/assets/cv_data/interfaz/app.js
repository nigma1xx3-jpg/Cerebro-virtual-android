const $ = (id) => document.getElementById(id);
const api = async (path, options={}) => {
  const r = await fetch(path, {headers:{"Content-Type":"application/json"}, ...options});
  const data = await r.json().catch(()=>({ok:false,error:"Respuesta no válida"}));
  if(!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
  return data;
};
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400)}
function safe(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function loadStatus(){
 try{
  const d=await api("/api/status");
  $("connection").textContent="CONECTADO";$("version").textContent=d.version;
  $("engine-state").textContent="ACTIVO";$("module-count").textContent=d.module_count;
  $("memory-count").textContent=d.memory_count??"—";$("memory-state").textContent=d.memory_state;
  $("modules").innerHTML=Object.entries(d.modules).map(([k,v])=>`<div class="module-item"><div class="module-name">${safe(k.replaceAll("_"," "))}</div><div class="module-state">${safe(v)}</div></div>`).join("");
 }catch(e){$("connection").textContent="SIN CONEXIÓN";$("engine-state").textContent="OFFLINE";$("modules").innerHTML=`<div class="empty">No se pudo conectar: ${safe(e.message)}</div>`}
}
async function loadMemories(){
 try{
  const d=await api("/api/memories");$("memory-total").textContent=`${d.count} REGISTROS`;
  $("memories").innerHTML=d.items.length?d.items.map(x=>`<article class="memory-item"><div class="memory-content">${safe(x.content)}</div><div class="memory-meta">${safe(x.date)} · ${safe(x.source)} · ${safe(x.status)}</div></article>`).join(""):`<div class="empty">Todavía no hay recuerdos registrados.</div>`;
 }catch(e){$("memories").innerHTML=`<div class="empty">${safe(e.message)}</div>`}
}
$("query").addEventListener("input",e=>$("char-count").textContent=`${e.target.value.length} / 4000`);
$("query-form").addEventListener("submit",async e=>{
 e.preventDefault();const text=$("query").value.trim();if(!text)return;
 const btn=$("send");btn.disabled=true;btn.textContent="PROCESANDO…";
 $("response").classList.remove("hidden");$("response").innerHTML="<div class='loading'>El motor está ejecutando el ciclo cognitivo…</div>";
 try{
  const d=await api("/api/process",{method:"POST",body:JSON.stringify({text})});
  const warnings=(d.warnings||[]).map(x=>safe(x)).join(" · ");
  $("response").innerHTML=`<h3>RESPUESTA DEL MOTOR</h3><p>${safe(d.answer)}</p><div class="response-meta">Confianza heurística: ${safe(d.confidence)} · Estado: ${safe(d.reasoning_state)} · Evidencias: ${safe(d.evidence_count)}<br>Metacognición: ${safe(d.metacognition?.estado||"no disponible")} · Carga estimada: ${safe(d.cognitive_load??"no disponible")}<br>${safe(d.note)}${warnings?`<br>Avisos: ${warnings}`:""}</div>`;
  await loadStatus();await loadMemories();toast("Ciclo cognitivo completado");
 }catch(err){$("response").innerHTML=`<h3>NO SE COMPLETÓ EL CICLO</h3><p>${safe(err.message)}</p>`}
 finally{btn.disabled=false;btn.innerHTML='PROCESAR <span>↗</span>'}
});
$("refresh").addEventListener("click",async()=>{await loadStatus();await loadMemories();toast("Panel actualizado")});
$("run-diagnostic").addEventListener("click",async()=>{
 const b=$("run-diagnostic");b.disabled=true;b.textContent="EJECUTANDO…";$("diagnostic-result").textContent="Ejecutando diagnóstico del motor…";
 try{const d=await api("/api/diagnostic");$("diagnostic-result").textContent=JSON.stringify(d.diagnostic,null,2);toast("Diagnóstico recibido")}
 catch(e){$("diagnostic-result").textContent="Error: "+e.message}
 finally{b.disabled=false;b.textContent="EJECUTAR TEST"}
});
loadStatus();loadMemories();
