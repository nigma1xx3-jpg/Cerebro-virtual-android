# Instalación y comprobación — Cerebro Virtual 3.0.2

1. Conserva las carpetas y ZIP anteriores; no los sobrescribas.
2. Extrae `cerebro_virtual_3_0_2_plasticidad_supervisada.zip` en una carpeta nueva.
3. En Termux entra en la carpeta `cvwork` que contiene `cerebro.py`.
4. Ejecuta `python -m compileall -q .`.
5. Ejecuta `python -m unittest discover -s pruebas -v`.
6. Inicia con `python cerebro.py`.
7. Ejecuta `/diagnostico` y confirma que la topología de la red sea válida.
8. Ejecuta `/red` para revisar las 13 neuronas y sus 20 conexiones.
9. Ejecuta `/plasticidad` para consultar los cambios supervisados.
10. Solo después de evaluar manualmente una conexión, puedes usar `/reforzar origen->destino|si/no|referencia`.

Ejemplo de sintaxis: `/reforzar percepcion->atencion|si|prueba manual 01`.

**Importante:** `si` significa que una evaluación humana explícita confirmó que esa conexión contribuyó correctamente en el caso citado; `no` significa que la evaluación confirmó que no contribuyó correctamente. No uses este comando como prueba casual. Los cambios quedan guardados con referencia, validador, fecha y pesos anterior/nuevo. Un mismo identificador de evento no puede aplicarse dos veces.

La autonomía continúa siendo supervisada. El programa no ejecuta acciones externas por sí solo y no modifica pesos a partir de la mera repetición de mensajes.
