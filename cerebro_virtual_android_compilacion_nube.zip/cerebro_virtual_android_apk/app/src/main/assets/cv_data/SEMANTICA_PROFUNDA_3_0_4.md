# Cerebro Virtual 3.0.4 — Recuperación semántica híbrida

## Qué incorpora
- Vectorización local dispersa TF-IDF y similitud coseno.
- Expansión conceptual española conservadora (sinónimos aproximados).
- Normalización morfológica ligera.
- Coincidencia literal como señal complementaria.
- Recuperación integrada en `razonamiento.central.buscar_coincidencias`.
- Gobernanza y procedencia existentes se mantienen antes de recuperar.

## Límites importantes
Este motor no utiliza un modelo Transformer ni embeddings neuronales contextuales.
Es un recuperador semántico local simbólico-vectorial, explicable y sin descargas.
La expansión conceptual puede generar falsos positivos; por eso las puntuaciones
son señales de recuperación, no prueba de verdad ni comprensión humana.
Los datos recuperados mantienen su estado de verificación y procedencia.

## Pruebas
Ejecutar desde `cvwork/`:
`python -m unittest discover -s pruebas -v`

El aprendizaje de hechos sigue requiriendo validación explícita.
