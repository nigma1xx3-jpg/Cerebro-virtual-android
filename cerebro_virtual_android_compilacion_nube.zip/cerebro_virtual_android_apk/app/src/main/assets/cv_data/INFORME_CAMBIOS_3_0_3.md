# Cerebro Virtual 3.0.3 — Aprendizaje asociativo supervisado

## Objetivo
Añadir memoria asociativa conectada al ciclo cognitivo y a la red neuronal computacional, sin convertir coocurrencias en hechos.

## Cambios implementados
- Nuevo módulo `aprendizaje/asociativo.py`.
- Generación de candidatos a partir de experiencias con corrección humana explícita y validada.
- Las coocurrencias solo producen candidatos `candidato_no_verificado`.
- Una asociación solo se activa en recuperación tras aprobación humana explícita con referencia y validador.
- Rechazo de relaciones también persistente y trazable.
- Protección contra eventos duplicados mediante `evento_id`.
- Recuperación asociativa por coincidencia de cualquiera de los conceptos de una relación validada.
- Integración de la memoria asociativa en `nucleo/ciclo_cognitivo.py`.
- Nueva neurona computacional `memoria_asociativa`.
- Tres conexiones nuevas: memoria episódica -> memoria asociativa; memoria semántica -> memoria asociativa; memoria asociativa -> razonamiento.
- Nuevos comandos CLI: `/candidatos_asociativos`, `/asociaciones texto` y `/validar_asociacion origen->destino|si/no|referencia`.
- Diagnóstico ampliado para importar el nuevo módulo.

## Topología
- 14 neuronas computacionales.
- 23 conexiones sinápticas dirigidas.
- Ninguna neurona aislada en la topología base.

## Validación ejecutada
- Suite completa: 69 pruebas superadas.
- Compilación de módulos Python: correcta.
- Prueba de humo del ciclo cognitivo: correcta.
- Confirmado que la salida del ciclo incluye memoria asociativa y propagación a la neurona correspondiente.
- Diagnóstico: `correcto_con_advertencias`; los módulos importan y la topología es válida.
- ZIP comprobado con `ZipFile.testzip()`.

## Límites
- No usa embeddings ni comprensión semántica profunda; la extracción de términos es léxica.
- Las coocurrencias no demuestran causalidad ni verdad.
- No se activan como conocimiento relaciones no validadas por una persona.
- La asociación no equivale a aprendizaje autónomo ni a conciencia.
- La autonomía continúa supervisada.
