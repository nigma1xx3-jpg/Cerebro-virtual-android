# Cerebro Virtual Android — proyecto APK 4.0.0-alpha

Este paquete contiene el proyecto Android Studio y el motor Python completo integrado mediante Chaquopy.

## Qué hace esta versión
- La app inicia Python dentro del proceso Android.
- Copia la estructura inicial del motor a `filesDir` privado para permitir persistencia.
- Configura `CV_DATA_DIR` antes de importar módulos cognitivos.
- Inicia la API local en `127.0.0.1:8765`.
- Abre el panel 4.0 en un WebView restringido al host local.
- La app no publica el servidor en la red Wi-Fi.

## Compilación
Requisitos: Android Studio, JDK 17, Android SDK 35 y conexión a Internet para descargar dependencias de Gradle/Chaquopy.

1. Abrir esta carpeta en Android Studio.
2. Esperar la sincronización de Gradle.
3. Seleccionar `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Instalar el APK generado en el teléfono.

## Límites conocidos de esta alpha
- Es un proyecto Android compilable, no un APK binario ya compilado.
- La compilación no se pudo ejecutar en este entorno porque no dispone de Android SDK ni Gradle.
- Se debe probar el empaquetado de datos no-Python del motor y el comportamiento de persistencia en dispositivo.
- La actividad mantiene el motor ligado al proceso de la app; Android puede finalizar procesos en segundo plano. Una futura versión debe incorporar un servicio foreground cuando se necesite ejecución prolongada.
- El motor se conserva en Python; no se ha reescrito en Kotlin.
- No hay sincronización en nube ni acceso a acciones externas.
