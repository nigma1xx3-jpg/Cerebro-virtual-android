# Cómo obtener el APK desde tu teléfono (sin computador)

## Método: GitHub Actions
Este proyecto incluye `.github/workflows/android.yml`. GitHub compilará el APK en la nube.

1. Descarga y extrae el ZIP.
2. Entra a https://github.com y crea una cuenta o inicia sesión.
3. Crea un repositorio nuevo llamado `cerebro-virtual-android`.
   - Puede ser privado.
   - No marques "Add a README".
4. En el navegador del teléfono, abre el repositorio y selecciona **Add file > Upload files**.
5. Sube el contenido de la carpeta `cerebro_virtual_android_apk` (no la carpeta exterior), incluyendo `.github`, `app`, `build.gradle`, `settings.gradle` y `gradle.properties`.
   - Si GitHub móvil no muestra archivos ocultos, activa "Sitio de escritorio" en el navegador para incluir `.github`.
6. Pulsa **Commit changes**.
7. Abre la pestaña **Actions** del repositorio.
8. Selecciona **Build Cerebro Virtual APK** y pulsa **Run workflow** si no comenzó automáticamente.
9. Espera a que termine en verde.
10. Abre la ejecución completada y baja a **Artifacts**.
11. Descarga `cerebro-virtual-4-0-alpha-debug`, descomprime ese ZIP y abre `app-debug.apk`.
12. Android preguntará si permites instalar desde esa fuente; autoriza el navegador/gestor de archivos y continúa.

## Importante
- GitHub Actions compila el APK; no compila dentro de ChatGPT.
- El APK es de depuración, no firmado para publicación en Play Store.
- Mantén el repositorio privado: el código contiene el motor y podría contener datos de memoria de prueba.
- Antes de instalar, verifica que el flujo terminó correctamente.
- Esta versión es alpha: aún falta validar en tu dispositivo la persistencia, arranque y consultas cognitivas reales.

## Configuración técnica
- JDK 17, Gradle 8.9, Android SDK 35.
- Chaquopy 17.2.0 y Python 3.13.
- ABI arm64-v8a y x86_64.
