# Estado de construcción — APK Cerebro Virtual 4.0.0-alpha

## Qué se construyó
- Proyecto Android nativo en Kotlin.
- Integración del motor Python con Chaquopy.
- Arranque del motor al abrir la Activity.
- API HTTP local enlazada a 127.0.0.1:8765.
- WebView con navegación limitada al servidor local.
- Interfaz copiada a almacenamiento privado de la aplicación.
- Datos persistentes sembrados en `filesDir/cerebro_virtual_data`.
- Copia inicial no sobrescribe archivos de datos existentes.
- Icono vectorial de aplicación.
- Motor Python completo incluido en `app/src/main/python`.

## Comprobaciones realizadas en este entorno
- 76/76 pruebas unitarias del motor: OK.
- Compilación sintáctica de todos los archivos Python: OK.
- Arranque de bootstrap Python: OK.
- `GET /api/health`: HTTP 200.
- `GET /api/status`: HTTP 200.
- `GET /`: HTTP 200.

## Lo que NO se ha comprobado
No se ha generado ni instalado un APK binario. Este entorno no tiene Android SDK ni Gradle, por lo que no puede ejecutar la compilación Android. La integración Kotlin/Chaquopy requiere sincronización y compilación en Android Studio con JDK 17 y Android SDK 35.

## Compilar cuando haya un PC disponible
1. Extraer este ZIP.
2. Abrir la carpeta `cerebro_virtual_android_apk` en Android Studio.
3. Instalar JDK 17 y Android SDK 35 desde SDK Manager.
4. Sincronizar Gradle y resolver dependencias.
5. Ejecutar Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Instalar el APK de `app/build/outputs/apk/debug/`.

## Advertencia técnica
Esta es una alpha de integración. Antes de considerar estable el APK hay que probar en un dispositivo real: arranque en frío, permisos, cierre/reapertura, persistencia de recuerdos, procesamiento cognitivo, tamaño del APK y compatibilidad ARM64.

## Compilación desde Android
Se añadió workflow GitHub Actions para compilar el APK en la nube, con JDK 17, Gradle 8.9, SDK 35, Chaquopy 17.2.0 y Python 3.13.
