# Método simplificado: compilar desde Android con GitHub

## Parte 1: subir un solo archivo
1. Crea un repositorio privado en GitHub llamado `cerebro-virtual-android`.
2. En el repositorio, pulsa Add file > Upload files.
3. Sube únicamente `cerebro_virtual_android_compilacion_nube.zip`.
4. Pulsa Commit changes.

## Parte 2: crear el workflow
1. En el repositorio, pulsa Add file > Create new file.
2. En el nombre escribe exactamente `.github/workflows/android.yml`.
3. Abre `GITHUB_WORKFLOW_PARA_COPIAR.yml` de este paquete y copia todo su contenido al editor de GitHub.
4. Pulsa Commit changes.

## Parte 3: compilar
1. Abre la pestaña Actions.
2. Entra a Build Cerebro Virtual APK.
3. Pulsa Run workflow y confirma.
4. Espera a que termine en verde.
5. Abre la ejecución y descarga el artefacto `cerebro-virtual-4-0-alpha-debug`.
6. Descomprime el artefacto y toca `app-debug.apk` para instalar.

No compartas el repositorio públicamente: el proyecto contiene el motor y archivos de datos de memoria. Manténlo privado.
